/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h> 
#include <boost/property_tree/xml_parser.hpp>
#include <xrt.h>
#include <ert.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include "xss_ioctl.h"
#include <signal.h>

#include "ert.h"
#include "xclbin.h"
#include "experimental/xrt-next.h"

//#define DEBUG

#define MAX_XSS_DEVICE 30
#define MAX_LINE_SIZE 2048
#define MAX_CUS_PER_KERNEL 10
#define MAX_CU_LIST_LENGTH 500

int get_xclbinid(char *bdf,char* &xclbin);
int get_peer_dev(char *bdf, char* &nvme_ctrl);

char bdf_add[MAX_XSS_DEVICE][100], 
kernel_name[MAX_XSS_DEVICE][100], xclbin_path[MAX_XSS_DEVICE][100];
unsigned pcislot[MAX_XSS_DEVICE];

int get_major_minor(char *bdf, int& dev_maj_min, int cmd)
{
	struct dirent *dp;
	char line[MAX_LINE_SIZE]; 
	int maj_min[10];
	char syspath[100] = "/sys/bus/pci/devices/";
	int i = 0;
	DIR *dr;

	dr = opendir(syspath);
	if (dr == NULL)
	{
		printf("Could not open '%s' directory",syspath);
		return -1;
	}
	closedir(dr);
	strcat(syspath,bdf);
	strcat(syspath,"/drm");
	dr = opendir(syspath);
	if (dr == NULL)
	{
		printf("Could not open '%s' directory",syspath);
		return -1;
	}
	while ((dp = readdir(dr)) != NULL){
		if(strstr(dp->d_name, "renderD") != NULL){
			strcat(syspath,"/");
			strcat(syspath,dp->d_name);
		}
	}
	closedir(dr);
	strcat(syspath,"/dev");

	FILE *fptr;
	if ((fptr = fopen(syspath, "r")) == NULL) {
		printf("Error! opening file");
		return -1;//exit(1);
	}

	i=0;
	while(fgets(line,MAX_LINE_SIZE,fptr)){
		char *pname = strtok(line, ":"); 
		while (pname != NULL) 
		{ 
			maj_min[i++] = atoi(pname);
			pname = strtok(NULL, ":"); 
		}
	}
	//printf("%d:%d\t\t",maj_min[0],maj_min[1]);
	if(cmd)
		dev_maj_min = maj_min[0];
	else
		dev_maj_min = maj_min[1];

	return 0; 
}

static size_t convert(const std::string& str)
{
	return str.empty() ? 0 : std::stoul(str,0,0);
}

int comp (const void * add1, const void * add2)
{
    int first = *((int*)add1);
    int second = *((int*)add2);
    if (first > second) return  1;
    if (first < second) return -1;
    return 0;
}

int check_cu_conf(const char cu_to_check[50],char src_kernel_list[MAX_CU_LIST_LENGTH])
{
	char list[MAX_CU_LIST_LENGTH];
	if(src_kernel_list[0]==NULL)
		return 1;

	strcpy(list,src_kernel_list);
	char *p = strtok(list,"\n");
	p = strtok(list,",");
	while (p != NULL)
	{
		if(strstr(cu_to_check,p)) {
			if(strcmp(p,cu_to_check)==0)
				return 1;
			else
				return 2;
		}
	        p = strtok(NULL, ",");
	}
	return 0;
}
int get_xclbin_info(xclDeviceHandle& handle, ssize_t& xmlFileSize, char* &xmlFile, ssize_t& context_size, struct xss_dev_cu_info *pxac, int kernel_conf_index)
{
	boost::property_tree::ptree xml_project;
	std::string sXmlFile;
	sXmlFile.assign(xmlFile, xmlFileSize);
	std::stringstream xml_stream;
	xml_stream << sXmlFile;
	boost::property_tree::read_xml(xml_stream, xml_project);

	struct cu_info *pcu;
	struct arg_info *pai;
	int cu_idx=0;
	int arg_idx=0;

	int mem_idx=0;
	uint64_t section_size;
	struct connection section_info;
	int ret = 0;
	size_t baddr_arr[MAX_CUS_PER_KERNEL], orig_baddr[MAX_CUS_PER_KERNEL];
	for (auto& xml_kernel : xml_project.get_child("project.platform.device.core")){
		if (xml_kernel.first != "kernel")
			continue;

		for (auto& xml_kernel_info : xml_kernel.second){
			if(xml_kernel_info.first == "instance"){
#ifdef DEBUG
				printf("\nInstance Name:%s",xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str());
				printf("\nKernel Name:%s",xml_kernel.second.get<std::string>("<xmlattr>.name").c_str());
#endif
				ret = check_cu_conf(xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str(),kernel_name[kernel_conf_index]);
				if(ret == 1) {
					pxac->num_cus = cu_idx+1;
					if(cu_idx == 0)
						pxac->cu = (struct cu_info*)malloc(sizeof(struct cu_info));
					else
						pxac->cu = (struct cu_info*)realloc(pxac->cu, (cu_idx+1) * sizeof(struct cu_info));

					context_size = context_size + sizeof(struct cu_info);
					pcu = &pxac->cu[cu_idx];

					strcpy(pcu->kernel_name,xml_kernel.second.get<std::string>("<xmlattr>.name").c_str());
					pcu->cu_index = cu_idx;
					arg_idx=0;
					int idx_cu;
					char kernel_instance[100];
					memset(kernel_instance, '\0', sizeof(kernel_instance));
					strcat(kernel_instance,pcu->kernel_name);
					strcat(kernel_instance,":");
					strcat(kernel_instance,xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str());
					idx_cu = xclIPName2Index(handle,kernel_instance);
					pcu->cu_index = idx_cu;

#ifdef DEBUG
					printf("\nfa:%s CU:%d\n",kernel_instance,idx_cu);
					for (auto& xml_kernel_instance : xml_kernel_info.second) {
						if(xml_kernel_instance.first=="addrRemap") {
							orig_baddr[cu_idx] = convert(xml_kernel_instance.second.get<std::string>("<xmlattr>.base"));
							//baddr_arr[cu_idx] = convert(xml_kernel_instance.second.get<std::string>("<xmlattr>.base"));
						}
					}
#endif
					for (auto& xml_kernel_info : xml_kernel.second){
						if (xml_kernel_info.first == "arg"){
							pcu->num_args = arg_idx+1;
							if(arg_idx == 0)
								pcu->args = (struct arg_info*)malloc(sizeof(struct arg_info));
							else
								pcu->args = (struct arg_info*)realloc(pcu->args, (arg_idx+1) * sizeof(struct arg_info));

							context_size = context_size + sizeof(struct arg_info);
							pai = &pcu->args[arg_idx];
							strcpy(pai->name,xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str());
							pai->address_qualifier = convert(xml_kernel_info.second.get<std::string>("<xmlattr>.addressQualifier"));
							pai->offset = convert(xml_kernel_info.second.get<std::string>("<xmlattr>.offset"));
							pai->size = convert(xml_kernel_info.second.get<std::string>("<xmlattr>.size"));
							pai->hostoffset = convert(xml_kernel_info.second.get<std::string>("<xmlattr>.hostOffset"));
							pai->hostsize = convert(xml_kernel_info.second.get<std::string>("<xmlattr>.hostSize"));
							if(pai->address_qualifier == 1){
								ret = xclGetSectionInfo(handle, &section_info, &section_size, CONNECTIVITY, mem_idx);
								if(ret){
									printf( "Failed to get connectivity for mem_idx %d", mem_idx);
									return ret;
								}
								pai->ddr = section_info.mem_data_index;
								mem_idx++;
							}
							arg_idx++;
						}
					}
				cu_idx++;
				}
				else if(ret == 2){
					printf("\nLoad-config Failed... Check your CU list in xss.conf ! Exiting...\n");
					exit(0);
				}
				else {
#ifdef DEBUG
					printf("\nCU Instance %s not found in xss.conf\n",xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str());
#endif
				}
			}
		}
	}
#if 0
	qsort (baddr_arr, cu_idx, sizeof(size_t), comp);

	for (int base_idx = 0 ; base_idx < pxac->num_cus; base_idx++) {
		for (int index = 0 ; index < cu_idx; index++) {
			if(baddr_arr[base_idx]==orig_baddr[index]) {
				pxac->cu[index].cu_index = base_idx;
				break;
			}
		}
	}
#endif

#ifdef DEBUG
	for (cu_idx=0;cu_idx<pxac->num_cus;cu_idx++)
		printf("\nCu Index: %d base add %x",pxac->cu[cu_idx].cu_index,orig_baddr[cu_idx]);
		printf("\n");
#endif

	return 0;
}

int read_config_file()
{
	FILE *fptr;
	char line[MAX_LINE_SIZE]; int line_index = 0;char *p;
	char bdf[MAX_XSS_DEVICE][100], kernel[MAX_XSS_DEVICE][100]={'\0'};
	char xclbin[MAX_XSS_DEVICE][100];
	int i=0;

	if ((fptr = fopen("/etc/xss.conf", "r")) == NULL) {
		printf("Error! opening file");
		exit(1);
	}

	while(fgets(line,MAX_LINE_SIZE,fptr)){
		char *cmt_ind = strstr(line, "#");
		int len = strlen(line);
		if ((cmt_ind) || (len < 2) ) {
			continue;
		}

		i =0;
		p = strtok(line, " ");
		while (p != NULL)
		{
			if(i==0) strcpy(bdf[line_index],p);
			if(i==1) strcpy(xclbin[line_index],p);
			if(i==2) strcat(kernel[line_index],p);
			p = strtok(NULL, " ");
			i++;
		}
		if(bdf[line_index][0]==NULL | xclbin[line_index][0]==NULL) {
			printf("\nConfiguration Error : Define <bdf_addr> <xclbin_path> in /etc/xss.conf...\n\n");
			exit(0);
		}
		char *xcl = strtok(xclbin[line_index],"\n");
		strcpy(xclbin[line_index],xcl);
		strcpy(bdf_add[line_index],bdf[line_index]);
		strcpy(xclbin_path[line_index],xclbin[line_index]);
		strcat(kernel_name[line_index],kernel[line_index]);
		line_index++;
	}
	if(line_index == 0) {
		printf("No Configuration found...\nDefine <bdf_addr> <xclbin_path> in /etc/xss.conf...\n");
		exit(0);
	}

	// To get the kernel name separated
	//i =0;
	//while(i<line_index){
	//	p = strtok(kernel[i++],",");
	//	while (p != NULL)
	//	{
	//		//printf("kernel:%s\n",p);
	//		p = strtok(NULL, ",");
	//	}
	//}
	////

	int array[5];int j=0;
	while(j<line_index){
		i = 0;
		p = strtok(bdf[j],":");
		while (p != NULL)
		{
			array[i] = (int)strtol(p, NULL, 16);
			if(i >= 1)
				p = strtok(NULL, ".");
			else
				p = strtok(NULL, ":");
			i++;
		}
		pcislot[j++] = (array[i-4]<<16) + (array[i-3]<<8) + (array[i-2]<<3) + array[i-1];
	}
	//printf("pci1:%d pci2:%d",pcislot[0],pcislot[1]);
	return 0;
}

int initXRT(unsigned deviceIndex,
		const char* halLog,
		xclDeviceHandle& handle,
		int cu_index,
		int& first_used_mem,
		uuid_t& xclbinId,
		ssize_t& xmlFileSize,
		char* &xmlFile,
		int& xss_index)
{
	xclDeviceInfo2 deviceInfo;

	xss_index = 0;

	handle = xclOpen(deviceIndex, halLog, XCL_INFO);

	if (xclGetDeviceInfo2(handle, &deviceInfo)) {
		printf( "Unable to obtain device information\n");
		return -1;
	}


	while((xss_index < MAX_XSS_DEVICE) && pcislot[xss_index]) {
		if(deviceInfo.mPciSlot == pcislot[xss_index]) {
			break;
		}
		xss_index++; 
	}

	if(deviceInfo.mPciSlot!= pcislot[xss_index]) {
		//printf("PCIslot verification failed, device pcislot: %d!\n",deviceInfo.mPciSlot);
		return -1;
	}
	const char* bit = xclbin_path[xss_index];
	//printf("Loading xclbin on device %s...  ",bdf_add[xss_index]);
	printf("Configuring device %s... ",bdf_add[xss_index]);

    	/* Xclbin Path exists. */
	FILE *fptr;
        if ((fptr = fopen(bit, "r")) == NULL) {
		//printf("Status : Failed !\n");
                printf("Error! Xclbin file not found!\n");
                return -1;
        }

	if (!bit || !strlen(bit))
		return 0;

	if(xclLockDevice(handle)) {
		printf( "Cannot lock device\n");
		return -1;
	}

	std::ifstream stream(bit, std::ifstream::binary);
	stream.seekg(0, stream.end);
	int size=0;
	size = stream.tellg();
	stream.seekg(0, stream.beg);

	char *header = new char[size];
	stream.read(header, size);

	if (strncmp(header, "xclbin2", 8)) {
		printf( "Invalid bitstream\n");
		return -1;
	}

	const xclBin *blob = (const xclBin *)header;
	if (xclLoadXclBin(handle, blob)) {
		delete [] header;
		printf( "Xclbin:%s load on device failed!", bit);
		return -1;
	}
	//printf("Status : Success ! \n");
	printf("Loaded xclbin:%s, ", bit);

	const axlf* top = (const axlf*)header;
	auto ip = xclbin::get_axlf_section(top, IP_LAYOUT);
	struct ip_layout* layout =  (ip_layout*) (header + ip->m_sectionOffset);

	if(cu_index > layout->m_count) {
		delete [] header;
		printf( "Cant determine cu base address\n");
		return -1;
	}

	auto topo = xclbin::get_axlf_section(top, MEM_TOPOLOGY);
	struct mem_topology* topology = (mem_topology*)(header + topo->m_sectionOffset);

	for (int i=0; i<topology->m_count; ++i) {
		if (topology->m_mem_data[i].m_used) {
			first_used_mem = i;
			break;
		}
	}

	uuid_copy(xclbinId, top->m_header.uuid);

	auto emsec = xclbin::get_axlf_section(top, EMBEDDED_METADATA);
	xmlFileSize = emsec->m_sectionSize;
	xmlFile = new char[xmlFileSize];
	memcpy(xmlFile, header + emsec->m_sectionOffset, xmlFileSize);

	delete [] header;
	return 0;
}

int load_config(void)
{
	int device_index = 0;
	unsigned cu_index = 0;
	int fd, ret=0;
	int device_major,device_minor;

	/* Read xss.conf file */
	read_config_file();
	//exit(0);
	int devices = xclProbe();
	if(device_index >= devices) {
		printf( "No Xilnix Acceleration devices found!!\n");
		return -1;
	}
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	printf("Reading configuration from /etc/xss.conf: \n");
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	int other_device = 0;
	while(devices-- > 0) {
		xclDeviceHandle handle;
		int first_mem = -1;
		uuid_t xclbinId;

		ssize_t xmlFileSize = 0;
		char* xmlFile = nullptr;
		int xss_config_index=0;
		ret = initXRT(device_index, NULL, handle, cu_index, first_mem, xclbinId, xmlFileSize, xmlFile, xss_config_index);
		if (ret) {
			//printf( "\nNot loading xclbin to %d device\n", device_index);
			other_device++;
			device_index++;
			continue;
		}
		struct xss_ioctl xdata;
		struct xss_dev_cu_info *pxac;
		pxac = (struct xss_dev_cu_info *)malloc(sizeof(struct xss_dev_cu_info));
		ssize_t context_size = sizeof(struct xss_dev_cu_info);
		ret = get_xclbin_info(handle, xmlFileSize, xmlFile, context_size, pxac, xss_config_index);

		//printf( "context_size %zd\n", context_size);
		fd = open("/dev/xss-interface", O_RDWR);
		if (fd < 0){
			printf( "Failed to open XSS interface device...");
			printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			closelog();
			return -1;
		}
		//printf("Configuring Device in XSS Driver... \n");
		ret = get_major_minor(bdf_add[xss_config_index],device_major,1);
		ret = get_major_minor(bdf_add[xss_config_index],device_minor,0);
		if(ret) {
			printf("Major Minor not found for :%s",bdf_add[xss_config_index]);
			printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			return -1;
		}
		char *xclbin = nullptr;
		ret = get_xclbinid(bdf_add[xss_config_index],xclbin);
		if(ret) {
			printf("XCLBINID not found for :%s",bdf_add[xss_config_index]);
			printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			return -1;
		}
		char *nvme = nullptr;
		ret = get_peer_dev(bdf_add[xss_config_index],nvme);
		//printf("maj:%d min:%d xcl:%s bdf addr:%s pcislot :%lx\n",device_major,device_minor,xclbin,bdf_add[xss_config_index],pcislot[xss_config_index]);
		xdata.size = context_size;
		xdata.dev_info = pxac;
		xdata.dev_info->major = device_major;//226;
		xdata.dev_info->minor = device_minor;//128;
		xdata.dev_info->pci_addr = pcislot[xss_config_index];
		strcpy(xdata.dev_info->peer_nvme,nvme);
		strcpy(xdata.dev_info->xclbin_id, xclbin);//"eeiuosdfoutre-asdfmpio-989342jklas");
		ret = ioctl(fd, XSS_ADD_DEV_CU_INFO_IOCTL, &xdata);
		if(ret){
			printf("Failed to add device info to xss-driver!\n");
			closelog();
			device_index++;
			continue;
			//return ret;
		}
		printf("Added device info to XSS.\n");
		device_index++;
		delete[] xmlFile;
		free(pxac);
		close(fd);
	}
	//printf("Devices:%d other:%d device_index:%d\n",devices,other_device,device_index);
	if(other_device == device_index) {
		printf( "Failed to configure any device specified in xss.conf, Please check BDF address\n");
	}
	printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	closelog();

	return 0;
}

int get_kernel_names(const char* bit)
{

	if (!bit || !strlen(bit))
		return 0;

	std::ifstream stream(bit, std::ifstream::binary);
	stream.seekg(0, stream.end);
	int size=0;
	size = stream.tellg();
	stream.seekg(0, stream.beg);

	char *header = new char[size];
	stream.read(header, size);

	if (strncmp(header, "xclbin2", 8)) {
		printf( "Invalid bitstream\n");
		return -1;
	}

	const axlf* top = (const axlf*)header;
	auto emsec = xclbin::get_axlf_section(top, EMBEDDED_METADATA);
	ssize_t xmlFileSize = emsec->m_sectionSize;
	char* xmlFile = new char[xmlFileSize];
	memcpy(xmlFile, header + emsec->m_sectionOffset, xmlFileSize);

	delete [] header;

	boost::property_tree::ptree xml_project;
	std::string sXmlFile;
	sXmlFile.assign(xmlFile, xmlFileSize);
	std::stringstream xml_stream;
	xml_stream << sXmlFile;
	boost::property_tree::read_xml(xml_stream, xml_project);

	printf("\nListing Kernels/CUs found in xclbin: %s\n",bit);
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	printf("%-6s %-30s %s\n", "S.No.", "Kernel Name",
						"Kernel Instance(CU)");
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	int serial = 1;
	for (auto& xml_kernel : xml_project.get_child("project.platform.device.core")){
		if (xml_kernel.first != "kernel")
			continue;
		printf("%-6d %-30s",(serial++),xml_kernel.second.get<std::string>("<xmlattr>.name").c_str());
		//printf("%s","CU Instance: ");
		for (auto& xml_kernel_info : xml_kernel.second){
			if(xml_kernel_info.first != "instance")
				continue;
			printf("%s,",xml_kernel_info.second.get<std::string>("<xmlattr>.name").c_str());
			//printf("%-6s %-30s","","");
		}
		printf("\n\n");
	}
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	return 0;
}

int get_xclbinid(char *bdf,char* &xclbin)
{
	DIR *dr;
	char line[MAX_LINE_SIZE];char *p;
	char syspath[100] = "/sys/bus/pci/devices/";

	dr = opendir(syspath);
	if (dr == NULL)
	{
		printf("Could not open '%s' directory",syspath);
		return -1;
	}
	closedir(dr);
	strcat(syspath,bdf);
	strcat(syspath,"/xclbinuuid");
	FILE *fptr;
	if ((fptr = fopen(syspath, "r")) == NULL) {
		printf("Error! opening file");
		return -1;
	}

	fgets(line,MAX_LINE_SIZE,fptr);
	p = strtok(line,"\n");
	xclbin = new char[sizeof(line)];
	strcpy(xclbin,p);
	//printf("XCLBINuuid :%s\n",xclbin);
	//printf("%s\t",p);
	return 0;
}

int get_peer_dev(char *bdf, char* &nvme_ctrl)
{
	struct dirent *dp;
	char bdf_add[10];
	char syspath[100] = "/sys/bus/pci/devices/";
	char nvmepath[100], compath[50];
	char *array[10], *pname, nvme[10];
	int i = 0;
	DIR *dn, *dr;

	dr = opendir(syspath);
	if (dr == NULL)
	{ 
		printf("Could not open '%s' directory",syspath); 
		return -1; 
	} 

	strcpy(bdf_add,bdf);
	strcpy(nvmepath,syspath);
	while ((dp = readdir(dr)) != NULL)
		if(strstr(dp->d_name, bdf_add) != NULL){
			strcat(syspath,dp->d_name);

			realpath(syspath, compath);

			pname = strtok(compath, "/"); 
			while (pname != NULL) 
			{ 
				array[i++] = pname;
				pname = strtok(NULL, "/"); 
			} 
			strcat(nvmepath,array[i-3]);
			closedir(dr);     

			dr = opendir(nvmepath);
			if (dr == NULL)
			{ 
				return -1; 
			} 
			while ((dp = readdir(dr)) != NULL){
				if(strstr(dp->d_name, "00.0") != NULL){
					strcat(nvmepath,"/");
					strcat(nvmepath,dp->d_name);

					DIR *dn = opendir(nvmepath);
					if (dn == NULL)
					{ 
						return -1; 
					} 
					while ((dp = readdir(dn)) != NULL){
						if(strstr(dp->d_name, "00.0") != NULL){
							if(strlen(dp->d_name) < 13) {
								strcat(nvmepath,"/");
								strcat(nvmepath,dp->d_name);
								strcat(nvmepath,"/nvme");
							}
						}
					}
					closedir(dn);
				}	
			}
		}
	dn = opendir(nvmepath);
	if (dn == NULL)
	{ 
		return -1; 
	}
	while ((dp = readdir(dn)) != NULL)
		if(strlen(dp->d_name) > 3)
			sprintf(nvme,"%s",dp->d_name);
	nvme_ctrl = new char[sizeof(nvme)];
	strcpy(nvme_ctrl,nvme);
	//printf("%s\t\t",nvme);
	closedir(dn);

	closedir(dr);     
	return 0; 
}

int list_devices() {
	unsigned device_index = 0;
	unsigned devices = xclProbe();
	if(device_index >= devices) {
		printf("Cannot find device index specified\n");
		return -1;
	}

	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	printf("Total available SmartSSD devices: %d\n",devices);
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

	int ret;
	printf("%-6s %-17s %-10s %-37s %-29s %s\n", "S.No.", "FPGA PCI Address", 
						"Peer-NVME", "XCLBINUUID", "Shell", "FPGA");
	while(devices-- > 0){
		xclDeviceHandle handle;
		xclDeviceInfo2 deviceInfo;
		handle = xclOpen(device_index++, NULL, XCL_INFO);

		if (xclGetDeviceInfo2(handle, &deviceInfo)) {
			printf("Unable to obtain device information\n");
			return -1;
		}

		unsigned bdf = deviceInfo.mPciSlot;
		//printf("pcislot:%x\n",deviceInfo.mPciSlot);
		unsigned domain = (bdf >> 16) & 0xFFFF;
		unsigned bus = (bdf >> 8) & 0x00ff;
		unsigned dev = (bdf >> 3) & 0x000f;
		//unsigned x = domain<<16 | bus<<8 | dev<<3;
		unsigned func = bdf - (domain<<16 | bus<<8 | dev<<3);
		char bdfaddr[50];
		//sprintf(bdfaddr,"000%lx:%lx:0%lx.%x",domain,bus|0x00,dev|0x00,func);
		sprintf(bdfaddr,"%.4x:%.2x:%.2x.%x",domain,bus,dev,func);
		//printf("~~~~~~~~~~~~~~~~~~~~~Device %d~~~~~~~~~~~~~~~~~~~~\n",devices);
		//printf("Device %d : \n",devices);
		printf("%-6d ",device_index);
		//printf("BDF Address:%.4x:%.2x:%.2x.%x\n",domain,bus,dev,func);
		//printf("BDF Address\tNVME Controller\t(Major/Minor)\tXCLBINUUID\t\t\t\tShell\t\t\t\tFPGA\n");
		//printf("BDF Address: %s\n",bdfaddr);
		printf("%-17s ",bdfaddr);
		char *nvme;
		ret = get_peer_dev(bdfaddr,nvme);
		if(ret)
			printf("%-10s ", "NA");
		else
			printf("%-10s ", nvme);
		char *xclbin;
		ret = get_xclbinid(bdfaddr,xclbin);
		if(ret)
			printf("%-37s ", "NA");
		else
			printf("%-37s ", xclbin);
		//printf("shell name :%s fpga :%s\n",deviceInfo.mName,deviceInfo.mFpga);
		//printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
		//printf("Shell :");
		if(strlen(deviceInfo.mName)>0)
			printf("%-29s ",deviceInfo.mName);
		else
			printf("%-29s ", "NA");
		//printf("FPGA :");
		if(strlen(deviceInfo.mFpga)>0)
			printf("%s\n",deviceInfo.mFpga);
		else
			printf("NA\n");
		//printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

	}
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	return ret;

}

int usage() {
	printf("Please provide argument as:\
		\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\
		\n./xss_util <option>\
		\noption : 'list-devices', 'list-kernels' 'load-config'\
		\nlist-kernels <xclbin_path>\
		\n------------------~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	return 0;
}

int main(int argc, char **argv)
{
	if(!argv[1]) {
		usage();
		return 0;
	}
	else {
		int cmd = strcmp(argv[1],"list-devices") ? strcmp(argv[1],"list-kernels") ? strcmp(argv[1],"load-config") ?  0 : 3 : 2  : 1;
		switch(cmd) {
			case 0 : printf("Error in usage: \n"); usage(); break;
			case 1 : list_devices(); break;
			case 2 :
				 if(!argv[2]) { usage(); break; } 
				 get_kernel_names(argv[2]); break;
			case 3 : load_config(); break;
			default : usage();break;
		}
	}
	return 0;
}
