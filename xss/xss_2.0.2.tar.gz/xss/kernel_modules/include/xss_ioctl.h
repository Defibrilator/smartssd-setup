/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef XSS_INTERFACE_H
#define XSS_INTERFACE_H

#include <linux/ioctl.h>

#define XSS_INTERFACE_MAGIC 'X'

#define XSS_ADD_DEV_CU_INFO_IOCTL            _IOW( XSS_INTERFACE_MAGIC, 1,  uint)

#define MAX_STR_SIZE 30

struct arg_info{
	char name[MAX_STR_SIZE];
	size_t address_qualifier;
	size_t size;
	size_t offset;
	size_t hostoffset;
	size_t hostsize;
	int32_t ddr;
};

struct cu_info{
	char kernel_name[MAX_STR_SIZE];
	uint8_t	 cu_index;
	uint8_t  num_args;
	struct   arg_info *args;
};

struct xss_dev_cu_info{
	uint8_t major;
	uint8_t minor;
	unsigned pci_addr;
	char    peer_nvme[20];
	char	xclbin_id[100];
	uint8_t num_cus;
	struct  cu_info *cu;
};

struct xss_ioctl{
	int size;
	struct xss_dev_cu_info *dev_info;
};

#endif
