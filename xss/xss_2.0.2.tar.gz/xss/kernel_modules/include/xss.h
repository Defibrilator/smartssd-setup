/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define AES_XTS_KEY_LEN 64
#define AES_XTS_IV_LEN 16
#define BLKDEV_LEN 50

/* List of Services XSS supports */
enum XSS_SERVICES{
	XSS_SERVICE_AES_XTS_ENCRYPTION,
	XSS_SERVICE_AES_XTS_DECRYPTION,
	XSS_SERVICE_LZ4_DECOMPRESSION,
	XSS_SERVICE_LZ4_COMPRESSION,
	XSS_SERVICE_PACKER,
	MAX_XSS_SERVICES
};

/* Define buffer type passing to XSS */
typedef enum {
	KERNEL_MEMBUF_TYPE,
	SGL_TYPE
} xss_buffer_type;

/* XSS callback structure */
typedef struct xss_callback_struct {
	void *data;
	void (*func)(void *cb_data, int status);	
} xss_callback_struct;

/* XSS Cipher request structure
 * It can be used to define Encryption/decryption
 * cipher request
 */
struct xss_cipher_req {
	void		*src;
	void		*dst;
	int		datalen;
	xss_buffer_type datatype;
	uint8_t		*key;
	uint8_t		key_len;
	uint8_t		*iv;
	uint8_t		iv_len;
	bool 		encrypt;
	xss_callback_struct xss_cb;
};

/* XSS AES Context structure */
struct xss_aes_ctx {
	int			ctx_id;
	uint8_t			key_len;
	char 			blk_dev[BLKDEV_LEN];
	uint8_t			key[AES_XTS_KEY_LEN];
	struct crypto_skcipher *fallback_alg;
};

/* To verify cipher name relates to XSS */
static inline bool is_xilinx_cipher(const char *cipher_text)
{
	pr_info("%s: %s", __func__, cipher_text);
	return !strncasecmp(cipher_text, "capi:xss_", 9);
}

/* XSS compression/decompression request structure */
struct xss_compress_request {
	void 			*src;
	void 			*dst;
	int 			src_len;
	int 			*dst_len;
	int			offset;
	xss_buffer_type 	datatype;
	bool 			compress;
	xss_callback_struct 	xss_cb;
};

/* XSS Packer request structure */
struct xss_packer_request {
	void 			*src;
	void 			*dst;
	void 			*offset;
	int 			src_len;
	xss_buffer_type 	datatype;
	xss_callback_struct 	xss_cb;
};

/* This function enable allocation of p2p memory
 * (It can be used to allocate/free p2p memory)
 */
struct page* xss_alloc_p2p_page(int ctx_id, gfp_t gfp_mask);
void xss_free_p2p_page(int ctx_id, struct page *page);

/* stand alone api to just use HW aes as library to enc/dec
 * and return results to host/ p2p buffer.
 * for p2p support - leverage the p2p allocated handles
 */
int xss_crypt(int ctx_id, struct xss_cipher_req *req);

/* For the smartSSD,
 * It gives the accelerator device id associated with the NVMe device.
 */
int xss_get_peer_dev(const char * blkdev_path);

/* Creates a context on the accelerator device for an application using XSS.
 * Client is a user name for the context that can be referenced in utilities
 * dev_id - accelerator device ID
 * Services - list from the supported services
 * num_services - length of the services array.
 * retrun - handle to the context.
 */
int xss_create_ctx(const char * client, int dev_id, int services[], int num_services);

/* Delete the context created */
void xss_delete_ctx(int ctx_id);

/* To check whether a page relates to p2p allocation in a context */
bool xss_is_user_ptr_p2p(struct page *page, int ctx_id);

/* Lists the devices that support a particular service
 * (assumes that the xclbin is programmed on the device with service)
 */
int xss_get_devs_with_service(int service_id, int dev_id[]);
bool xss_is_service_avail_on_dev(int dev_id, int service_id);
int xss_get_pci_addr(int dev_id, unsigned *pci_addr);
int xss_get_dev_id(unsigned pci_addr);
