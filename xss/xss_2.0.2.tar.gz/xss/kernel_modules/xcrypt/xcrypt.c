/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/crypto.h>
#include <crypto/aes.h>
#include <crypto/algapi.h>
#include <crypto/internal/skcipher.h>
#include <xss.h>

struct xcrypt_requeue_request {
	struct	list_head list;
	struct	skcipher_request *req;
	bool	encrypt;
	struct	work_struct xss_work;
};

static void xcrypt_handle_requeue_reqs(struct work_struct *work);
void xcrypt_enqueue_request(int encrypt, struct skcipher_request *req);

static int xss_alg_skcipher_init(struct crypto_skcipher *tfm)
{
	return 0;
}

static void xss_alg_skcipher_exit(struct crypto_skcipher *tfm)
{
	struct crypto_tfm *base = crypto_skcipher_tfm(tfm);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(base);
	xss_delete_ctx(xctx->ctx_id);
}

static int xss_alg_sync_skcipher_encrypt(struct skcipher_request *req)
{
	int ret;
	struct crypto_skcipher *cipher = crypto_skcipher_reqtfm(req);
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	struct xss_cipher_req xss_req;
	xss_req.src = req->src;
	xss_req.dst = req->dst;
	xss_req.encrypt = true;
	xss_req.iv = (uint8_t *)req->iv;
	xss_req.datalen = req->cryptlen;
	xss_req.datatype = SGL_TYPE;

	xss_req.key_len = xctx->key_len;
	xss_req.key	= xctx->key;

	ret = xss_crypt(xctx->ctx_id, &xss_req);

	return ret;
}



static int xss_alg_sync_skcipher_decrypt(struct skcipher_request *req)
{
	int ret;
	struct crypto_skcipher *cipher = crypto_skcipher_reqtfm(req);
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	struct xss_cipher_req xss_req;
	xss_req.src = req->src;
	xss_req.dst = req->dst;
	xss_req.encrypt = false;
	xss_req.iv = (uint8_t *)req->iv;
	xss_req.datalen = req->cryptlen;
	xss_req.datatype = SGL_TYPE;

	xss_req.key_len = xctx->key_len;
	xss_req.key	= xctx->key;

	ret = xss_crypt(xctx->ctx_id, &xss_req);

	return ret;
}


static int xss_alg_sync_skcipher_xts_setkey(struct crypto_skcipher *cipher,
		const u8 *key, unsigned int keylen)
{
	int ret=0;
	int dev_id;
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	int services[] = {XSS_SERVICE_AES_XTS_ENCRYPTION, XSS_SERVICE_AES_XTS_DECRYPTION};

	ret = xss_get_peer_dev(xctx->blk_dev);
	if(ret < 0) {
		return ret;
	}
	dev_id = ret;

	ret = xss_create_ctx("xcrypt", dev_id, services, ARRAY_SIZE(services));
	if(ret <= 0)
        	return ret;
	xctx->ctx_id = ret;
	ret = 0;
	printk ("%s: keylen %d blkdev:%s devid:%d ctx_id:%d", __func__, keylen,xctx->blk_dev,dev_id,xctx->ctx_id);

	xctx->key_len = keylen;
	memcpy(xctx->key, key, keylen);

	return ret;
}

static void callback(void *arg, int status)
{
	struct crypto_async_request *req = (struct crypto_async_request *)arg;
	req->complete(req, !status);
}

void xcrypt_enqueue_request(int encrypt, struct skcipher_request *req)
{
	struct xcrypt_requeue_request *xcrypt_req = (struct xcrypt_requeue_request *)
					kzalloc(sizeof(struct xcrypt_requeue_request),GFP_KERNEL);;
	if(!xcrypt_req) {
		return;
	}

	xcrypt_req->req = req;
	xcrypt_req->encrypt = encrypt;

	INIT_WORK(&xcrypt_req->xss_work, xcrypt_handle_requeue_reqs);
	schedule_work(&xcrypt_req->xss_work);
}

static int xss_alg_async_skcipher_encrypt(struct skcipher_request *req)
{
	int ret;
	struct crypto_skcipher *cipher = crypto_skcipher_reqtfm(req);
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	struct xss_cipher_req xss_req;
	xss_req.src = req->src;
	xss_req.dst = req->dst;
	xss_req.encrypt = true;
	xss_req.iv = (uint8_t *)req->iv;
	xss_req.datalen = req->cryptlen;
	xss_req.datatype = SGL_TYPE;

	xss_req.xss_cb.func = (void *)callback;
	xss_req.xss_cb.data = (void *)&req->base;

	xss_req.key_len = xctx->key_len;
	xss_req.key	= xctx->key;
	ret = xss_crypt(xctx->ctx_id, &xss_req);
	if(ret == -EBUSY) {
		xcrypt_enqueue_request(true, req);
	}
	return ret;
}

static int xss_alg_async_skcipher_decrypt(struct skcipher_request *req)
{
	int ret;
	struct crypto_skcipher *cipher = crypto_skcipher_reqtfm(req);
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	struct xss_cipher_req xss_req;
	xss_req.src = req->src;
	xss_req.dst = req->dst;
	xss_req.encrypt = false;
	xss_req.iv = (uint8_t *)req->iv;
	xss_req.datalen = req->cryptlen;
	xss_req.datatype = SGL_TYPE;

	xss_req.xss_cb.func = (void *)callback;
	xss_req.xss_cb.data = (void *)&req->base;

	xss_req.key_len = xctx->key_len;
	xss_req.key	= xctx->key;

	ret = xss_crypt(xctx->ctx_id, &xss_req);
	if(ret == -EBUSY) {
		xcrypt_enqueue_request(false, req);
	}
	return ret;
}

static void xcrypt_handle_requeue_reqs(struct work_struct *work)
{
	int ret;
	struct xcrypt_requeue_request *xcrypt_req;
	xcrypt_req = container_of(work, struct xcrypt_requeue_request, xss_work);
	if(xcrypt_req->encrypt)
		ret = xss_alg_async_skcipher_encrypt(xcrypt_req->req);
	else
		ret = xss_alg_async_skcipher_decrypt(xcrypt_req->req);
	if(ret != -EBUSY) {
		skcipher_request_complete(xcrypt_req->req, ret);
	}
	kfree(xcrypt_req);
}

static int xss_alg_async_skcipher_xts_setkey(struct crypto_skcipher *cipher,
		const u8 *key, unsigned int keylen)
{
	int ret=0;
	int dev_id;
	struct crypto_tfm *tfm = crypto_skcipher_tfm(cipher);
	struct xss_aes_ctx *xctx = crypto_tfm_ctx(tfm);

	int services[] = {XSS_SERVICE_AES_XTS_ENCRYPTION, XSS_SERVICE_AES_XTS_DECRYPTION};

	ret = xss_get_peer_dev(xctx->blk_dev);
	if(ret < 0) {
		return ret;
	}
	dev_id = ret;

	ret = xss_create_ctx("xcrypt", dev_id, services, ARRAY_SIZE(services));
	if(ret <= 0)
        	return ret;
	xctx->ctx_id = ret;
	ret = 0;
	printk ("%s: keylen %d blkdev:%s devid:%d ctx_id:%d", __func__, keylen,xctx->blk_dev,dev_id,xctx->ctx_id);

	xctx->key_len = keylen;
	memcpy(xctx->key, key, keylen);

	return ret;
}


static struct skcipher_alg xss_crypto_algs[] = {
	{
		.base = {
			.cra_name = "xts(aes)",
			.cra_driver_name = "xss_aes_xts",
			.cra_priority = 500,
			.cra_flags = CRYPTO_ALG_TYPE_SKCIPHER,
			.cra_blocksize = AES_BLOCK_SIZE,
			.cra_ctxsize = sizeof(struct xss_aes_ctx),
			.cra_alignmask = 0,
			.cra_module = THIS_MODULE,
		},
		.setkey = xss_alg_sync_skcipher_xts_setkey,
		.decrypt = xss_alg_sync_skcipher_decrypt,
		.encrypt = xss_alg_sync_skcipher_encrypt,
		.min_keysize = 2 * AES_MIN_KEY_SIZE,
		.max_keysize = 2 * AES_MAX_KEY_SIZE,
		.ivsize = AES_BLOCK_SIZE,
		.init = xss_alg_skcipher_init,
		.exit = xss_alg_skcipher_exit,
	}, {
		.base = {
			.cra_name = "xts(aes)",
			.cra_driver_name = "xss_aes_xts_async",
			.cra_priority = 500,
			.cra_flags = CRYPTO_ALG_TYPE_SKCIPHER|CRYPTO_ALG_ASYNC,
			.cra_blocksize = AES_BLOCK_SIZE,
			.cra_ctxsize = sizeof(struct xss_aes_ctx),
			.cra_alignmask = 0,
			.cra_module = THIS_MODULE,
		},
		.init = xss_alg_skcipher_init,
		.exit = xss_alg_skcipher_exit,
		.setkey = xss_alg_async_skcipher_xts_setkey,
		.decrypt = xss_alg_async_skcipher_decrypt,
		.encrypt = xss_alg_async_skcipher_encrypt,
		.min_keysize = 2 * AES_MIN_KEY_SIZE,
		.max_keysize = 2 * AES_MAX_KEY_SIZE,
		.ivsize = AES_BLOCK_SIZE,
	}
};

int xss_crypt_init(void)
{
	int ret=0;
	ret = crypto_register_skciphers(xss_crypto_algs,
                       ARRAY_SIZE(xss_crypto_algs));

	return ret;
}

void xss_crypt_exit(void)
{
	printk ("%s", __func__);
	crypto_unregister_skciphers(xss_crypto_algs,
			ARRAY_SIZE(xss_crypto_algs));
}

module_init(xss_crypt_init);
module_exit(xss_crypt_exit);
MODULE_LICENSE("GPL");
