/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/cdev.h>
#include <linux/ratelimit.h>

#include <drm/drmP.h>
#include <drm/drm_file.h>
#include <drm/drm_drv.h>
#include <drm/drm_ioctl.h>

#include <xrt_mem.h>
#include <ert.h>
#include "xocl_ioctl.h"

#include "xss_internal.h"
#include "../include/xss_ioctl.h"
#include "../include/xss.h"
#include "xss_kernel_arg.h"
#include "xss_services.h"

static DEFINE_RATELIMIT_STATE(ratelimit_state, 2 * HZ, 2);

#define SGL_BO_ARG_SIZE 4096
#define EXEC_BO_ARG_SIZE 4096

struct p2p_page_node {
	struct list_head list;
	struct page *page;
};

static dev_t dev;
static struct cdev c_dev;
static struct class *cl;

static bool force_sync_dma = false;

struct workqueue_struct *xss_exec_wq;
atomic_t num_completions;
atomic_t num_active_devs;

struct xss_kernel_info supported_kernels[MAX_KERNELS] = {
	{
		.kernel_name = "fa_aes_xts2_rtl_enc",
		.num_kargs = MAX_AES_XTS_ARGS,
		.kargs = { AES_XTS_ENC_ARGS },
	},
	{
		.kernel_name = "fa_aes_xts2_rtl_dec",
		.num_kargs = MAX_AES_XTS_ARGS,
		.kargs = { AES_XTS_DEC_ARGS },
	},
        {
                .kernel_name = "xilLz4Decompress",
                .num_kargs = MAX_LZ4_DECOMPRESS_ARGS,
                .kargs = { LZ4_DECOMPRESS_ARGS },
        },
	{
#ifdef XSS_FA_BASED_KERNEL
                .kernel_name = "xilLz4Compress_fa",
#else
                .kernel_name = "xilLz4Compress",
#endif
                .num_kargs = MAX_LZ4_COMPRESS_ARGS,
                .kargs = { LZ4_COMPRESS_ARGS },
        },
	{
#ifdef XSS_FA_BASED_KERNEL
                .kernel_name = "xilPacker_fa",
#else
                .kernel_name = "xilPacker",
#endif
                .num_kargs = MAX_PACKER_ARGS,
                .kargs = { PACKER_ARGS },
        }
};

static struct xss_service supported_services[] =  {
	{ AES_XTS_ENCR_SERVICE }, 
	{ AES_XTS_DECR_SERVICE },
        { LZ4_DECOMPRESS_SERVICE },
	{ LZ4_COMPRESS_SERVICE },
	{ PACKER_SERVICE },
};

static struct xss_context xss_ctx_list[MAX_XSS_CTX];

struct xss_list xss_devices;

static void xss_exec_cb_func(unsigned long data, int err);
static void xss_callback_func(unsigned long data, int err);
static void xss_close_service_cus(struct xss_context *ctx);

static void xss_list_init(struct xss_list *list)
{
	INIT_LIST_HEAD(&list->list);
	spin_lock_init(&list->lock);
}

static struct drm_file_info* xss_drm_open (dev_t drm_dev_t)
{
	int err;
	struct drm_file_info *drm_file;

	drm_file = kzalloc(sizeof(struct drm_file_info), GFP_KERNEL);
	if (!drm_file) {
		return NULL;
	}


	drm_file->inode = kzalloc(sizeof(struct inode), GFP_KERNEL);
	if (!drm_file->inode) {
		goto err;
	}

	drm_file->inode->i_rdev = drm_dev_t;

	drm_file->filp = kzalloc(sizeof(struct file), GFP_KERNEL);
	if (!drm_file->filp) {
		goto err_inode;
	}

	err = drm_open(drm_file->inode, drm_file->filp);
	if (err) {
		pr_err("%s: drm_open Error %d", __func__, err);
		goto err_filp;
	}

	return drm_file;

err_filp:
	kfree(drm_file->filp);
err_inode:
	kfree(drm_file->inode);
err:
	kfree(drm_file);
	return NULL;
}

static int invoke_drm_ioctl(struct drm_file_info *drm_file, int ioctl_cmd, void *arg)
{
	uint32_t nr = _IOC_NR(ioctl_cmd);
	const struct drm_ioctl_desc *ioctl = NULL;

	struct drm_file *file = drm_file->filp->private_data;
	struct drm_device *drm_dev = file->minor->dev;

	uint32_t index = nr - DRM_COMMAND_BASE;

	ioctl = &drm_dev->driver->ioctls[index];
	return drm_ioctl_kernel(drm_file->filp, ioctl->func, 
			arg, ioctl->flags);
}

static int xss_open_xrt_ctx(struct drm_file_info *drm_file, const uuid_t xclbin_id, 
		uint32_t cu_index, bool shared) 
{
	struct drm_xocl_ctx ctx_arg;

	memset(&ctx_arg, 0, sizeof(ctx_arg));

	memcpy(&ctx_arg.xclbin_id, &xclbin_id, sizeof(uuid_t));
	ctx_arg.op = XOCL_CTX_OP_ALLOC_CTX;
	ctx_arg.cu_index = cu_index;
	ctx_arg.flags = shared ? XOCL_CTX_SHARED : XOCL_CTX_EXCLUSIVE;

	return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_CTX, &ctx_arg);
}

static int xss_close_xrt_ctx(struct drm_file_info *drm_file, const uuid_t xclbin_id, 
		uint32_t cu_index) 
{
	struct drm_xocl_ctx ctx_arg;

	memset(&ctx_arg, 0, sizeof(ctx_arg));

	memcpy(&ctx_arg.xclbin_id, &xclbin_id, sizeof(uuid_t));
	ctx_arg.op = XOCL_CTX_OP_FREE_CTX;
	ctx_arg.cu_index = cu_index;

	return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_CTX, &ctx_arg);
}

static void xss_drm_release (struct drm_file_info *drm_file)
{
	pr_info("%s", __func__);
	if (drm_file && drm_file->inode 
			&& drm_file->filp) {
		drm_release(drm_file->inode, drm_file->filp);
		kfree(drm_file->filp);
		kfree(drm_file->inode);
		kfree(drm_file);
	}
	else {
		pr_info("Error: Invalid drm file :%s", __func__);
	}

}

static inline uint64_t xss_get_bo_paddr(struct drm_file_info *drm_file, uint32_t bo_handle) 
{
	int ret = 0;
	struct drm_xocl_info_bo info_bo_arg;

	memset(&info_bo_arg, 0, sizeof(struct drm_xocl_info_bo));

	info_bo_arg.handle = bo_handle;
	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_INFO_BO, 
			&info_bo_arg);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return ret;
	}
	return info_bo_arg.paddr;
}

static inline int xss_get_bo_size(struct drm_file_info *drm_file, uint32_t bo_handle) 
{
	int ret = 0;
	struct drm_xocl_info_bo info_bo_arg;

	memset(&info_bo_arg, 0, sizeof(struct drm_xocl_info_bo));

	info_bo_arg.handle = bo_handle;
	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_INFO_BO, 
			&info_bo_arg);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return ret;
	}

	return info_bo_arg.size;
}

void* xss_get_bo_kernel_vaddr (struct drm_file_info *drm_file, uint32_t bo_handle)
{
	int ret=0;
	struct drm_xocl_kinfo_bo bo_kvirt;

	bo_kvirt.handle = bo_handle;

	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_KINFO_BO, &bo_kvirt);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return NULL;
	}

	return (void *)bo_kvirt.vaddr;

}

int xss_create_bo(struct drm_file_info *drm_file, uint32_t* bo_handle, uint64_t* bo_paddr, 
		int ddr, uint32_t bo_size)
{
	int ret=0;
	struct drm_xocl_create_bo create_bo_arg;

	memset(&create_bo_arg, 0, sizeof(create_bo_arg));
	create_bo_arg.size = bo_size;
	create_bo_arg.flags = XCL_BO_FLAGS_DEV_ONLY | ddr;

	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_CREATE_BO, 
			&create_bo_arg);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return ret;
	}

	*bo_handle = create_bo_arg.handle;
	*bo_paddr  = xss_get_bo_paddr(drm_file, *bo_handle);

	return 0;
}

int xss_create_exec_bo(struct drm_file_info *drm_file, uint32_t* bo_handle, uint64_t* bo_vaddr, 
		uint32_t size)
{
	struct drm_xocl_create_bo create_bo_arg;
	int ret=0;

	//create execbuf
	create_bo_arg.size = size;
	create_bo_arg.flags = XCL_BO_FLAGS_EXECBUF;

	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_CREATE_BO, 
			&create_bo_arg);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return ret;
	}

	*bo_handle = create_bo_arg.handle;
	*bo_vaddr  = (u64)xss_get_bo_kernel_vaddr(drm_file, *bo_handle);
	return 0;
}

int xss_create_p2p_bo(struct drm_file_info *drm_file, uint32_t* bo_handle, uint64_t* bo_paddr, 
		uint32_t bo_size)
{
	struct drm_xocl_create_bo  create_bo_arg;
	int ret=0;

	//create P2P BO
	create_bo_arg.size    = bo_size;
	create_bo_arg.flags   = XCL_BO_FLAGS_P2P;

	ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_CREATE_BO, 
			&create_bo_arg);
	if (ret) {
		pr_err("%s: Error ", __func__);
		return ret;
	}

	*bo_handle = create_bo_arg.handle;
	*bo_paddr  = xss_get_bo_paddr(drm_file, *bo_handle);

	return 0;
}

int xss_remap_kmem_bo(struct drm_file_info *drm_file, uint32_t bo_handle, void *kern_addr)
{
	struct drm_xocl_map_kern_mem kmem_bo;

	kmem_bo.addr = (uint64_t)kern_addr;
	kmem_bo.flags = XCL_BO_FLAGS_KERNBUF;
	kmem_bo.handle = bo_handle;

	return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_MAP_KERN_MEM, 
			&kmem_bo);
}

int xss_remap_sgl_bo(struct drm_file_info *drm_file, uint32_t bo_handle, void *sgl_addr)
{
	struct drm_xocl_map_kern_mem sgl_bo;

	sgl_bo.addr = (uint64_t)sgl_addr;
	sgl_bo.flags = XCL_BO_FLAGS_SGL;
	sgl_bo.handle = bo_handle;

	return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_MAP_KERN_MEM, 
			&sgl_bo);
}

int xss_migrate_bo(struct drm_file_info *drm_file, uint32_t bo_handle, int size, 
		enum drm_xocl_sync_bo_dir dir, 
		int offset, void *cb_ctx)
{
	struct drm_xocl_sync_bo_cb bo_arg;

	memset(&bo_arg, 0, sizeof(bo_arg));
	bo_arg.handle = bo_handle;
	bo_arg.flags = 0;
	bo_arg.size = size;
	bo_arg.offset = offset;
	bo_arg.dir = dir;

	if(cb_ctx) {
		bo_arg.cb_func = (uint64_t)xss_callback_func; 
		bo_arg.cb_data = (uint64_t)cb_ctx; 

		return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_SYNC_BO_CB, 
			&bo_arg);
	}
	else
		return invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_SYNC_BO,
                        &bo_arg);
}

int xss_trigger_hwfunc(struct drm_file_info *drm_file, uint32_t exec_handle,
				uint64_t exec_vaddr, void *callback, void* ctx, 
				int cu_index)
{
        int ret=0;
        int count=0;
        struct ert_start_kernel_cmd *ert_packet;
        struct drm_xocl_execbuf_cb execbuf;

        ert_packet = (struct ert_start_kernel_cmd *) exec_vaddr;
        if (ert_packet == NULL) {
                pr_info("%s: Error for exec bo: %d", __func__, exec_handle);
                return -EFAULT;
        }

        memset(&execbuf, 0, sizeof(execbuf));
        execbuf.cb_func = (u64)callback;
        execbuf.cb_data = (uint64_t)ctx;
        execbuf.exec_bo_handle = exec_handle;

        ret = invoke_drm_ioctl(drm_file, DRM_IOCTL_XOCL_EXECBUF_CB,
                        &execbuf);
        if (ret) {
                pr_err("%s: Error ", __func__);
                return ret;
        }

        if (!ctx) {
                while ((ert_packet->state < ERT_CMD_STATE_COMPLETED)
                                && count++ < 5000)
                        udelay(500);

                if (ert_packet->state < ERT_CMD_STATE_COMPLETED) {
                        pr_err("%s: cmd BO %d (status %d) could not complete \
                                        in stipulated time!", __func__,
                                        execbuf.exec_bo_handle, ert_packet->state);
                        ret= -1;
                }
        }
	return ret;
}

/*
int find_same_dir_bos_after(int i, struct xss_request *req, int dir)
{
	int count = 0;
	int bo_count = req->num_bos;
	struct xss_bo **bo_list = req->bo_list;

	int expected_type = (dir == SYNC_INPUT) ? XSS_BO_TYPE_INPUT : 
						XSS_BO_TYPE_OUTPUT;

	for (i++;i<bo_count; i++)
		if (bo_list[i]->type & expected_type)
			count++;

	return count;
}
*/
int xss_remap_request_bos(struct xss_request *req)
{
	int i;
	int ret=0;
	int bo_count = req->num_bos;
	struct xss_bo **bo_list = req->bo_list;
	struct xss_bo *bo;
	struct xss_context *ctx = req->ctx;

	for (i=0; i<bo_count; i++)
	{
		bo = bo_list[i];

		if (!bo->uaddr 
			|| (bo->type & XSS_BO_TYPE_EXEC)
			|| (bo->type & XSS_BO_TYPE_P2P)
			|| (bo->type & XSS_BO_TYPE_INTERNAL))
			continue;

		if (bo->type & XSS_BO_TYPE_SGL)
			ret = xss_remap_sgl_bo(ctx->drm_file, bo->handle, 
							(void*)bo->uaddr);
		else if (bo->type & XSS_BO_TYPE_BUF)
			ret = xss_remap_kmem_bo(ctx->drm_file, bo->handle, 
							(void*)bo->uaddr);
		
		if (ret < 0) {
			pr_info("%s: %d", __func__, ret);
			//print_bo(bo);
			return -EFAULT;
		}
	}
	return 0;
}

int xss_sync_request_bos(struct xss_request *req, int dir)
{
	int i;
	int ret=0;
	int num_transfers = 0;
	int bo_count = req->num_bos;
	struct xss_bo **bo_list = req->bo_list;
	struct xss_bo *bo;
	struct xss_context *ctx = req->ctx;

	for (i=req->private+1; i<bo_count; i++)
	{
		bo = bo_list[i];

		if (!bo->uaddr 
			|| (bo->type & XSS_BO_TYPE_EXEC)
			|| (bo->type & XSS_BO_TYPE_P2P)
			|| (bo->type & XSS_BO_TYPE_INTERNAL)
			|| ((bo->type & XSS_BO_TYPE_INPUT) 
				&& (dir == SYNC_OUTPUT))
			|| ((bo->type & XSS_BO_TYPE_OUTPUT) 
				&& (dir == SYNC_INPUT)))
			continue;

		num_transfers++;
		if (IS_ASYNC_REQ(req) && !force_sync_dma) {
			ret = xss_migrate_bo(ctx->drm_file, bo->handle,
						bo->size, dir, bo->offset, req);
			req->private = i;
			break;	
		}
		else	
			ret = xss_migrate_bo(ctx->drm_file, bo->handle, 
						bo->size, dir, bo->offset, NULL);
		if (ret < 0) {
			pr_info("%s: %d %d", __func__, ret, dir);
			//print_bo(bo);
			return -EFAULT;
		}
		//pr_info("%s:%d %d %llx %x %llx %d done", __func__, i, 
		//	bo->handle, bo->paddr, bo->type, bo->addr, dir);
	}

	//return (num_transfers + find_same_dir_bos_after(i, req, dir));
	return num_transfers;
}

int xss_execute_request(struct xss_request *req)
{
	int ret=0;
	struct xss_context *ctx = req->ctx;
	struct xss_bo *bo = req->bo_list[0];

	if (atomic_fetch_add(1, &ctx->device->inflight_execs) == 0)
		atomic_inc(&num_active_devs);

	ret = xss_trigger_hwfunc(ctx->drm_file, bo->handle, bo->vaddr, 
					xss_exec_cb_func, req, req->cu_index);
	if (ret < 0) {
		pr_info("%s: exec %d %llx %x %llx", __func__, 
				bo->handle, bo->vaddr, bo->type, bo->uaddr);
		return -EFAULT;
	}
	return ret;
}

int xss_submit_request(struct xss_request *req)
{
	int ret = 0;

	if ((ret = xss_remap_request_bos(req)) < 0)
		return ret;

	req->private = 0;
	req->state = XSS_STATE_INPUT_TX;
	if ((ret = xss_sync_request_bos(req, SYNC_INPUT))<0)
		return ret;

	/* For asynchronous mode, if an asynchronous input transfer 
	   has been submitted, the function can return*/
	if (IS_ASYNC_REQ(req) && (ret > 0) && !force_sync_dma)
		return 0;

	req->state = XSS_STATE_COMPUTE;
	if ((ret = xss_execute_request(req)) < 0)
		return ret;

	/* For asynchronous mode, we reach here if there was no 
	   asynchronous input transfer submitted, now that the 
	   compute request was submitted,  the function can return*/
	if (IS_ASYNC_REQ(req))
		return ret;

	req->state = XSS_STATE_OUTPUT_TX;
	return xss_sync_request_bos(req, SYNC_OUTPUT);
}

static void xss_exec_compltn_worker(struct work_struct *work)
{
	struct xss_request *req = container_of(work, struct xss_request, xss_work);
	xss_callback_func((unsigned long)req, 0);
}

inline static int get_cpu_for_exec_cmpltn(int num_active_devs)
{
	int num_cpus = min_t(unsigned, num_present_cpus(), (num_active_devs << 1)); 
	/* Using CPU 4 onwards for exec completions since first 4 CPUs 
         * may be used by XDMA. The number of CPUs used depends on number
	 * number of active devices. 2 CPUs are used per device for execbuf
	 * completions.
	 */
	return (4 + (atomic_fetch_add(1, &num_completions) % num_cpus));
}

static void xss_exec_cb_func(unsigned long data, int err)
{
	struct xss_request *req = (struct xss_request *)data;
	struct xss_context *ctx = req->ctx;
	int active_devs = atomic_read(&num_active_devs);

	if (err < 0) {
		pr_err("%s: exec-cmd failed! %d", __func__, err);
		req->complete(req, err);
		return;
	}

	if (!active_devs) {
		pr_err("%s: UNLIKELY EVENT: num active devs = 0" 
				"on exec completions!", __func__);
		req->complete(req, -EFAULT);
		return;
	}

	INIT_WORK(&req->xss_work, xss_exec_compltn_worker);
	queue_work_on(get_cpu_for_exec_cmpltn(active_devs), xss_exec_wq, &req->xss_work);

	if (atomic_sub_return(1, &ctx->device->inflight_execs) == 0)
		atomic_dec(&num_active_devs);

}

static void xss_callback_func(unsigned long data, int err)
{
	int ret=0;
	struct xss_request *req = (struct xss_request *)data;

	switch (req->state) {
	case XSS_STATE_INPUT_TX:
#ifdef XSS_TRACE_TIME
		do_gettimeofday(&req->input_tv);
#endif
		if (req->dma_cb)
			req->dma_cb(req, req->private);

		/* Sync the next Input BO, if any*/
		if ((ret = xss_sync_request_bos(req, SYNC_INPUT)) < 0)
			goto out;

		/* There may be more BOs to be synced */
		if (ret > 0)
			break;
			
		/* ret=0 means no more input bo to sync, 
		   time to send the execbuf */
		req->state = XSS_STATE_COMPUTE;
		if ((ret = xss_execute_request(req)) < 0)
			goto out;
		/* execbuf sent */
		break;

	case XSS_STATE_COMPUTE:
#ifdef XSS_TRACE_TIME
		do_gettimeofday(&req->compute_tv);
#endif
		/*Execbuf completed*/
		if (req->exec_cb)
			req->exec_cb(req, err);

		/* Start op status */
		req->private = 0;
		req->state = XSS_STATE_OUTPUT_TX;
		if ((ret = xss_sync_request_bos(req, SYNC_OUTPUT))< 0)
			goto out;

		if ((ret == 0) || force_sync_dma)
			req->complete(req, ret);
	
		break;

	case XSS_STATE_OUTPUT_TX:
		if (req->dma_cb)
			req->dma_cb(req, req->private);

		/* Sync the next Input BO, if any*/
		if ((ret = xss_sync_request_bos(req, SYNC_OUTPUT)) < 0)
			goto out;

		/* There may be more BOs to be synced */
		if (ret > 0)
			break;
		/* All done time to complete the request*/	
		req->complete(req, ret);
		break;

	default:
		ret = -EINVAL;
		break;
	}
	return;
out:
	req->complete(req, ret);
}

/* xss performance status */
static struct xss_perf_stats perf_stats[5];

int xss_get_perf_stats (struct xss_perf_stats **xss_stats)
{
	*xss_stats = perf_stats;
	return 5;
}

inline uint64_t time_diff(struct timeval tv2, struct timeval tv1)
{
	uint64_t diff = (((tv2.tv_sec - tv1.tv_sec) * 1000000) 
			+ (tv2.tv_usec - tv1.tv_usec));
	return diff;
}

struct xss_bo* xss_get_bo(struct list_head *bo_list)
{
	struct xss_bo *bo = list_first_entry_or_null(bo_list, struct xss_bo, list);
	if (!bo)
		return NULL;
	list_del(&bo->list);
	return bo;
}

bool is_user_ptr_p2p(struct page *page, struct xss_context *ctx, struct xss_bo **p2p_bo)
{
	int i;
	struct xss_bo *ctx_bo;
	void* page_vaddr = page_to_virt(page);
	for (i=0;i<ctx->num_services; i++) {
		ctx_bo = &ctx->p2p_bo[i];
		//pr_info("%s: i:%d page %llx vaddr %llx (%llx %llx)", __func__,i, (u64)page, 
		//	(u64)page_vaddr, (u64)ctx_bo->vaddr,
		//  	(u64)(ctx_bo->vaddr + ctx_bo->size));
		if ((page_vaddr >= (void *)ctx_bo->vaddr) &&
				(page_vaddr < ((void *)ctx_bo->vaddr + ctx_bo->size))) {
			*p2p_bo = ctx_bo;
			return true;
		}
	}

	return false;
}

bool xss_is_user_ptr_p2p(struct page *page, int ctx_id)
{
	struct xss_context *ctx = xss_get_ctx_struct(ctx_id);
	bool ret;
	struct xss_bo *p2p_bo;

	ret = is_user_ptr_p2p(page, ctx, &p2p_bo);
        return ret;
}
EXPORT_SYMBOL_GPL(xss_is_user_ptr_p2p);

int get_p2p_page_offset(struct page *page, struct xss_bo *p2p_bo)
{
	void* page_vaddr = page_to_virt(page);
	//pr_info("%s: page %llx", __func__,(u64)page);
	return page_vaddr - (void *)p2p_bo->vaddr;
}


int xss_service_offset_in_ctx(struct xss_context *ctx, int svc_id)
{
	int i;
	for (i=0; i<ctx->num_services;i++)
		if (ctx->svc_ids[i] == svc_id)
			return i;
	return -EINVAL;
}

int xss_get_service_cu(struct xss_context *ctx, int svc_offset, int kernel_id)
{
	int i;
	int service_cu;
	struct dev_service_info *svc_info = ctx->dev_svc_ref[svc_offset];
	struct service_kernel *svc_kernel = NULL; 
	int num_svc_kernels = supported_services[svc_info->service_id].num_kernels;
	int service_count = atomic_fetch_add(1, &svc_info->service_counter);

	for (i=0; i<num_svc_kernels;i++) {
		svc_kernel = &svc_info->service_kernels[i];
		if (svc_kernel->kernel_id == kernel_id)
			break;
	}

	if (i == num_svc_kernels)
		return -EINVAL;

	service_cu = service_count % svc_kernel->num_cus;

	return svc_kernel->cus[service_cu]->cu_index;
}


static void xss_delete_p2p_pglist(struct xss_context *ctx);

void xss_free_p2p_page(int ctx_id, struct page *page)
{
	struct p2p_page_node *page_node = (struct p2p_page_node *) page->private;
	unsigned long flags;
	struct xss_context *ctx;
	struct xss_list *p2p_pglist;

	if (!ctx_id) {
		pr_err("%s: Invalid ctx id %d ", __func__, ctx_id);
		return;
	}
	ctx = xss_get_ctx_struct(ctx_id);
	p2p_pglist = &ctx->p2p_mem_pages;

	spin_lock_irqsave(&p2p_pglist->lock, flags);
	list_add_tail(&page_node->list, &p2p_pglist->list);
	spin_unlock_irqrestore(&p2p_pglist->lock, flags);

	atomic_dec(&ctx->p2p_use_count);
	if (!ctx->in_use && !atomic_read(&ctx->p2p_use_count)) {
		xss_delete_p2p_pglist(ctx);
		xss_close_service_cus(ctx);
		xss_drm_release(ctx->drm_file);
		memset(ctx, 0, sizeof(struct xss_context));
	}
}
EXPORT_SYMBOL_GPL(xss_free_p2p_page);

struct page* xss_alloc_p2p_page(int ctx_id, gfp_t gfp_mask)
{
	struct p2p_page_node * page_node;
	unsigned long flags;
	struct xss_context *ctx;
	struct xss_list *p2p_pglist;
	if (!ctx_id) {
		pr_err("%s: Invalid ctx id %d ", __func__, ctx_id);
		return NULL;
	}
	ctx = xss_get_ctx_struct(ctx_id);
	p2p_pglist = &ctx->p2p_mem_pages;
	spin_lock_irqsave(&p2p_pglist->lock, flags);
	page_node = list_first_entry_or_null(&p2p_pglist->list, 
			struct p2p_page_node, list);
	if(!page_node) {
		if (__ratelimit(&ratelimit_state))
			printk("%s: no p2p page available in free list!", __func__);
		spin_unlock_irqrestore(&p2p_pglist->lock, flags);
		return NULL;
	}
	list_del(&page_node->list);
	spin_unlock_irqrestore(&p2p_pglist->lock, flags);
	/*pr_info("%s: page %llx page_node: %llx", __func__,
		(u64)page_node->page, (u64)page_node);*/
	atomic_inc(&ctx->p2p_use_count);

	return page_node->page;

}
EXPORT_SYMBOL_GPL(xss_alloc_p2p_page);

static int add_to_free_p2p_pglist(struct xss_context *ctx, void* bo_vaddr, int size)
{
	unsigned long flags;
	struct page* page;
	struct xss_list *p2p_pglist = &ctx->p2p_mem_pages;

	while(size > 0){
		struct p2p_page_node *page_node = (struct p2p_page_node *) 
			kzalloc(sizeof(struct p2p_page_node), GFP_KERNEL);
		if(!page_node){
			pr_info("%s: page-node alloc failed!", __func__);
			return -ENOMEM;
		}
		page = virt_to_page(bo_vaddr);
		page_node->page = page;
		page->private = (uint64_t)page_node;
		/*pr_info("%s: page %llx vaddr: %llx", __func__, 
		  (u64)page, (u64)bo_vaddr);*/

		spin_lock_irqsave(&p2p_pglist->lock, flags);
		list_add_tail(&page_node->list, &p2p_pglist->list);
		spin_unlock_irqrestore(&p2p_pglist->lock, flags);

		bo_vaddr += PAGE_SIZE;
		size     -= PAGE_SIZE;
	}
	return 0;
}

static void xss_delete_p2p_pglist(struct xss_context *ctx)
{
	unsigned long flags;
	struct p2p_page_node *page_node;
	struct list_head *pos, *next;
	struct xss_list *p2p_pglist = &ctx->p2p_mem_pages;

	spin_lock_irqsave(&p2p_pglist->lock, flags);
	list_for_each_safe(pos, next, &p2p_pglist->list){
		page_node = list_entry(pos, struct p2p_page_node, list);
		page_node->page->private=0;
		list_del(pos);
		kfree(page_node);
	}
	spin_unlock_irqrestore(&p2p_pglist->lock, flags);
}


int xss_proc_init(void);
void xss_proc_exit(void);

static bool find_necessary_cus_for_service(struct xss_service* service, 
		struct xss_device* xss_dev)
{
	int k_idx, cu_idx;
	struct xss_kernel_info *kernel;
	struct cu_info *dev_cu;
	struct cu_info *dev_cu_list = xss_dev->cu_list;
	struct dev_service_info *service_info;
	struct service_kernel *svc_kernel;

	int svc_num_kernels = service->num_kernels;
	int dev_num_cus = xss_dev->num_valid_cus;


	service_info = &xss_dev->service_list[xss_dev->num_services]; 
	service_info->service_id = service->svc_id;

	for(k_idx=0; k_idx<svc_num_kernels; k_idx++) {
		kernel = &supported_kernels[service->kernels[k_idx]];
		for(cu_idx=0; cu_idx<dev_num_cus; cu_idx++) {
			dev_cu = &dev_cu_list[cu_idx];
			if (strstr(kernel->kernel_name, dev_cu->kernel_name)) {
			/* found a matching kernel type CU in the list*/
				pr_info("%s: Adding Kernel:%s CU: %d to service:%d ", 
					__func__, kernel->kernel_name, dev_cu->cu_index,
					service_info->service_id);
				/* Add the CU's info to the corresponding service info 
				   on the device*/
				svc_kernel = &service_info->service_kernels[k_idx];
				svc_kernel->cus[svc_kernel->num_cus] = dev_cu;
				svc_kernel->kernel_id = service->kernels[k_idx];
				svc_kernel->num_cus++;
			}
		}
	}
	/* check if atleast one CU is found for each kernel type required
	   for the service */
	for(k_idx=0; k_idx<service->num_kernels; k_idx++) {
		if (!service_info->service_kernels[k_idx].num_cus) {
			/*if a CU could not be found in the device
			  for any of the kernel type of the service,
			  the device cannot support that service*/
			memset(service_info, 0, sizeof(*service_info));
			return false;
		}
	}
	pr_info("%s: Adding service %d  to device: %d",__func__, 
			service_info->service_id, xss_dev->dev_id);
	xss_dev->num_services++;
	return true;
}

int is_xss_dev_available(unsigned pci_addr)
{
	unsigned long flags;
        struct xss_device *xss_dev;

        spin_lock_irqsave(&xss_devices.lock, flags);
        list_for_each_entry(xss_dev, &xss_devices.list, list) {
                if(xss_dev->pci_addr == pci_addr) {
        		spin_unlock_irqrestore(&xss_devices.lock, flags);
                        return -EEXIST;
		}
        }
        spin_unlock_irqrestore(&xss_devices.lock, flags);
	return 0;
}

static void xss_discover_services(struct xss_device *xss_dev)
{
	int svc_idx;
	struct xss_service *service;

	for(svc_idx=0; svc_idx < ARRAY_SIZE(supported_services); svc_idx++) {
		service = &supported_services[svc_idx];
		find_necessary_cus_for_service(service, xss_dev);
	}
	pr_info("%s: num_services:%d", __func__, xss_dev->num_services);
}

static bool is_xss_recognized_kernel(struct cu_info *cu)
{
	int k_idx;
	int arg_idx = 0;

	for(k_idx=0; k_idx < MAX_KERNELS; k_idx++) {
		struct xss_kernel_info *kernel = &supported_kernels[k_idx];

		if (!strstr(kernel->kernel_name, cu->kernel_name))
			continue;

		if (cu->num_args != kernel->num_kargs)
			continue;

		while(arg_idx < cu->num_args) {
			struct arg_info *cu_arg = &cu->args[arg_idx];
			struct kernel_args *kernel_arg = &kernel->kargs[arg_idx];

			if(strcmp(cu_arg->name, kernel_arg->name)!=0)
				break;
			if (cu_arg->size != kernel_arg->size)
				break;
			if (cu_arg->offset != kernel_arg->offset)
				break;
			arg_idx++;
		}


		if (arg_idx < cu->num_args)
			continue;
		else
			return true;
	}

	return false;
}

static int xss_init_dev_with_udata(void __user *udata, struct xss_device *xss_dev)
{
	struct xss_ioctl ioctl_data;
	struct xss_dev_cu_info dev_cu_info;

	int cu_idx;
	int valid_cu_idx = 0;

	if(copy_from_user(&ioctl_data, udata, sizeof(struct xss_ioctl))){
		pr_err("%s: ioctl_data copy_from_user failed.\n",__func__);
		return -EFAULT;
	}

	if(copy_from_user(&dev_cu_info, ioctl_data.dev_info,
				sizeof(struct xss_dev_cu_info))){
		pr_err("%s: dev_info copy_from_user failed.\n",__func__);
		return -EFAULT;
	}

	xss_dev->drm_dev_t = MKDEV(dev_cu_info.major, 
			dev_cu_info.minor);

	if(is_xss_dev_available(dev_cu_info.pci_addr)) {
		return -EEXIST;
	}

	xss_dev->pci_addr = dev_cu_info.pci_addr;
	strcpy(xss_dev->peer_nvme,dev_cu_info.peer_nvme);

	pr_info("%s: %s %d %d %d %x %s", __func__, dev_cu_info.xclbin_id, 
			dev_cu_info.major, dev_cu_info.minor, dev_cu_info.num_cus, 
			dev_cu_info.pci_addr, dev_cu_info.peer_nvme);

	uuid_parse(dev_cu_info.xclbin_id, &xss_dev->xclbin_id);

	for (cu_idx = 0; cu_idx < dev_cu_info.num_cus; cu_idx++) {
		struct cu_info *cu = &xss_dev->cu_list[valid_cu_idx];
		struct arg_info *args;

		if(copy_from_user(cu, &dev_cu_info.cu[cu_idx], 
					sizeof(struct cu_info))!=0){

			pr_err("%s cu copy_from_user failed.\n",__func__);
			return -EFAULT;
		}

		pr_info("%s: %s %d", __func__, cu->kernel_name, cu->num_args); 
		args = kmalloc(cu->num_args * sizeof(struct arg_info), 
				GFP_KERNEL);

		if(copy_from_user(args, cu->args, cu->num_args * 
					sizeof(struct arg_info))!=0){

			pr_err("%s cu copy_from_user failed.\n",__func__);
			kfree(args);
			return -EFAULT;
		}

		cu->args = args;

		if (is_xss_recognized_kernel(cu)) {
			pr_info("%s: valid cu:%s", __func__, cu->kernel_name);
			valid_cu_idx++;
		}

	}

	xss_dev->num_valid_cus = valid_cu_idx;
	return 0;
}

static int xss_add_dev_cu_info(void __user *udata)
{
	int ret = 0;
	unsigned long flags;

	// Allocate a xss_device opbject
	struct xss_device *xss_dev = (struct xss_device *)
		kmalloc(sizeof(struct xss_device), GFP_KERNEL);
	if (!xss_dev) {
		pr_err("%s: No memory to allocate xss_device!", __func__);
		return -ENOMEM;
	}

	//  Validate and Initialize device with user data
	ret = xss_init_dev_with_udata(udata, xss_dev);
	if (ret) {
		kfree(xss_dev);
		return ret;
	}
	if(!xss_dev->num_valid_cus) {
		kfree(xss_dev);
		return -EINVAL;
	}

	spin_lock_irqsave(&xss_devices.lock, flags);
	xss_dev->dev_id = xss_devices.count;
	spin_unlock_irqrestore(&xss_devices.lock, flags);

	// Find if the CUs found on the device are good enough 
	// to support XSS Services
	xss_discover_services(xss_dev);

	if (!xss_dev->num_services) {
		kfree(xss_dev);
		return -EINVAL;
	}

	spin_lock_irqsave(&xss_devices.lock, flags);
	list_add_tail(&xss_dev->list, &xss_devices.list);
	xss_devices.count++;
	spin_unlock_irqrestore(&xss_devices.lock, flags);

	return ret;
}

static struct xss_device* find_xss_device(int dev_id)
{
	unsigned long flags;
	struct xss_device *xss_dev = NULL;

	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_entry(xss_dev, &xss_devices.list, list) {
		if (xss_dev->dev_id == dev_id){
			spin_unlock_irqrestore(&xss_devices.lock, flags);
			return xss_dev;
		}
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);

	return NULL;
}

int xss_get_dev_id(unsigned pci_addr)
{
	unsigned long flags;
	struct xss_device *xss_dev;
	int dev_id = -ENODEV;

	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_entry(xss_dev, &xss_devices.list, list) {
		if(xss_dev->pci_addr == pci_addr)
			dev_id = xss_dev->dev_id;
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);
	return dev_id;
}
EXPORT_SYMBOL_GPL(xss_get_dev_id);

int xss_get_pci_addr(int dev_id, unsigned *pci_addr)
{
	unsigned long flags;
	struct xss_device *xss_dev;

	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_entry(xss_dev, &xss_devices.list, list) {
		if(xss_dev->dev_id == dev_id)
			*(pci_addr) = xss_dev->pci_addr;
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);
	return 0;
}
EXPORT_SYMBOL_GPL(xss_get_pci_addr);

int xss_get_devs_with_service(int service_id, int dev_id[])
{
	int i;
	unsigned long flags;
	struct xss_device *xss_dev;

	int num_devices = 0;
	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_entry(xss_dev, &xss_devices.list, list) {
		for (i=0; i<xss_dev->num_services; i++) {
			if (service_id == xss_dev->service_list[i].service_id){
				pr_info("%s: %d %d", __func__, service_id, xss_dev->dev_id);
				num_devices++;
				dev_id[num_devices] = xss_dev->dev_id;
				break;
			}
		}
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);
	return num_devices;
}
EXPORT_SYMBOL_GPL(xss_get_devs_with_service);

static int  is_service_avail(struct xss_device *xss_dev, int service_id)
{
	int i;
	for (i=0; i<xss_dev->num_services; i++) {
		if (service_id == 
				xss_dev->service_list[i].service_id){
			return i;
		}
	}	
	return -EINVAL;
}

bool xss_is_service_avail_on_dev(int dev_id, int service_id)
{
	struct xss_device *xss_dev = find_xss_device(dev_id);
	return (is_service_avail(xss_dev, service_id)<0) ? false : true;

}
EXPORT_SYMBOL_GPL(xss_is_service_avail_on_dev);

int xss_get_peer_dev(const char * blkdev_path)
{
	unsigned long flags;
	int len=0,dev_id=-1;
	struct xss_device *xss_dev;
	char device[20];
	while(blkdev_path[len++]);
	snprintf(device,len-7,blkdev_path+5);
	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_entry(xss_dev, &xss_devices.list, list) {
	        if(strstr(xss_dev->peer_nvme,device))
	                dev_id = xss_dev->dev_id;
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);
	return dev_id;
}
EXPORT_SYMBOL_GPL(xss_get_peer_dev);

static void delete_xss_bo_list (struct xss_bo_list *free_bo_list)
{
	unsigned long flags;
	struct list_head *pos, *next;
	struct xss_bo *bo;

	spin_lock_irqsave(&free_bo_list->lock, flags);
	list_for_each_safe(pos, next, &free_bo_list->exec_bos){
		bo = list_entry(pos, struct xss_bo, list);
		list_del(pos);
		kfree(bo);
	}
	list_for_each_safe(pos, next, &free_bo_list->dummy_bos){
		bo = list_entry(pos, struct xss_bo, list);
		list_del(pos);
		kfree(bo);
	}
	list_for_each_safe(pos, next, &free_bo_list->data_bos){
		bo = list_entry(pos, struct xss_bo, list);
		list_del(pos);
		kfree(bo);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
}

static int create_xss_bo_list (struct xss_context *ctx, struct xss_bo_list *free_bo_list, int svc_id)
{
	int ret=0,i;
	unsigned long flags;
	struct xss_bo *bo;

	INIT_LIST_HEAD(&free_bo_list->exec_bos);
	INIT_LIST_HEAD(&free_bo_list->dummy_bos);
	INIT_LIST_HEAD(&free_bo_list->data_bos);

	spin_lock_init(&free_bo_list->lock);

	spin_lock_irqsave(&free_bo_list->lock, flags);
	for(i=0; i < supported_services[svc_id].max_outstanding_reqs; i++){
		bo = (struct xss_bo *)kzalloc(sizeof(struct xss_bo), GFP_KERNEL);
		if (!bo) {
			ret = -ENOMEM;
			goto out;
		}

		ret = xss_create_exec_bo(ctx->drm_file, &bo->handle, &bo->vaddr, 
				EXEC_BO_ARG_SIZE);
		if (ret || (bo->handle == (uint32_t)-1))
			goto out;
		bo->size = 4096;
		list_add_tail(&bo->list, &free_bo_list->exec_bos);
	}
	for(i=0; i < supported_services[svc_id].max_outstanding_reqs; i++){
		bo = (struct xss_bo *)kzalloc(sizeof(struct xss_bo), GFP_KERNEL);
		if (!bo) {
			ret = -ENOMEM;
			goto out;
		}

		list_add_tail(&bo->list, &free_bo_list->dummy_bos);
	}
	for(i=0; i < supported_services[svc_id].max_outstanding_reqs; i++){
		bo = (struct xss_bo *)kzalloc(sizeof(struct xss_bo), GFP_KERNEL);
		if (!bo) {
			ret = -ENOMEM;
			goto out;
		}

		ret = xss_create_bo(ctx->drm_file, &bo->handle, &bo->paddr, 0,
					supported_services[svc_id].blk_size);
		if (ret || (bo->handle == (uint32_t)-1))
			goto out;
		bo->size = supported_services[svc_id].blk_size;
		list_add_tail(&bo->list, &free_bo_list->data_bos);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	return ret;
out:
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	delete_xss_bo_list(free_bo_list);
	return ret;
}

int xss_preallocate_xrt_buffers(struct xss_context *ctx, int dev_svc_offset, int svc_id)
{
	int ret=0;
	struct xss_bo_list *free_bo_list;
	struct xss_bo *p2p_bo;

	free_bo_list = &ctx->free_bo_list[dev_svc_offset];
	ret = create_xss_bo_list(ctx, free_bo_list, svc_id);
	if (ret)
		return ret;

	p2p_bo = &ctx->p2p_bo[dev_svc_offset];
	if (supported_services[svc_id].reqd_p2p_pages) {
		ret = xss_create_p2p_bo(ctx->drm_file, &p2p_bo->handle, &p2p_bo->paddr,
			(supported_services[svc_id].reqd_p2p_pages *
			supported_services[svc_id].blk_size));
		if (ret || (int)p2p_bo->handle == -1)
			goto out;

		p2p_bo->vaddr = (u64)xss_get_bo_kernel_vaddr(ctx->drm_file, p2p_bo->handle);
		p2p_bo->size  = supported_services[svc_id].reqd_p2p_pages *
						supported_services[svc_id].blk_size;

		pr_info("%s: P2P BO details: handle:%x paddr:%llx size:%x vaddr:%llx",
				__func__, p2p_bo->handle, p2p_bo->paddr, p2p_bo->size,
				(u64)p2p_bo->vaddr);

		add_to_free_p2p_pglist(ctx, (void *)p2p_bo->vaddr,
			(supported_services[svc_id].reqd_p2p_pages *
					supported_services[svc_id].blk_size));
	}
	return ret;
out:
	delete_xss_bo_list(free_bo_list);
	return ret;
}

static int xss_open_service_cus(struct xss_context *ctx)
{
	struct dev_service_info *svc_info; 
	struct service_kernel *svc_kernel;
	int num_kernels; 
	int i = 0;
	int k_idx = 0;
	int cu_idx = 0;
	int ret=0;

	for (i=0; i<ctx->num_services; i++) {
		svc_info = ctx->dev_svc_ref[i];
		num_kernels = supported_services[svc_info->service_id].num_kernels; 
		for (k_idx=0; k_idx < num_kernels; k_idx++) {
			svc_kernel = &svc_info->service_kernels[k_idx];
			for (cu_idx=0; cu_idx < svc_kernel->num_cus; cu_idx++) {
				pr_info("%s: creating cu context: \
						d:%d s:%d k:%d c:%d ",__func__,
						ctx->device->dev_id, 
						svc_info->service_id, 
						svc_kernel->kernel_id, 
						svc_kernel->cus[cu_idx]->cu_index);
				ret = xss_open_xrt_ctx(ctx->drm_file, 
						ctx->device->xclbin_id, 
						svc_kernel->cus[cu_idx]->cu_index, 
						true);
				if (ret) {
					pr_err("%s: Unable to open xrt context", __func__);
					return -EFAULT;
				}

			}
		}

	}
	return 0;
}

static void xss_close_service_cus (struct xss_context *ctx)
{
	struct dev_service_info *svc_info; 
	struct service_kernel *svc_kernel;
	int num_kernels; 
	int i = 0;
	int k_idx = 0;
	int cu_idx = 0;

	for (i=0; i<ctx->num_services; i++) {
		svc_info = ctx->dev_svc_ref[i];
		num_kernels = supported_services[svc_info->service_id].num_kernels; 
		for (k_idx=0; k_idx < num_kernels; k_idx++) {
			svc_kernel = &svc_info->service_kernels[k_idx];
			for (cu_idx=0; cu_idx < svc_kernel->num_cus; cu_idx++) {
				pr_info("%s: closing cu context: "
					"d:%d s:%d k:%d c:%d ",__func__,
						ctx->device->dev_id, 
						svc_info->service_id, 
						svc_kernel->kernel_id, 
						svc_kernel->cus[cu_idx]->cu_index);
				xss_close_xrt_ctx(ctx->drm_file, 
						ctx->device->xclbin_id, 
						svc_kernel->cus[cu_idx]->cu_index);
			}
		}

	}
}

struct xss_context* xss_get_ctx_struct(int ctx_id)
{
	if (!ctx_id) {
		pr_err("%s: Invalid ctx id %d ", __func__, ctx_id);
		return NULL;
	}
	return &xss_ctx_list[ctx_id-1];
}

static int find_free_ctx_slot(void)
{
	int i;
	for (i=0; i<MAX_XSS_CTX; i++)
	{
		if (!xss_ctx_list[i].ctx_id) {
			pr_info("ctx_d:%d i:%d",xss_ctx_list[i].ctx_id,i);
			return i;
		}
	}
	return -ENOSPC;
}

int xss_create_ctx(const char * client, int dev_id, int services[], int num_services)
{
	int i;
	int ret=0;
	struct xss_device *xss_dev;
	struct xss_context *xss_ctx;	

	// Find a free ctx slot
	int ctx_slot = find_free_ctx_slot();
	if (ctx_slot < 0)
		return ctx_slot;
	xss_ctx = &xss_ctx_list[ctx_slot];

	// find the device with dev_id
	xss_dev = find_xss_device(dev_id);
	if (!xss_dev)
		return -EINVAL;

	// find services with svd_id in the device
	for (i=0; i<num_services; i++) {
		int svc_offset = is_service_avail(xss_dev, services[i]);
		if(svc_offset < 0)
			return -EINVAL;
		xss_ctx->dev_svc_ref[i] = &xss_dev->service_list[svc_offset];
	}

	// store ctx with client
	xss_ctx->ctx_id = ctx_slot + 1;
	strcpy(xss_ctx->client, client);
	xss_ctx->device = xss_dev;
	xss_ctx->num_services = num_services;
	for (i=0; i<num_services; i++)
		xss_ctx->svc_ids[i] = services[i];

	xss_ctx->drm_file = xss_drm_open(xss_dev->drm_dev_t);
	if (xss_ctx->drm_file == NULL) {
		pr_err("%s: Unable to drm_open", __func__);
		return -ENOMEM;
	}

	// open cu context for each CU required for the services in ctx
	if ((ret = xss_open_service_cus(xss_ctx)) < 0)
		goto out;

	/*initialize p2p page list for the context*/
	xss_list_init(&xss_ctx->p2p_mem_pages);

	// call the services' init
	for (i=0; i<num_services; i++) {
		if ((ret = xss_preallocate_xrt_buffers(xss_ctx, i, xss_ctx->svc_ids[i])) < 0) 
			goto out1;
		if (supported_services[xss_ctx->svc_ids[i]].init){
			ret = supported_services[xss_ctx->svc_ids[i]].init(xss_ctx);
			if (ret < 0)
				goto out1;
		}
	}

	xss_ctx->in_use = true;
	return xss_ctx->ctx_id;
out1:
	xss_delete_p2p_pglist(xss_ctx);
	xss_close_service_cus(xss_ctx);
out:
	xss_drm_release(xss_ctx->drm_file);
	memset(xss_ctx, 0, sizeof(struct xss_context));
	return ret;
}
EXPORT_SYMBOL_GPL(xss_create_ctx);

void xss_delete_ctx(int ctx_id)
{
	int i;
	struct xss_context *ctx;

	if (!ctx_id) {
		pr_err("%s: Invalid ctx id %d ", __func__, ctx_id);
		return;
	}
	ctx = xss_get_ctx_struct(ctx_id);

	pr_info("%s:", __func__);
	if(ctx) {
		for (i=0; i<ctx->num_services; i++) {
			int svc_id = ctx->svc_ids[i];
			if (supported_services[svc_id].exit)
				supported_services[svc_id].exit(ctx);
			delete_xss_bo_list(&ctx->free_bo_list[i]);
		}
		ctx->in_use = false;
		pr_info("%s: %d", __func__, atomic_read(&ctx->p2p_use_count));
		if (!atomic_read(&ctx->p2p_use_count)) {
			xss_delete_p2p_pglist(ctx);
			xss_close_service_cus(ctx);
			xss_drm_release(ctx->drm_file);
			memset(ctx, 0, sizeof(struct xss_context));
		}
	}
}
EXPORT_SYMBOL_GPL(xss_delete_ctx);

static long xss_interface_ioctl(struct file *file, unsigned int cmd, 
		unsigned long arg)
{
	int ret=0;
	switch (cmd) {
		case XSS_ADD_DEV_CU_INFO_IOCTL:
			ret = xss_add_dev_cu_info((void __user *)arg);
			if(ret) {
				pr_info("Unable to add deice info : FAILED\n");
				return ret;
			}
			return 0;
		default:
			pr_err("%s Invalid device IOCTL.\n",__func__);
			return -ENOTTY;
	}
}

static struct file_operations xss_interface_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = xss_interface_ioctl
};

static int xss_init(void)
{
	int ret=0;
	struct device *dev_ret;

	printk(KERN_INFO "Loading xss ioctl interface module...\n");
	if((ret = alloc_chrdev_region(&dev, 0, 1, "xss_interface")) < 0)
	{
		return ret;
	}

	cdev_init(&c_dev, &xss_interface_fops);

	if((ret = cdev_add(&c_dev, dev, 1)) < 0)
	{
		return ret;
	}

	if(IS_ERR(cl = class_create(THIS_MODULE, "char")))
	{
		cdev_del(&c_dev);
		unregister_chrdev_region(dev, 1);
		return PTR_ERR(cl);
	}

	if(IS_ERR(dev_ret = device_create(cl, NULL, dev, NULL, 
					"xss-interface")))
	{
		class_destroy(cl);
		cdev_del(&c_dev);
		unregister_chrdev_region(dev, 1);
		return PTR_ERR(dev_ret);
	}

	perf_stats[0].op_name = "Encryption";
	perf_stats[1].op_name = "Decryption";
	perf_stats[2].op_name = "Compression";
	perf_stats[3].op_name = "Decompression";
	perf_stats[4].op_name = "Packer";
	xss_proc_init();
	xss_list_init(&xss_devices);
	xss_exec_wq = alloc_workqueue("xss-exec-wq", 0, 0);    

	return ret;
}

static void xss_exit(void)
{
	unsigned long flags;
	struct list_head *pos, *next;
	struct xss_device *xss_dev;
	struct cu_info *cu;
	int cu_idx;

	printk(KERN_INFO "Exiting XSS Interface module...\n");

	if (xss_exec_wq)
		destroy_workqueue(xss_exec_wq);

	spin_lock_irqsave(&xss_devices.lock, flags);
	list_for_each_safe(pos, next, &xss_devices.list){
		xss_dev = list_entry(pos, struct xss_device, list);
		list_del(pos);
		for (cu_idx = 0; cu_idx < xss_dev->num_valid_cus; cu_idx++) {
			cu = &xss_dev->cu_list[cu_idx];
			kfree(cu->args);
		}
		kfree(xss_dev);
	}
	spin_unlock_irqrestore(&xss_devices.lock, flags);

	xss_proc_exit();

	device_destroy(cl, dev);
	class_destroy(cl);
	cdev_del(&c_dev);
	unregister_chrdev_region(dev, 1);
}

module_init(xss_init);
module_exit(xss_exit);
MODULE_LICENSE("GPL");
