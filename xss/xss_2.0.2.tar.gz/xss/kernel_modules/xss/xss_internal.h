/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <xss_ioctl.h>
#include <xocl_ioctl.h>
#include <linux/scatterlist.h>

//#define XSS_TRACE_TIME
#define XSS_FA_BASED_KERNEL

#define MAX_CUS_PER_DEVICE	30
#define MAX_CUS_SAME_TYPE	5
#define MAX_KERNELS_PER_SERVICE 3
#define MAX_SERVICES_PER_DEVICE	10
#define MAX_SERVICES_PER_CONTEXT 10
#define MAX_SERVICE_KERNELS  10
#define MAX_XSS_CTX 30

#define XSS_STATE_INPUT_TX  0
#define XSS_STATE_COMPUTE   1
#define XSS_STATE_OUTPUT_TX 2

#define XSS_PERF_STATS 0

#define XSS_ENCRYPT_OPCODE 2
#define XSS_DECRYPT_OPCODE 3

#define IS_SGL(xss_req) (xss_req->datatype == SGL_TYPE)
#define IS_ENCRYPT(xss_req) (xss_req->crypt_op == XSS_ENCRYPT_OPCODE)
#define IS_DECRYPT(xss_req) (xss_req->crypt_op == XSS_DECRYPT_OPCODE)



#define WORD_INDEX(byte) (byte/4)
#define AES_XTS_KARG_OFFSET(KARG) \
	WORD_INDEX(supported_kernels[AES_XTS_256_ENCR].kargs[KARG].offset)
#define AES_XTS_KARG_SIZE(KARG) \
	WORD_INDEX(supported_kernels[AES_XTS_256_ENCR].kargs[KARG].size)

#define COMPRESS_KARG_OFFSET(KARG) \
	WORD_INDEX(supported_kernels[LZ4_COMPRESS].kargs[KARG].offset)
#define COMPRESS_KARG_SIZE(KARG) \
	WORD_INDEX(supported_kernels[LZ4_COMPRESS].kargs[KARG].size)

#define DECOMPRESS_KARG_OFFSET(KARG) \
	WORD_INDEX(supported_kernels[LZ4_DECOMPRESS].kargs[KARG].offset)
#define DECOMPRESS_KARG_SIZE(KARG) \
	WORD_INDEX(supported_kernels[LZ4_DECOMPRESS].kargs[KARG].size)

#define PACKER_KARG_OFFSET(KARG) \
	WORD_INDEX(supported_kernels[PACKER].kargs[KARG].offset)
#define PACKER_KARG_SIZE(KARG) \
	WORD_INDEX(supported_kernels[PACKER].kargs[KARG].size)
#define LOWER_WORD(X) (X & 0xFFFFFFFF)
#define UPPER_WORD(X) (X >> 32) & 0xFFFFFFFF

#define XSS_SYNC_H2C DRM_XOCL_SYNC_BO_TO_DEVICE
#define XSS_SYNC_C2H DRM_XOCL_SYNC_BO_FROM_DEVICE

#define XSS_BO_TYPE_INPUT	(1 << 0)
#define XSS_BO_TYPE_OUTPUT	(1 << 1)
#define XSS_BO_TYPE_INTERNAL	(1 << 2)
#define XSS_BO_TYPE_EXEC	(1 << 3)
#define XSS_BO_TYPE_BUF		(1 << 4)
#define XSS_BO_TYPE_SGL		(1 << 5)
#define XSS_BO_TYPE_P2P		(1 << 6)

#define XSS_OP_DIR_READ 0
#define XSS_OP_DIR_WRITE 1

#define SYNC_INPUT XSS_SYNC_H2C
#define SYNC_OUTPUT XSS_SYNC_C2H

#define SGL_OFFSET(ptr) (((struct scatterlist *)ptr)->offset)

#define IS_ASYNC_REQ(req) (req->user_cb != NULL)

typedef void (*xss_callback_fn)(void *cb_data, int status);

struct drm_file_info {
	struct inode *inode;
	struct file *filp;
};

struct xss_list {
	spinlock_t lock;
	struct list_head list;
	int count;
};

struct xss_bo_list {
	spinlock_t lock;
	struct list_head exec_bos;
	struct list_head data_bos;
	struct list_head dummy_bos;
};

struct xss_bo {
	uint64_t uaddr; /* user SGL address */
	uint64_t paddr; /* Physical address on device */
	uint64_t vaddr; /* Kernel virtual address */
	uint32_t size;
	uint32_t handle;
	uint32_t offset;
	uint8_t  type;
	struct list_head list;
};

struct service_kernel {
	uint8_t	kernel_id;
	uint8_t	num_cus;
	struct	cu_info *cus[MAX_CUS_SAME_TYPE];
};

struct dev_service_info {
	int 		  	service_id;
	atomic_t		service_counter;
	struct service_kernel	service_kernels[MAX_KERNELS_PER_SERVICE];
};

struct xss_device {
	struct list_head	list;
	int			dev_id;
	dev_t			drm_dev_t;
	uuid_t			xclbin_id;
	int			num_valid_cus;
	unsigned                pci_addr;
	char 			peer_nvme[20];
	struct cu_info		cu_list[MAX_CUS_PER_DEVICE];
	int			num_services;
	struct dev_service_info service_list[MAX_SERVICES_PER_DEVICE];
	atomic_t		inflight_execs;
};

struct xss_context {
	uint8_t           	ctx_id;
	char		  	client[20];
	struct drm_file_info	*drm_file;
	uint8_t           	num_services;
	uint8_t           	svc_ids[MAX_SERVICES_PER_CONTEXT];
	bool		  	in_use;
	struct xss_device 	*device;
	struct dev_service_info *dev_svc_ref[MAX_SERVICES_PER_CONTEXT];
	struct xss_bo_list      free_bo_list[MAX_SERVICES_PER_CONTEXT];
	struct xss_bo    	p2p_bo[MAX_SERVICES_PER_CONTEXT];
	struct xss_list    	p2p_mem_pages;
	atomic_t		p2p_use_count;
};

struct xss_service {
	int  svc_id;
	char name[MAX_STR_SIZE];
	int  num_kernels;
	int  kernels[MAX_SERVICE_KERNELS];
	int  max_outstanding_reqs;
	int  reqd_p2p_pages;
	int  blk_size;
	int  (*init) (struct xss_context *);
	void  (*exit) (struct xss_context *);
};

struct xss_perf_stats {
	uint64_t set_args_time; 
	uint64_t input_tx_time; 
	uint64_t output_tx_time; 
	uint64_t compute_time;
	uint64_t op_time; 
	uint64_t num_ops; 
	uint64_t errors;
	atomic_t request_in;
	atomic_t request_out;
	char *op_name;
};

#define MAX_NUM_BLOCKS 8
struct xss_batch_req_node {
        struct list_head list;
	struct xss_request *xss_req;
	struct xss_compress_request *compress_req[MAX_NUM_BLOCKS];
	struct scatterlist sg_in[MAX_NUM_BLOCKS];
	int slots;
	struct timer_list batch_timer;
	int     ctx_id;
};

struct xss_request {
	uint8_t            state;
	uint8_t            num_bos;
	struct xss_bo      **bo_list;
	uint8_t            op_dir;
	uint8_t            cu_index;
	uint8_t            svc_id;
	struct xss_context *ctx;
	void               *user_cb_data;
	xss_callback_fn    user_cb;
	xss_callback_fn    dma_cb;
	xss_callback_fn    exec_cb;
	xss_callback_fn    complete;
	struct work_struct xss_work;
#ifdef XSS_TRACE_TIME
        struct timeval	   start_tv;
        struct timeval     process_tv;
        struct timeval     input_tv;
        struct timeval     compute_tv;
        struct timeval     output_tv;
        struct timeval     end_tv;
#endif
	unsigned long	   private;
};

typedef struct fa_desc_entry{ 
	u32 arg_offset;
	u32 arg_size;
	u32 arg_value[];
} fa_desc_entry_t;

int xss_submit_request(struct xss_request *req);

int xss_create_bo(struct drm_file_info *drm_file, uint32_t* bo_handle, 
		uint64_t* bo_paddr, int ddr, uint32_t bo_size);
int xss_remap_sgl_bo(struct drm_file_info *drm_file, uint32_t bo_handle,
						void *sgl_addr);
int xss_remap_kmem_bo(struct drm_file_info *drm_file, uint32_t bo_handle, 
						void *kern_addr);
void* xss_get_bo_kernel_vaddr (struct drm_file_info *drm_file, 
						uint32_t bo_handle);
int xss_sync_bo(struct drm_file_info *drm_file, uint32_t bo_handle, 
		int size, enum drm_xocl_sync_bo_dir dir, int offset);
int xss_migrate_bo(struct drm_file_info *drm_file, uint32_t bo_handle, int size, 
		enum drm_xocl_sync_bo_dir dir, int offset, void *cb_ctx);
int xss_trigger_hwfunc(struct drm_file_info *drm_file, uint32_t exec_bo_handle,
		uint64_t exec_vaddr, void *callback, void* ctx, int cu_index);

struct xss_bo* xss_get_bo(struct list_head *bo_list);
struct xss_context* xss_get_ctx_struct(int ctx_id);
bool is_user_ptr_p2p(struct page *page, struct xss_context *ctx, struct xss_bo **p2p_bo);
int get_p2p_page_offset(struct page *page, struct xss_bo *p2p_bo);
int xss_service_offset_in_ctx(struct xss_context *ctx, int svc_id);
int xss_get_service_cu(struct xss_context *ctx, int svc_offset, int kernel_id);

int xss_get_perf_stats (struct xss_perf_stats **stats);
inline uint64_t time_diff(struct timeval tv2, struct timeval tv1);
