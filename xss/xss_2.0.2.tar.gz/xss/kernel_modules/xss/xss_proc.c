/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include "xss_internal.h"

#define BUFSIZE 3000
char buf[BUFSIZE];

static ssize_t xss_perf_read(struct file *file, char __user *ubuf,size_t count, loff_t *ppos) 
{
	int i;
	int num_stats;
	struct xss_perf_stats *xss_stats;// = xss_get_perf_stats();
	int len=0;
	unsigned long avg_arg_time; 
	unsigned long avg_input_tx_time; 
	unsigned long avg_output_tx_time; 
	unsigned long avg_compute_time; 
	unsigned long avg_op_time; 
	unsigned long total_ops;
	unsigned long total_request_in;
	unsigned long total_request_out;

	if(*ppos > 0 || count < BUFSIZE)
		return 0;

	num_stats = xss_get_perf_stats(&xss_stats);

	len += sprintf(buf,"==========XSS Perfstats==========:\n");
	for (i=0; i<num_stats; i++) {
		total_request_in = atomic_read(&xss_stats[i].request_in);
		total_request_out = atomic_read(&xss_stats[i].request_out);		
		//len += sprintf(buf + len,"Total requests in: %lu\n", total_request_in);
		//len += sprintf(buf + len,"Total request comp.: %lu\n", total_request_out);
		pr_info("%s: %s", __func__, xss_stats[i].op_name);
		pr_info("%s: OP %llu", __func__, xss_stats[i].op_time);
		pr_info("%s: REQ in %llu", __func__, atomic_read(&xss_stats[i].request_in));
		pr_info("%s: REQ out %llu", __func__, atomic_read(&xss_stats[i].request_out));
		pr_info("%s: A %llu",  __func__, xss_stats[i].set_args_time);
		pr_info("%s: C %llu",  __func__, xss_stats[i].compute_time);
		pr_info("%s: I %llu",  __func__, xss_stats[i].input_tx_time);
		pr_info("%s: O %llu",  __func__, xss_stats[i].output_tx_time);
		pr_info("%s: N %llu",  __func__, xss_stats[i].num_ops);
		pr_info("%s: E %llu",  __func__, xss_stats[i].errors);

		total_ops = xss_stats[i].num_ops;
		avg_arg_time = total_ops ? xss_stats[i].set_args_time/total_ops : total_ops;
		avg_input_tx_time = total_ops ? xss_stats[i].input_tx_time/total_ops : total_ops;
		avg_output_tx_time = total_ops ? xss_stats[i].output_tx_time/total_ops: total_ops;
		avg_compute_time = total_ops ? xss_stats[i].compute_time/total_ops  : total_ops;
		avg_op_time = total_ops ? xss_stats[i].op_time/total_ops	   : total_ops;
		total_request_in = atomic_read(&xss_stats[i].request_in);
		total_request_out = atomic_read(&xss_stats[i].request_out);		

		len += sprintf(buf + len,"-----%s	:-\n", xss_stats[i].op_name); 
		len += sprintf(buf + len,"%s Total requests in: %lu comp: %lu\n", xss_stats[i].op_name, total_request_in, total_request_out);
		len += sprintf(buf + len,"Avg Op Time(us): %lu\n", avg_op_time);
		len += sprintf(buf + len,"Avg Set Args Time(us): %lu\n", avg_arg_time); 
		len += sprintf(buf + len,"Avg Input Tx Time(us): %lu\n",avg_input_tx_time); 
		len += sprintf(buf + len,"Avg Compute Time(us): %lu\n", avg_compute_time); 
		len += sprintf(buf + len,"Avg Output Tx Time(us): %lu\n",avg_output_tx_time); 
		len += sprintf(buf + len,"Num Ops: %llu\n", xss_stats[i].num_ops); 
		len += sprintf(buf + len,"Errors: %llu\n", xss_stats[i].errors); 
	}

	if(copy_to_user(ubuf,buf,len))
		return -EFAULT;

	*ppos = len;
	return len;
}

static struct proc_dir_entry *xss_proc_dir;
static struct proc_dir_entry *perf_ent;

static struct file_operations perf_ops = 
{
	.owner = THIS_MODULE,
	.read  = xss_perf_read,
};

int xss_proc_init(void)
{
	xss_proc_dir = proc_mkdir( "xss", NULL);
	if(!xss_proc_dir) {
		printk("proc_mkdir FAILED|n");
		return -ENOMEM;
	}
	perf_ent = proc_create("perf",0666,xss_proc_dir,&perf_ops);
	return 0;
}

void xss_proc_exit(void)
{
	remove_proc_subtree("xss", NULL);
	printk ("%s", __func__);
}
