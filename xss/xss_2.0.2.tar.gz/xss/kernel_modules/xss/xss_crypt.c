/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/uuid.h>
#include <linux/scatterlist.h>

#include "xss_internal.h"
#include "../include/xss_ioctl.h"
#include "../include/xss.h"
#include "xss_kernel_arg.h"
#include <ert.h>

#define XSS_CRYPT_BLOCK_SIZE 4096

enum crypt_bo_list{
CRYPT_EXEC_BO_IDX,
CRYPT_IP_BO_IDX,
CRYPT_OP_BO_IDX,
CRYPT_OPSTATUS_BO_IDX,
CRYPT_NUM_BOS
};

extern struct xss_kernel_info supported_kernels[];

int crypt_services[] = {
	XSS_SERVICE_AES_XTS_DECRYPTION,
	XSS_SERVICE_AES_XTS_ENCRYPTION
};

int crypt_kernels[] = {
	AES_XTS_256_DECR,
	AES_XTS_256_ENCR
};



struct xss_bo op_status_bo;

int crypt_service_init(struct xss_context *xss_ctx)
{
	xss_create_bo(xss_ctx->drm_file, &op_status_bo.handle, &op_status_bo.paddr, 0, 
								XSS_CRYPT_BLOCK_SIZE);
	op_status_bo.type = XSS_BO_TYPE_INTERNAL;
	return 0;
}

void crypt_service_exit(void)
{
	pr_info ("%s", __func__);
}

static inline void print_bo(struct xss_bo* bo)
{
	pr_info("%s: handle:%d type:0x%x paddr:%llx addr:%llx ofs:%x len:%d", 
		__func__, bo->handle, bo->type, bo->paddr, bo->uaddr, bo->offset,
		bo->size);
}

static inline void print_req_bos(struct xss_bo** bo_list)
{
	struct xss_bo *ip_bo, *op_bo;
	ip_bo = bo_list[CRYPT_IP_BO_IDX];
	op_bo = bo_list[CRYPT_OP_BO_IDX];

	if (!ip_bo || !op_bo) {
		pr_err("%s: %llx %llx", __func__, (u64)ip_bo, (u64)op_bo);
		return;
	}

	pr_info("%s: sgl:%d src:%llx dst:%llx sofs:%x dofs:%x len:(%d:%d) "
		"type:(0x%x:0x%x) handle:(%d:%d) paddr:(%llx:%llx)",
		__func__, 1, (u64)ip_bo->uaddr, (u64)op_bo->uaddr, 
		ip_bo->offset, op_bo->offset, ip_bo->size, op_bo->size, 
		ip_bo->type, op_bo->type, ip_bo->handle, op_bo->handle, 
		ip_bo->paddr, op_bo->paddr);
}

static inline void print_ert_pkt(struct ert_start_kernel_cmd *epkt)
{
	int i=0;
	for(;i<epkt->count+1;i++) 
		pr_info("%s: %d:%x", __func__, i, ((u32*)epkt)[i]);
	
}

static inline void print_cipher_request(struct xss_cipher_req *xreq, 
				int svc_offset, int cu_index)
{
	pr_info("%s: sgl:%d src:%llx dst:%llx sofs:%d dofs:%d len;%d "
		"spage:%llx dpage:%llx svc_offset:%d cu_index:%d", 
		__func__, IS_SGL(xreq), (u64)xreq->src, (u64)xreq->dst, 
		SGL_OFFSET(xreq->src), SGL_OFFSET(xreq->dst), xreq->datalen,
		(u64)sg_page(xreq->src), (u64)sg_page(xreq->dst), svc_offset, cu_index);
}


void crypt_free_req_bo_list(struct xss_context *ctx, int svc_offset, 
						struct xss_bo **bo_list)
{
	int i;
	unsigned long flags;
	struct xss_bo *bo;
	struct xss_bo_list *free_bo_list;

	free_bo_list = &ctx->free_bo_list[svc_offset];

	spin_lock_irqsave(&free_bo_list->lock, flags);
	for (i=0; i<CRYPT_NUM_BOS; i++){
		bo = bo_list[i];
		if (!bo || (i == CRYPT_OPSTATUS_BO_IDX))
			continue;
		if (bo->type & XSS_BO_TYPE_EXEC)
			list_add_tail(&bo->list, &free_bo_list->exec_bos);
		else if (bo->type & XSS_BO_TYPE_P2P)
			list_add_tail(&bo->list, &free_bo_list->dummy_bos);
		else
			list_add_tail(&bo->list, &free_bo_list->data_bos);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	kfree(bo_list);
}

struct xss_bo** crypt_setup_req_bo_list(struct xss_context *ctx, 
				struct xss_cipher_req *xreq)
{
	unsigned long flags;
	int svc_offset;

	struct page *in_page, *out_page;
	struct xss_bo *bo, *p2p_bo; 

	struct xss_bo_list *free_bo_list;
	struct xss_bo **bo_list;

	bo_list = (struct xss_bo **)kzalloc(CRYPT_NUM_BOS*
					sizeof(struct xss_bo*), GFP_KERNEL);
	if (!bo_list) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return NULL;
	}

	svc_offset = xss_service_offset_in_ctx(ctx, crypt_services[xreq->encrypt]);
	if (svc_offset<0)
		return NULL;

	free_bo_list = &ctx->free_bo_list[svc_offset];
	spin_lock_irqsave(&free_bo_list->lock, flags);

	bo = xss_get_bo(&free_bo_list->exec_bos);
	if (!bo)
		goto out;
	bo->type = XSS_BO_TYPE_EXEC;
	bo_list[CRYPT_EXEC_BO_IDX] = bo;

	in_page  = IS_SGL(xreq) ? sg_page(xreq->src): virt_to_page(xreq->src);
	out_page = IS_SGL(xreq) ? sg_page(xreq->dst): virt_to_page(xreq->dst);

	if (is_user_ptr_p2p(in_page, ctx, &p2p_bo)) {
		bo         = xss_get_bo(&free_bo_list->dummy_bos);
		if (!bo)
			goto out;

		bo->handle = p2p_bo->handle;
		bo->paddr  = p2p_bo->paddr;
		bo->size   = xreq->datalen; 
		bo->offset = get_p2p_page_offset(in_page, p2p_bo) +
				(IS_SGL(xreq) ? SGL_OFFSET(xreq->src):0);
		bo->type = XSS_BO_TYPE_P2P;
		bo->type|= XSS_BO_TYPE_INPUT;
		bo_list[CRYPT_IP_BO_IDX] = bo;
	}
	else {
		bo         = xss_get_bo(&free_bo_list->data_bos);
		if (!bo)
			goto out;

		bo->uaddr   = (u64)xreq->src;
		bo->size   = xreq->datalen; 
		bo->type   = IS_SGL(xreq) ? XSS_BO_TYPE_SGL:XSS_BO_TYPE_BUF;
		bo->type  |= XSS_BO_TYPE_INPUT;
		bo->offset = IS_SGL(xreq) ? SGL_OFFSET(xreq->src):0;
		bo_list[CRYPT_IP_BO_IDX] = bo;
	}
	if (is_user_ptr_p2p(sg_page(xreq->dst), ctx, &p2p_bo)) {
		bo = xss_get_bo(&free_bo_list->dummy_bos);
		if (!bo)
			goto out;

		bo->handle = p2p_bo->handle;
		bo->paddr  = p2p_bo->paddr;
		bo->size   = xreq->datalen; 
		bo->offset = get_p2p_page_offset(out_page, p2p_bo) +
				(IS_SGL(xreq) ? SGL_OFFSET(xreq->dst):0);
		bo->type = XSS_BO_TYPE_P2P;
		bo->type|= XSS_BO_TYPE_OUTPUT;
		bo_list[CRYPT_OP_BO_IDX] = bo;
	}
	else {
		bo = xss_get_bo(&free_bo_list->data_bos);
		if (!bo)
			goto out;

		bo->uaddr   = (u64)xreq->dst;
		bo->size   = xreq->datalen; 
		bo->type   = IS_SGL(xreq) ? XSS_BO_TYPE_SGL:XSS_BO_TYPE_BUF;
		bo->type  |= XSS_BO_TYPE_OUTPUT;
		bo->offset = IS_SGL(xreq) ? SGL_OFFSET(xreq->dst):0;
		bo_list[CRYPT_OP_BO_IDX] = bo;
	}
	bo_list[CRYPT_OPSTATUS_BO_IDX] = &op_status_bo;

	spin_unlock_irqrestore(&free_bo_list->lock, flags);

	//print_req_bos(bo_list);
	return bo_list;
out:
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	crypt_free_req_bo_list(ctx, svc_offset, bo_list);
	return NULL;
}

static int crypt_setup_ert_packet(struct xss_context *ctx, 
					struct xss_cipher_req *xreq,
					struct xss_bo **bo_list, 
					int cu_index)
{
	uint64_t ip_bo_paddr, op_bo_paddr, op_status_bo_paddr;
	struct ert_start_kernel_cmd *ert_packet;
	fa_desc_entry_t *desc_entry;
	int off = 0;

	int ip_size = bo_list[CRYPT_IP_BO_IDX]->size;
	int op_size = bo_list[CRYPT_IP_BO_IDX]->size;

	ip_bo_paddr = bo_list[CRYPT_IP_BO_IDX]->paddr + 
			bo_list[CRYPT_IP_BO_IDX]->offset; 
	op_bo_paddr = bo_list[CRYPT_OP_BO_IDX]->paddr + 
			bo_list[CRYPT_OP_BO_IDX]->offset; 
	op_status_bo_paddr = bo_list[CRYPT_OPSTATUS_BO_IDX]->paddr + 
			bo_list[CRYPT_OPSTATUS_BO_IDX]->offset; 

	ert_packet = (struct ert_start_kernel_cmd *) 
				bo_list[CRYPT_EXEC_BO_IDX]->vaddr;

	if (!ert_packet) {
	        pr_info("%s: Cannot get ert packket for exec_handle!", __func__);
	        return -EFAULT;
	}

        ert_packet->state = ERT_CMD_STATE_NEW;
        ert_packet->opcode = ERT_START_FA;
        ert_packet->type = ERT_CU;
        ert_packet->count = 0x30;
        ert_packet->cu_mask = 1 << cu_index;

	ert_packet->data[0] = 0;
	ert_packet->data[1] = MAX_AES_XTS_ARGS-1;
	ert_packet->data[2] = MAX_AES_XTS_ARGS_SIZE;
	ert_packet->data[3] = 0;
	ert_packet->data[4] = 0;
	
	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x10;
	desc_entry->arg_size = sizeof(ip_bo_paddr);
	memcpy(desc_entry->arg_value, &ip_bo_paddr, sizeof(ip_bo_paddr));
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x18;
	desc_entry->arg_size = sizeof(ip_size);
	memcpy(desc_entry->arg_value, &ip_size, sizeof(ip_size));
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;
	
	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x1C;
	desc_entry->arg_size = sizeof(op_bo_paddr);
	memcpy(desc_entry->arg_value, &op_bo_paddr, sizeof(op_bo_paddr));
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;
	
	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x24;
	desc_entry->arg_size = sizeof(op_size);
	memcpy(desc_entry->arg_value, &op_size, sizeof(op_size));
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;
	
	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x28;
	desc_entry->arg_size = sizeof(op_status_bo_paddr);
	memcpy(desc_entry->arg_value, &op_status_bo_paddr, sizeof(op_status_bo_paddr));
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x30;
	desc_entry->arg_size = AES_XTS_KEY_LEN;
	memcpy(desc_entry->arg_value, xreq->key, AES_XTS_KEY_LEN);
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = 0x70;
	desc_entry->arg_size = AES_XTS_IV_LEN;
	memcpy(desc_entry->arg_value, xreq->iv, AES_XTS_IV_LEN);
	off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

	//print_ert_pkt(ert_packet);
	return 0;
}

static void xss_crypt_req_cmpltn(void *data, int status)
{
	int ret=0;
	struct xss_request *req = (struct xss_request *)data;
	struct xss_context *ctx = req->ctx;
	int svc_offset = xss_service_offset_in_ctx(ctx, req->svc_id);

	struct xss_perf_stats *stats;
	xss_get_perf_stats(&stats);
	if(req->op_dir == XSS_OP_DIR_WRITE)
		atomic_inc(&stats[0].request_out); 
	else
		atomic_inc(&stats[1].request_out);
 
	if(req->user_cb)
		req->user_cb(req->user_cb_data, ret);

	crypt_free_req_bo_list(ctx, svc_offset, req->bo_list);

	kfree(req);
}


int xss_crypt(int ctx_id, struct xss_cipher_req *cipher_req)
{
	struct xss_context *ctx = xss_get_ctx_struct(ctx_id);
	int ret=0;
	int cu_index;
	int svc_offset;
	struct xss_request *xss_req;
	struct xss_bo **bo_list;

	struct xss_perf_stats *stats;
	xss_get_perf_stats(&stats);
	if(cipher_req->encrypt)
		atomic_inc(&stats[0].request_in); 
	else
		atomic_inc(&stats[1].request_in); 
	//pr_info("%s func : enc : %d",__func__,cipher_req->enc);
	svc_offset = xss_service_offset_in_ctx(ctx, crypt_services[cipher_req->encrypt]);
	if (svc_offset<0)
		return svc_offset;

	cu_index = xss_get_service_cu(ctx, svc_offset, crypt_kernels[cipher_req->encrypt]);
	if (cu_index<0)
		return svc_offset;

	//print_cipher_request(cipher_req, svc_offset, cu_index);

	xss_req = (struct xss_request *)
			kzalloc(sizeof(struct xss_request), GFP_KERNEL);
	if (!xss_req) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return -ENOMEM;
	}

	bo_list = crypt_setup_req_bo_list(ctx, cipher_req);
	if (!bo_list) {
		//pr_info("%s: No free BufferObjects!!", __func__);
		kfree(xss_req);
		return -EBUSY;
	}

	ret = crypt_setup_ert_packet(ctx, cipher_req, bo_list, cu_index);
	if (ret)
		goto out;

	xss_req->ctx      = ctx;
	xss_req->svc_id   = crypt_services[cipher_req->encrypt];
	xss_req->cu_index = cu_index;
	xss_req->bo_list  = bo_list;
	xss_req->num_bos  = CRYPT_NUM_BOS;
	xss_req->op_dir   = cipher_req->encrypt ? XSS_OP_DIR_WRITE:XSS_OP_DIR_READ;
	xss_req->complete = xss_crypt_req_cmpltn;
	xss_req->user_cb  = cipher_req->xss_cb.func;
	xss_req->user_cb_data = cipher_req->xss_cb.data;

	if ((ret = xss_submit_request(xss_req)) < 0)
		goto out;
	
	return -EINPROGRESS;
out:
	crypt_free_req_bo_list(ctx, svc_offset, bo_list);
	kfree(xss_req);
	return ret;
}
EXPORT_SYMBOL_GPL(xss_crypt);
