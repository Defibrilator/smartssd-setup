/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define MAX_KERNEL_ARGS 30

#define AES_XTS_ENC_ARGS \
                        {"DATA_IN_OFFSET",	"m_axi1", 	"int*",	0x8,  0x10},\
                        {"DATA_IN_LEN_BYTES", 	"s_axi_control","int",	0x4,  0x18},\
                        {"DATA_OUT_OFFSET", 	"m_axi",  	"int*",	0x8,  0x1C},\
                        {"DATA_OUT_LEN_AVAIL",	"s_axi_control","int",	0x4,  0x24},\
                        {"DATA_OUT_STATUS_OFFSET","m_axi",	"int*",	0x8,  0x28},\
                        {"AES_KEY_OFFSET",	"s_axi_control","int",	0x40, 0x30},\
                        {"AES_IV_OFFSET",	"s_axi_control","int",	0x10, 0x70},\
                        {"nextDescriptorAddr",	"M_AXI_DESC",	"void*",0x8,  0x0},\

#define AES_XTS_DEC_ARGS AES_XTS_ENC_ARGS

#ifdef XSS_FA_BASED_KERNEL
#define LZ4_COMPRESS_ARGS \
                        {"in_r", "M_AXI_GMEM0", "ap_uint",0x8,0x10},\
                        {"out_r", "M_AXI_GMEM0", "ap_uint", 0x8,0x1C},\
                        {"compressd_size", "M_AXI_GMEM1", "unsigned int*", 0x8,0x28},\
                        {"num_blocks", "S_AXI_CONTROL", "unsigned int", 0x4,0x34},\
			{"nextDescriptorAddr", "M_AXI_DESC",   "void*",0x8,  0x0}
#else
#define LZ4_COMPRESS_ARGS \
                        {"in_r", "M_AXI_GMEM0", "ap_uint",0x8,0x10},\
                        {"out_r", "M_AXI_GMEM0", "ap_uint", 0x8,0x1C},\
                        {"compressd_size", "M_AXI_GMEM1", "unsigned int*", 0x8,0x28},\
                        {"num_blocks", "S_AXI_CONTROL", "unsigned int", 0x4,0x34}
#endif

#define LZ4_DECOMPRESS_ARGS \
                        {"in_r", "M_AXI_GMEM", "ap_uint",0x8,0x10},\
                        {"out_r", "M_AXI_GMEM", "ap_uint", 0x8,0x1C},\
                        {"in_compress_size", "S_AXI_CONTROL", "unsigned int", 0x4,0x28},\
                        {"block_size_in_kb", "S_AXI_CONTROL", "unsigned int", 0x4,0x30},\
                        {"input_index", "S_AXI_CONTROL", "unsigned int", 0x4,0x38}

#ifdef XSS_FA_BASED_KERNEL
#define PACKER_ARGS \
                        {"in_r", "M_AXI_GMEM", "void*",0x8,0x10},\
                        {"out_r", "M_AXI_GMEM", "void*", 0x8,0x1C},\
                        {"fragment_info", "M_AXI_GMEM1", "void*", 0x8,0x28},\
                        {"no_fragments", "S_AXI_CONTROL", "unsigned int", 0x4,0x34},\
			{"nextDescriptorAddr", "M_AXI_DESC",   "void*",0x8,  0x0}
#else
#define PACKER_ARGS \
                        {"in_r", "M_AXI_GMEM", "void*",0x8,0x10},\
                        {"out_r", "M_AXI_GMEM", "void*", 0x8,0x1C},\
                        {"fragment_info", "M_AXI_GMEM1", "void*", 0x8,0x28},\
                        {"no_fragments", "S_AXI_CONTROL", "unsigned int", 0x4,0x34}
#endif

struct kernel_args
{
        char *name;
        char *port;
        char *type;
        size_t size;
        size_t offset;
	int32_t ddr;
};

enum SUPPORTED_KERNELS {
	AES_XTS_256_ENCR,
	AES_XTS_256_DECR,
	LZ4_DECOMPRESS,
	LZ4_COMPRESS,
	PACKER,
	MAX_KERNELS
};

enum SUPPORTED_PACKER_KARGS {
	PACKER_INPUT_BO, //base addr
	PACKER_OUTPUT_BO,
	PACKER_FRAGMENT_INFO_BO, //offset and size
	PACKER_FRAGMENT_COUNT,
#ifdef XSS_FA_BASED_KERNEL
	PACKER_NEXT_DESCRIPTOR_ADDR,
#endif
	MAX_PACKER_ARGS
};
enum SUPPORTED_COMPRESS_KARGS {
	LZ4_COMP_INPUT_BO,
	LZ4_COMP_OUTPUT_BO,
	LZ4_COMP_COMPRESSED_SIZE_BO,
	LZ4_COMP_NUM_BLOCKS,
#ifdef XSS_FA_BASED_KERNEL
	LZ4_COMP_NEXT_DESCRIPTOR_ADDR,
#endif
	MAX_LZ4_COMPRESS_ARGS
};

enum SUPPORTED_DECOMPRESS_KARGS {
	LZ4_DECOMP_INPUT_BO,
	LZ4_DECOMP_OUTPUT_BO,
	LZ4_DECOMP_INPUT_SIZE,
	LZ4_DECOMP_BLOCK_SIZE_IN_KB,
	LZ4_DECOMP_OFFSET,
	MAX_LZ4_DECOMPRESS_ARGS
};

enum SUPPORTED_AES_KARGS {
	INPUT_BO,
	DATA_IN_LEN_BYTES,
	OUTPUT_BO,
	DATA_OUT_LEN_AVAIL,
	OUTPUT_BO_OFFSET,
	AES_KEY_OFFSET,
	AES_IV_OFFSET,
	NEXT_DESCRIPTOR_ADDR,
	MAX_AES_XTS_ARGS
};

#define MAX_AES_XTS_ARGS_SIZE 112
#define MAX_LZ4_COMPRESS_ARGS_SIZE 28
#define MAX_PACKER_ARGS_SIZE 28

struct xss_kernel_info {
	char *kernel_name;
	int num_cus;
	int cu_index[MAX_KERNELS];
	int num_kargs;
	struct kernel_args kargs[MAX_KERNEL_ARGS];
};
