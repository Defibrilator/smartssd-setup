/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Srija Malyala <srijam@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/uuid.h>
#include <linux/scatterlist.h>

#include "xss_internal.h"
#include "../include/xss_ioctl.h"
#include "../include/xss.h"
#include "xss_kernel_arg.h"
#include <ert.h>

#define IS_PACKER_SRVC_AVAILABLE 1

enum decompress_bo_list{
	DECOMPRESS_EXEC_BO_IDX,
	DECOMPRESS_IP_BO_IDX,
	DECOMPRESS_OP_BO_IDX,
	DECOMPRESS_NUM_BOS
};

enum compress_bo_list {
	COMPRESS_EXEC_BO_IDX,
	COMPRESS_IP_BO_IDX,
	COMPRESS_SIZE_BO_IDX,
	COMPRESS_NUM_BOS
};

enum packer_bo_list {
	PACKER_EXEC_BO_IDX,
	PACKER_IP_BO_IDX,
	PACKER_OP_BO_IDX,
	PACKER_NUM_BOS
};

extern struct xss_kernel_info supported_kernels[];

int compress_services[] = {
        XSS_SERVICE_LZ4_DECOMPRESSION,
	XSS_SERVICE_LZ4_COMPRESSION,
	XSS_SERVICE_PACKER
};

int compress_kernels[] = {
	LZ4_DECOMPRESS,
	LZ4_COMPRESS,
	PACKER
};

struct list_head xss_batch_list = LIST_HEAD_INIT(xss_batch_list);
static DEFINE_SPINLOCK(batch_req_list_lock);

int compress_service_init(struct xss_context *xss_ctx)
{
	unsigned long flags;
	struct xss_batch_req_node *batch_req;
	int i=0, slot;

	printk ("%s", __func__);
	for(i=0; i < 6000; i++){
		batch_req = (struct xss_batch_req_node*)
			kzalloc(sizeof(struct xss_batch_req_node), GFP_KERNEL);
                if(!batch_req) {
                        pr_info("%s: batch_req alloc failed!",__func__);
                        return -ENOMEM;
                }
               batch_req->xss_req = (struct xss_request*)
                        kmalloc(sizeof(struct xss_request), GFP_KERNEL);
                if(!batch_req->xss_req){
                        pr_info("%s: xss_req alloc failed!",__func__);
                        return -ENOMEM;
                }

		for(slot=0; slot < MAX_NUM_BLOCKS; slot++) {
			batch_req->compress_req[slot] = (struct xss_compress_request*)
				kmalloc(sizeof(struct xss_compress_request), GFP_KERNEL);
	                if(!batch_req->compress_req){
	                        pr_info("%s: xss_req alloc failed!",__func__);
	                        return -ENOMEM;
	                }
		}

		sg_init_table(batch_req->sg_in, MAX_NUM_BLOCKS);

                spin_lock_irqsave(&batch_req_list_lock, flags);
                list_add_tail(&batch_req->list, &xss_batch_list);
                spin_unlock_irqrestore(&batch_req_list_lock, flags);
        }

	return 0;
}

int packer_service_init(struct xss_context *xss_ctx)
{
        printk ("%s", __func__);
	return 0;
}

void compress_service_exit(void)
{
	unsigned long flags;
        struct list_head *pos, *next;
	struct xss_batch_req_node *batch_req;
	int slot=0;

        printk ("%s", __func__);
	spin_lock_irqsave(&batch_req_list_lock, flags);
        list_for_each_safe(pos, next, &xss_batch_list){
                batch_req = list_entry(pos, struct xss_batch_req_node, list);
                list_del(pos);
		kfree(batch_req->xss_req);
		for(slot=0; slot < MAX_NUM_BLOCKS; slot++)
			kfree(batch_req->compress_req[slot]);
                kfree(batch_req);
        }
	spin_unlock_irqrestore(&batch_req_list_lock, flags);
}

void packer_service_exit(struct xss_context *xss_ctx)
{
        printk ("%s", __func__);
}

static inline void print_bo(struct xss_bo* bo)
{
	pr_info("%s: handle:%d type:0x%x paddr:%llx addr:%llx ofs:%x len:%d", 
		__func__, bo->handle, bo->type, bo->paddr, bo->uaddr, bo->offset,
		bo->size);
}

static inline void print_req_bos(struct xss_bo** bo_list)
{
	struct xss_bo *ip_bo, *op_bo;
	ip_bo = bo_list[COMPRESS_IP_BO_IDX];
	op_bo = bo_list[COMPRESS_SIZE_BO_IDX];

	if (!ip_bo || !op_bo) {
		pr_err("%s: %llx %llx", __func__, (u64)ip_bo, (u64)op_bo);
		return;
	}

	pr_info("%s: sgl:%d src:%llx dst:%llx sofs:%x dofs:%x len:(%d:%d) "
		"type:(0x%x:0x%x) handle:(%d:%d) paddr:(%llx:%llx)",
		__func__, 1, (u64)ip_bo->uaddr, (u64)op_bo->uaddr, 
		ip_bo->offset, op_bo->offset, ip_bo->size, op_bo->size, 
		ip_bo->type, op_bo->type, ip_bo->handle, op_bo->handle, 
		ip_bo->paddr, op_bo->paddr);
}

static inline void print_ert_pkt(struct ert_start_kernel_cmd *epkt)
{
	int i=0;
	for(;i<epkt->count+1;i++) 
		pr_info("%s: %d:%x", __func__, i, ((u32*)epkt)[i]);
}

static inline void print_compress_request(struct xss_compress_request *xreq, 
				int svc_offset, int cu_index)
{
	pr_info("%s: src:%llx dst:%llx len;%d "
		"svc_offset:%d cu_index:%d", 
		__func__, (u64)xreq->src, (u64)xreq->dst, 
		xreq->src_len, svc_offset, cu_index);
}

void decompress_free_req_bo_list(struct xss_context *ctx, int svc_offset, 
						struct xss_bo **bo_list)
{
	int i;
	unsigned long flags;
	struct xss_bo *bo;
	struct xss_bo_list *free_bo_list;

	free_bo_list = &ctx->free_bo_list[svc_offset];

	spin_lock_irqsave(&free_bo_list->lock, flags);
	for (i=0; i<DECOMPRESS_NUM_BOS; i++){
		bo = bo_list[i];
		if (bo->type & XSS_BO_TYPE_EXEC)
			list_add_tail(&bo->list, &free_bo_list->exec_bos);
		else
			list_add_tail(&bo->list, &free_bo_list->data_bos);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	kfree(bo_list);
}

void packer_free_req_bo_list(struct xss_context *ctx, int svc_offset, 
						struct xss_bo **bo_list)
{
	int i;
	unsigned long flags;
	struct xss_bo *bo;
	struct xss_bo_list *free_bo_list;

	free_bo_list = &ctx->free_bo_list[svc_offset];

	spin_lock_irqsave(&free_bo_list->lock, flags);
	for (i=0; i<PACKER_NUM_BOS; i++){
		bo = bo_list[i];
		if (bo->type & XSS_BO_TYPE_EXEC)
			list_add_tail(&bo->list, &free_bo_list->exec_bos);
		else if (bo->type & XSS_BO_TYPE_P2P)
			list_add_tail(&bo->list, &free_bo_list->dummy_bos);
		else
			list_add_tail(&bo->list, &free_bo_list->data_bos);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	kfree(bo_list);
}

void compress_free_req_bo_list(struct xss_context *ctx, int svc_offset, 
						struct xss_bo **bo_list)
{
	int i;
	unsigned long flags;
	struct xss_bo *bo;
	struct xss_bo_list *free_bo_list;

	free_bo_list = &ctx->free_bo_list[svc_offset];

	spin_lock_irqsave(&free_bo_list->lock, flags);
	for (i=0; i<COMPRESS_NUM_BOS; i++){
		bo = bo_list[i];
		if (bo->type & XSS_BO_TYPE_EXEC)
			list_add_tail(&bo->list, &free_bo_list->exec_bos);
		else if (bo->type & XSS_BO_TYPE_P2P)
			list_add_tail(&bo->list, &free_bo_list->dummy_bos);
		else
			list_add_tail(&bo->list, &free_bo_list->data_bos);
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	kfree(bo_list);
}

static int decompress_setup_ert_packet(struct xss_context *ctx, 
					struct xss_compress_request *compress_req,
					struct xss_bo **bo_list, 
					int cu_index)
{
	int ert_packet_size;
	uint32_t block_size_in_kb = 64;
	uint64_t ip_bo_paddr, op_bo_paddr;
	struct ert_start_kernel_cmd *ert_packet;

	ip_bo_paddr = bo_list[DECOMPRESS_IP_BO_IDX]->paddr + 
			bo_list[DECOMPRESS_IP_BO_IDX]->offset; 
	op_bo_paddr = bo_list[DECOMPRESS_OP_BO_IDX]->paddr + 
			bo_list[DECOMPRESS_OP_BO_IDX]->offset; 

	ert_packet = (struct ert_start_kernel_cmd *) 
				bo_list[DECOMPRESS_EXEC_BO_IDX]->vaddr;

	if (!ert_packet) {
	        pr_info("%s: Cannot get ert packket for exec_handle!", __func__);
	        return -EFAULT;
	}

	ert_packet_size = DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_OFFSET) + 
				DECOMPRESS_KARG_SIZE(LZ4_DECOMP_OFFSET) + 1;

	memset(ert_packet, 0, ert_packet_size);

	ert_packet->state   = ERT_CMD_STATE_NEW;
	ert_packet->opcode  = ERT_START_CU;
	ert_packet->count   = ert_packet_size;
	ert_packet->cu_mask = 1 << cu_index;
	ert_packet->type    = ERT_CU;
	ert_packet->extra_cu_masks = 0;

	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_INPUT_BO)]   = LOWER_WORD(ip_bo_paddr);
	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_INPUT_BO)+1] = UPPER_WORD(ip_bo_paddr);

	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_OUTPUT_BO)]   = LOWER_WORD(op_bo_paddr);
	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_OUTPUT_BO)+1] = UPPER_WORD(op_bo_paddr);

	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_INPUT_SIZE)] = compress_req->src_len;
	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_BLOCK_SIZE_IN_KB)] = block_size_in_kb;
	ert_packet->data[DECOMPRESS_KARG_OFFSET(LZ4_DECOMP_OFFSET)] = compress_req->offset;

	//print_ert_pkt(ert_packet);
	return 0;
}

static int compress_setup_ert_packet(struct xss_context *ctx, 
					struct xss_compress_request *compress_req,
					struct xss_bo **bo_list, 
					int cu_index, uint64_t p2p_base_addr, int slots)
{
	int ert_packet_size;
	uint64_t ip_bo_paddr, comp_size_bo_paddr;
	struct ert_start_kernel_cmd *ert_packet;
#ifdef XSS_FA_BASED_KERNEL
	fa_desc_entry_t *desc_entry;
	int off = 0, i;
#endif

	ip_bo_paddr = bo_list[COMPRESS_IP_BO_IDX]->paddr + 
			bo_list[COMPRESS_IP_BO_IDX]->offset; 
	comp_size_bo_paddr = bo_list[COMPRESS_SIZE_BO_IDX]->paddr + 
			bo_list[COMPRESS_SIZE_BO_IDX]->offset; 


	ert_packet = (struct ert_start_kernel_cmd *) 
				bo_list[COMPRESS_EXEC_BO_IDX]->vaddr;
	if (!ert_packet) {
	        pr_info("%s: Cannot get ert packket for exec_handle!", __func__);
	        return -EFAULT;
	}

#ifdef XSS_FA_BASED_KERNEL
    ert_packet->state = ERT_CMD_STATE_NEW;
    ert_packet->opcode = ERT_START_FA;
    ert_packet->type = ERT_CU;
    ert_packet->cu_mask = 1 << cu_index;
    ert_packet->count = 32;     //w.r.t cu_fa_get_desc_size() in xrt

	ert_packet->data[0] = 0;
	ert_packet->data[1] = MAX_LZ4_COMPRESS_ARGS - 1;
	ert_packet->data[2] = MAX_LZ4_COMPRESS_ARGS_SIZE;
	ert_packet->data[3] = 0;
	ert_packet->data[4] = 0;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[LZ4_COMPRESS].kargs[LZ4_COMP_INPUT_BO].offset;
    desc_entry->arg_size = sizeof(ip_bo_paddr);
    memcpy(desc_entry->arg_value, &ip_bo_paddr, sizeof(ip_bo_paddr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
    desc_entry->arg_offset = supported_kernels[LZ4_COMPRESS].kargs[LZ4_COMP_OUTPUT_BO].offset;
    desc_entry->arg_size = sizeof(p2p_base_addr);
    memcpy(desc_entry->arg_value, &p2p_base_addr, sizeof(p2p_base_addr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
    desc_entry->arg_offset = supported_kernels[LZ4_COMPRESS].kargs[LZ4_COMP_COMPRESSED_SIZE_BO].offset;
    desc_entry->arg_size = sizeof(comp_size_bo_paddr);
    memcpy(desc_entry->arg_value, &comp_size_bo_paddr, sizeof(comp_size_bo_paddr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[LZ4_COMPRESS].kargs[LZ4_COMP_NUM_BLOCKS].offset;
    desc_entry->arg_size = sizeof(slots);
    memcpy(desc_entry->arg_value, &slots, sizeof(slots));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

#else
	ert_packet_size = COMPRESS_KARG_OFFSET(LZ4_COMP_NUM_BLOCKS) +
				COMPRESS_KARG_SIZE(LZ4_COMP_NUM_BLOCKS) + 1;

	memset(ert_packet, 0, ert_packet_size);

	ert_packet->state   = ERT_CMD_STATE_NEW;
	ert_packet->opcode  = ERT_START_CU;
	ert_packet->count   = ert_packet_size;
	ert_packet->cu_mask = 1 << cu_index;
	ert_packet->type    = ERT_CU;
	ert_packet->extra_cu_masks = 0;

	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_INPUT_BO)]   = LOWER_WORD(ip_bo_paddr);
	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_INPUT_BO)+1] = UPPER_WORD(ip_bo_paddr);

	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_OUTPUT_BO)]   = LOWER_WORD(p2p_base_addr);
	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_OUTPUT_BO)+1] = UPPER_WORD(p2p_base_addr);

	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_COMPRESSED_SIZE_BO)]   = LOWER_WORD(comp_size_bo_paddr);
	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_COMPRESSED_SIZE_BO)+1] = UPPER_WORD(comp_size_bo_paddr);

	ert_packet->data[COMPRESS_KARG_OFFSET(LZ4_COMP_NUM_BLOCKS)] = slots;
#endif
	//print_ert_pkt(ert_packet);
	return 0;
}

static int packer_setup_ert_packet(struct xss_context *ctx, 
					struct xss_packer_request *packer_req,
					struct xss_bo **bo_list, 
					int cu_index, uint64_t p2p_base_addr)
{
	int ert_packet_size;
	uint64_t ip_bo_paddr, op_bo_paddr;
	struct ert_start_kernel_cmd *ert_packet;
#ifdef XSS_FA_BASED_KERNEL
	int num_fragments = (int)packer_req->src_len;
	fa_desc_entry_t *desc_entry;
	int off = 0;
#endif

	ip_bo_paddr = bo_list[PACKER_IP_BO_IDX]->paddr + 
			bo_list[PACKER_IP_BO_IDX]->offset; 
	op_bo_paddr = bo_list[PACKER_OP_BO_IDX]->paddr + 
			bo_list[PACKER_OP_BO_IDX]->offset; 

	ert_packet = (struct ert_start_kernel_cmd *) 
				bo_list[PACKER_EXEC_BO_IDX]->vaddr;

	if (!ert_packet) {
	        pr_info("%s: Cannot get ert packket for exec_handle!", __func__);
	        return -EFAULT;
	}

#ifdef XSS_FA_BASED_KERNEL
    ert_packet->state = ERT_CMD_STATE_NEW;
    ert_packet->opcode = ERT_START_FA;
    ert_packet->type = ERT_CU;
    ert_packet->cu_mask = 1 << cu_index;
    ert_packet->count = 32;     //w.r.t cu_fa_get_desc_size() in xrt

    ert_packet->data[0] = 0;
    ert_packet->data[1] = MAX_PACKER_ARGS - 1;
    ert_packet->data[2] = MAX_PACKER_ARGS_SIZE;
    ert_packet->data[3] = 0;
    ert_packet->data[4] = 0;

	desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[PACKER].kargs[PACKER_INPUT_BO].offset;
    desc_entry->arg_size = sizeof(p2p_base_addr);
    memcpy(desc_entry->arg_value, &p2p_base_addr, sizeof(p2p_base_addr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[PACKER].kargs[PACKER_OUTPUT_BO].offset;
    desc_entry->arg_size = sizeof(op_bo_paddr);
    memcpy(desc_entry->arg_value, &op_bo_paddr, sizeof(op_bo_paddr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[PACKER].kargs[PACKER_FRAGMENT_INFO_BO].offset;
    desc_entry->arg_size = sizeof(ip_bo_paddr);
    memcpy(desc_entry->arg_value, &ip_bo_paddr, sizeof(ip_bo_paddr));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

    desc_entry = (fa_desc_entry_t *)(&ert_packet->data[5] + off);
	desc_entry->arg_offset = supported_kernels[PACKER].kargs[PACKER_FRAGMENT_COUNT].offset;
    desc_entry->arg_size = sizeof(num_fragments);
    memcpy(desc_entry->arg_value, &num_fragments, sizeof(num_fragments));
    off += (sizeof(fa_desc_entry_t) + desc_entry->arg_size)/4;

#else
	ert_packet_size = PACKER_KARG_OFFSET(PACKER_FRAGMENT_COUNT) + 
				PACKER_KARG_SIZE(PACKER_FRAGMENT_COUNT) + 1;

	memset(ert_packet, 0, ert_packet_size);

	ert_packet->state   = ERT_CMD_STATE_NEW;
	ert_packet->opcode  = ERT_START_CU;
	ert_packet->count   = ert_packet_size;
	ert_packet->cu_mask = 1 << cu_index;
	ert_packet->type    = ERT_CU;
	ert_packet->extra_cu_masks = 0;

	ert_packet->data[PACKER_KARG_OFFSET(PACKER_INPUT_BO)]   = LOWER_WORD(p2p_base_addr);
	ert_packet->data[PACKER_KARG_OFFSET(PACKER_INPUT_BO)+1] = UPPER_WORD(p2p_base_addr);

	ert_packet->data[PACKER_KARG_OFFSET(PACKER_OUTPUT_BO)]   = LOWER_WORD(op_bo_paddr);
	ert_packet->data[PACKER_KARG_OFFSET(PACKER_OUTPUT_BO)+1] = UPPER_WORD(op_bo_paddr);

	ert_packet->data[PACKER_KARG_OFFSET(PACKER_FRAGMENT_INFO_BO)]   = LOWER_WORD(ip_bo_paddr);
	ert_packet->data[PACKER_KARG_OFFSET(PACKER_FRAGMENT_INFO_BO)+1] = UPPER_WORD(ip_bo_paddr);

	ert_packet->data[PACKER_KARG_OFFSET(PACKER_FRAGMENT_COUNT)] = packer_req->src_len;
#endif
	//print_ert_pkt(ert_packet);
	return 0;
}

struct xss_bo** decompress_setup_req_bo_list(struct xss_context *ctx, 
				struct xss_compress_request *compress_req)
{
	unsigned long flags;
	int svc_offset;

	struct xss_bo *bo; 
	struct xss_bo_list *free_bo_list;
	struct xss_bo **bo_list;

	bo_list = (struct xss_bo **)kzalloc(DECOMPRESS_NUM_BOS*
					sizeof(struct xss_bo*), GFP_KERNEL);
	if (!bo_list) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return NULL;
	}

	svc_offset = xss_service_offset_in_ctx(ctx, compress_services[compress_req->compress]);
	if (svc_offset<0)
		return NULL;

	free_bo_list = &ctx->free_bo_list[svc_offset];
	spin_lock_irqsave(&free_bo_list->lock, flags);

	bo = xss_get_bo(&free_bo_list->exec_bos);
	if (!bo)
		goto out;
	bo->type = XSS_BO_TYPE_EXEC;
	bo_list[DECOMPRESS_EXEC_BO_IDX] = bo;

	bo         = xss_get_bo(&free_bo_list->data_bos);
	if (!bo)
		goto out;

	bo->uaddr  = (u64)compress_req->src;
	bo->size   = 4096; 
	bo->type   = XSS_BO_TYPE_BUF;
	bo->type  |= XSS_BO_TYPE_INPUT;
	bo->offset = 0;
	bo_list[DECOMPRESS_IP_BO_IDX] = bo;

	bo = xss_get_bo(&free_bo_list->data_bos);
	if (!bo)
		goto out;

	bo->uaddr  = (u64)compress_req->dst;
	bo->size   = 4096; 
	bo->type   = XSS_BO_TYPE_BUF;
	bo->type  |= XSS_BO_TYPE_OUTPUT;
	bo->offset = 0;
	bo_list[DECOMPRESS_OP_BO_IDX] = bo;

	spin_unlock_irqrestore(&free_bo_list->lock, flags);

	//print_req_bos(bo_list);
	return bo_list;
out:
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	decompress_free_req_bo_list(ctx, svc_offset, bo_list);
	return NULL;
}

struct xss_bo** packer_setup_req_bo_list(struct xss_context *ctx, 
		struct xss_packer_request *packer_req, uint64_t *p2p_addr)
{
	unsigned long flags;
	int svc_offset;

	struct page *data_page, *out_page;
	struct xss_bo *bo, *p2p_bo; 

	struct xss_bo_list *free_bo_list;
	struct xss_bo **bo_list;
	int compressed_size;
	uint16_t slot;
	uint32_t *fragment_info = (uint32_t *)packer_req->src;
	int num_fragments = (int)packer_req->src_len;
	char **offset = (char **)packer_req->offset;

	for (slot = 0; slot < num_fragments; slot++) {
		data_page = virt_to_page(offset[slot]);
		if (is_user_ptr_p2p(data_page, ctx, &p2p_bo)) 
			fragment_info[slot*3 + 40] = get_p2p_page_offset(data_page, p2p_bo);
		else
			printk("%s: fragment info offset is not filled for slot:%d\n",__func__,slot);
	}

	*p2p_addr = p2p_bo->paddr;
	compressed_size = fragment_info[(num_fragments-1)*3 + 42] + fragment_info[(num_fragments-1)*3 + 41] - 40;

	bo_list = (struct xss_bo **)kzalloc(PACKER_NUM_BOS*
					sizeof(struct xss_bo*), GFP_KERNEL);
	if (!bo_list) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return NULL;
	}

	svc_offset = xss_service_offset_in_ctx(ctx, compress_services[2]);
	if (svc_offset<0)
		return NULL;

	free_bo_list = &ctx->free_bo_list[svc_offset];
	spin_lock_irqsave(&free_bo_list->lock, flags);

	bo = xss_get_bo(&free_bo_list->exec_bos);
	if (!bo)
		goto out;
	bo->type = XSS_BO_TYPE_EXEC;
	bo_list[PACKER_EXEC_BO_IDX] = bo;

	bo         = xss_get_bo(&free_bo_list->data_bos);
	if (!bo)
		goto out;

	bo->uaddr   = (u64)packer_req->src;
	bo->size   = 4096; 
	bo->type   = XSS_BO_TYPE_BUF;
	bo->type  |= XSS_BO_TYPE_INPUT;
	bo->offset = 0;
	bo_list[PACKER_IP_BO_IDX] = bo;

	out_page = virt_to_page(packer_req->dst);

	if (is_user_ptr_p2p(out_page, ctx, &p2p_bo)) {
		bo         = xss_get_bo(&free_bo_list->dummy_bos);
		if (!bo)
			goto out;

		bo->handle = p2p_bo->handle;
		bo->paddr  = p2p_bo->paddr;
		bo->size   = 0;
		bo->offset = get_p2p_page_offset(out_page, p2p_bo);
		bo->type = XSS_BO_TYPE_P2P;
		bo->type|= XSS_BO_TYPE_OUTPUT;
		bo_list[PACKER_OP_BO_IDX] = bo;
	}
	spin_unlock_irqrestore(&free_bo_list->lock, flags);

	//print_req_bos(bo_list);
	return bo_list;
out:
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	packer_free_req_bo_list(ctx, svc_offset, bo_list);
	return NULL;
}

struct xss_bo** compress_setup_req_bo_list(struct xss_context *ctx, 
				struct xss_compress_request *compress_req,
				struct scatterlist *sg_in, int slots)
{
	unsigned long flags;
	int svc_offset;

	struct xss_bo *bo, *p2p_bo; 
	struct xss_bo_list *free_bo_list;
	struct xss_bo **bo_list;
	struct page *compressed_size = xss_alloc_p2p_page(ctx->ctx_id, GFP_KERNEL);

	if (!compressed_size) {
                pr_info("%s: compressed_size alloc failed!", __func__);
                return NULL;
        }

	bo_list = (struct xss_bo **)kzalloc(COMPRESS_NUM_BOS*
					sizeof(struct xss_bo*), GFP_KERNEL);
	if (!bo_list) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return NULL;
	}

	svc_offset = xss_service_offset_in_ctx(ctx, compress_services[compress_req->compress]);
	if (svc_offset<0)
		return NULL;

	free_bo_list = &ctx->free_bo_list[svc_offset];
	spin_lock_irqsave(&free_bo_list->lock, flags);

	bo = xss_get_bo(&free_bo_list->exec_bos);
	if (!bo)
		goto out;
	bo->type = XSS_BO_TYPE_EXEC;
	bo_list[COMPRESS_EXEC_BO_IDX] = bo;

	if (is_user_ptr_p2p(compressed_size, ctx, &p2p_bo)) {
		bo         = xss_get_bo(&free_bo_list->dummy_bos);
		if (!bo)
			goto out;

		bo->handle = p2p_bo->handle;
		bo->paddr  = p2p_bo->paddr;
		bo->uaddr  = (u64)page_to_virt((struct page*)compressed_size);
		bo->size   = sizeof(uint32_t);
		bo->offset = get_p2p_page_offset(compressed_size, p2p_bo);
		bo->type = XSS_BO_TYPE_P2P;
		bo->type|= XSS_BO_TYPE_OUTPUT;
		bo_list[COMPRESS_SIZE_BO_IDX] = bo;
	}

	bo         = xss_get_bo(&free_bo_list->data_bos);
	if (!bo)
		goto out;

	bo->uaddr   = (u64)sg_in;
	bo->size   = compress_req->src_len * slots;
	bo->type   = XSS_BO_TYPE_SGL;
	bo->type  |= XSS_BO_TYPE_INPUT;
	bo->offset = 0;
	bo_list[COMPRESS_IP_BO_IDX] = bo;

	spin_unlock_irqrestore(&free_bo_list->lock, flags);

	//print_req_bos(bo_list);
	return bo_list;
out:
	spin_unlock_irqrestore(&free_bo_list->lock, flags);
	compress_free_req_bo_list(ctx, svc_offset, bo_list);
	return NULL;
}

static void xss_packer_req_cmpltn(void* data, int status)
{
	int ret=0;
	struct xss_request *req = (struct xss_request *)data;
	struct xss_context *ctx = req->ctx;
	int svc_offset = xss_service_offset_in_ctx(ctx, req->svc_id);
	struct xss_perf_stats *stats;
#ifdef XSS_TRACE_TIME
	uint64_t t1, t2, t3, t4, t5;
#endif

	xss_get_perf_stats(&stats);
	stats = &stats[4];
	atomic_inc(&stats->request_out);
 
#ifdef XSS_TRACE_TIME
        do_gettimeofday(&req->output_tv);
#endif
	if(req->user_cb)
		req->user_cb(req->user_cb_data, ret);	

#ifdef XSS_TRACE_TIME
        do_gettimeofday(&req->end_tv);

        t1 = time_diff(req->process_tv, req->start_tv);
        t2 = time_diff(req->input_tv, req->process_tv);
        t3 = time_diff(req->compute_tv, req->input_tv);
        t4 = time_diff(req->output_tv, req->compute_tv);
        t5 = time_diff(req->end_tv, req->start_tv);

        stats->set_args_time += t1;
        stats->input_tx_time += t2;
        stats->compute_time += t3;
        stats->output_tx_time += t4;
        stats->op_time += t5;
        stats->num_ops += 1;
#endif
	packer_free_req_bo_list(ctx, svc_offset, req->bo_list);
	kfree(req);
}

static void xss_compress_req_cmpltn(void* data, int status)
{
	struct xss_request *req = (struct xss_request *)data;
	struct xss_context *ctx = req->ctx;
	struct xss_bo **bo_list = req->bo_list;
	int svc_offset = xss_service_offset_in_ctx(ctx, req->svc_id);
	struct xss_perf_stats *stats;
	struct xss_batch_req_node *batch_req;
	struct xss_bo *comp_size_bo = bo_list[COMPRESS_SIZE_BO_IDX];
	uint32_t *compressed_size = (uint32_t *)comp_size_bo->uaddr;
	int block;
	unsigned int flags;
#ifdef XSS_TRACE_TIME
	uint64_t t1, t2, t3, t4, t5;

	do_gettimeofday(&req->output_tv);
#endif
	batch_req = (struct xss_batch_req_node*)req->user_cb_data;

	xss_get_perf_stats(&stats);
	if(req->op_dir == XSS_OP_DIR_WRITE) {
		stats = &stats[2];
		atomic_add(batch_req->slots, &stats->request_out);
	} else {
		stats = &stats[3];
		atomic_inc(&stats->request_out);
	}

	for(block = 0; block < batch_req->slots; block++)
	{
		if(req->user_cb) {
			if(req->op_dir == XSS_OP_DIR_WRITE) {
				if (compressed_size[block] >= 4096)
					req->user_cb(batch_req->compress_req[block]->xss_cb.data, 0);
				else if (compressed_size[block] < 0)
					printk("%s: Error! compressed_size: %d\n",__func__,compressed_size[block]);
				else
					req->user_cb(batch_req->compress_req[block]->xss_cb.data, compressed_size[block]);
			} else {
				req->user_cb(req->user_cb_data, 4096);
			}
		}
	}
#ifdef XSS_TRACE_TIME
	do_gettimeofday(&req->end_tv);

	t1 = time_diff(req->process_tv, req->start_tv);
        t2 = time_diff(req->input_tv, req->process_tv);
        t3 = time_diff(req->compute_tv, req->input_tv);
        t4 = time_diff(req->output_tv, req->compute_tv);
        t5 = time_diff(req->end_tv, req->start_tv);

        stats->set_args_time += t1;
        stats->input_tx_time += t2;
        stats->compute_time += t3;
        stats->output_tx_time += t4;
        stats->op_time += t5;
        stats->num_ops += 1;
#endif
	batch_req->slots = 0;
	spin_lock_irqsave(&batch_req_list_lock, flags);
	list_add_tail(&batch_req->list, &xss_batch_list);
	spin_unlock_irqrestore(&batch_req_list_lock, flags);

	if(req->op_dir == XSS_OP_DIR_WRITE)
		xss_free_p2p_page(ctx->ctx_id, (struct page*)virt_to_page(comp_size_bo->uaddr));

	if(req->op_dir == XSS_OP_DIR_WRITE)
		compress_free_req_bo_list(ctx, svc_offset, req->bo_list);
	else
		decompress_free_req_bo_list(ctx, svc_offset, req->bo_list);
}

int xss_packer(int ctx_id, struct xss_packer_request *packer_req)
{
	struct xss_context *ctx = xss_get_ctx_struct(ctx_id);
	int ret = 0;
	int svc_offset;
	int cu_index;
	struct xss_request *xss_req;
	struct xss_bo **bo_list;
	struct xss_perf_stats *stats;
	uint64_t p2p_base_addr;

	xss_get_perf_stats(&stats);
		atomic_inc(&stats[4].request_in);

	svc_offset = xss_service_offset_in_ctx(ctx, compress_services[2]);
	if (svc_offset<0)
		return svc_offset;

	cu_index = xss_get_service_cu(ctx, svc_offset, compress_kernels[2]);
	if (cu_index<0)
		return svc_offset;

	xss_req = (struct xss_request *)
		kmalloc(sizeof(struct xss_request), GFP_KERNEL);
	if (!xss_req) {
		pr_info("%s: xss_req alloc failed!", __func__);
		return -ENOMEM;
	}

#ifdef XSS_TRACE_TIME
	do_gettimeofday(&xss_req->start_tv);
#endif
	bo_list = packer_setup_req_bo_list(ctx, packer_req, &p2p_base_addr);
	if (!bo_list) {
		pr_info("%s: No free BufferObjects!!", __func__);
		kfree(xss_req);
		return -ENOMEM;
	}

	ret = packer_setup_ert_packet(ctx, packer_req, bo_list, cu_index, p2p_base_addr);
	if (ret)
		goto out;

	xss_req->ctx      = ctx;
	xss_req->svc_id   = compress_services[2];
	xss_req->cu_index = cu_index;
	xss_req->bo_list  = bo_list;
	xss_req->num_bos  = PACKER_NUM_BOS;
	xss_req->op_dir   = XSS_OP_DIR_WRITE;
	xss_req->complete = xss_packer_req_cmpltn;
	xss_req->user_cb  = packer_req->xss_cb.func;
	xss_req->user_cb_data = packer_req->xss_cb.data;
	xss_req->exec_cb  = NULL;
	xss_req->dma_cb  = NULL;

#ifdef XSS_TRACE_TIME
	do_gettimeofday(&xss_req->process_tv);
#endif
	if ((ret = xss_submit_request(xss_req)) < 0)
		goto out;
	
	return -EINPROGRESS;
out:
	packer_free_req_bo_list(ctx, svc_offset, bo_list);
	kfree(xss_req);
	return ret;
}
EXPORT_SYMBOL_GPL(xss_packer);

int prepare_batch_request(struct xss_batch_req_node *batch_req)
{
	int ret = 0;
	int svc_offset;
	int cu_index;
	struct xss_request *xss_req;
	struct xss_bo **bo_list;
	int block;
	struct xss_context *ctx = xss_get_ctx_struct(batch_req->ctx_id);
	int slots = batch_req->slots;

	svc_offset = xss_service_offset_in_ctx(ctx, compress_services[batch_req->compress_req[0]->compress]);
	if (svc_offset<0)
		return svc_offset;

	cu_index = xss_get_service_cu(ctx, svc_offset, compress_kernels[batch_req->compress_req[0]->compress]);
	if (cu_index<0)
		return svc_offset;

	sg_mark_end(&batch_req->sg_in[slots - 1]);
	xss_req = batch_req->xss_req;

	bo_list = compress_setup_req_bo_list(ctx, batch_req->compress_req[0], batch_req->sg_in, slots);
	if (!bo_list) {
		pr_info("%s: No free BufferObjects!!", __func__);
		kfree(xss_req);
		return -ENOMEM;
	}

	struct xss_bo *comp_size_bo = bo_list[COMPRESS_SIZE_BO_IDX];
	uint32_t *compressed_size = (uint32_t *)comp_size_bo->uaddr;
	struct page *out_page;
	struct xss_bo *p2p_bo;

	for (block=0; block < slots; block++) {
		out_page = virt_to_page(batch_req->compress_req[block]->dst);
		if (is_user_ptr_p2p(out_page, ctx, &p2p_bo))
			compressed_size[32+block] = get_p2p_page_offset(out_page, p2p_bo);
	}

	ret = compress_setup_ert_packet(ctx, batch_req->compress_req[0], bo_list, cu_index, p2p_bo->paddr, slots);
	if (ret)
		goto out;

	xss_req->ctx      = ctx;
	xss_req->svc_id   = compress_services[batch_req->compress_req[0]->compress];
	xss_req->cu_index = cu_index;
	xss_req->bo_list  = bo_list;
	xss_req->num_bos  = COMPRESS_NUM_BOS;
	xss_req->op_dir   = XSS_OP_DIR_WRITE;
	xss_req->complete = xss_compress_req_cmpltn;
	xss_req->user_cb  = batch_req->compress_req[0]->xss_cb.func;
	xss_req->user_cb_data = batch_req;
	xss_req->exec_cb  = NULL;
	xss_req->dma_cb  = NULL;

#ifdef XSS_TRACE_TIME
	do_gettimeofday(&xss_req->process_tv);
#endif
	if ((ret = xss_submit_request(xss_req)) < 0)
		goto out;
	return ret;
out:
	compress_free_req_bo_list(ctx, svc_offset, bo_list);
	kfree(xss_req);
	return ret;

}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0)
void submit_batch_request(struct timer_list *timer)
#else
void submit_batch_request(unsigned long arg)
#endif
{
	int ret=0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0)
	struct xss_batch_req_node *batch_req = from_timer(batch_req, timer, batch_timer);
#else
	struct xss_batch_req_node *batch_req = (struct xss_batch_req_node*)arg; 
#endif
	unsigned long flags;

	spin_lock_irqsave(&batch_req_list_lock, flags);
	list_del(&batch_req->list);
	spin_unlock_irqrestore(&batch_req_list_lock, flags);

	ret = prepare_batch_request(batch_req);
	if (ret < 0)
		printk("prepare_batch_request\n");
}

int xss_compress(int ctx_id, struct xss_compress_request *compress_req)
{
	int ret = 0;
	struct xss_request *xss_req;
	struct xss_perf_stats *stats;
	unsigned long flags;
	int slot_id = 0;
	struct xss_batch_req_node *batch_req;

	if(IS_SGL(compress_req))
		return -ENOTSUPP;

	xss_get_perf_stats(&stats);
	if (compress_req->compress)
		atomic_inc(&stats[2].request_in);
	else
		atomic_inc(&stats[3].request_in);

	/* Batching */
	spin_lock_irqsave(&batch_req_list_lock, flags);
        batch_req = list_first_entry_or_null(&xss_batch_list,
				struct xss_batch_req_node, list);
        if(!batch_req) {
                pr_info("%s: no batch_req available in free list!", __func__);
		spin_unlock_irqrestore(&batch_req_list_lock, flags);
                ret = -ENOMEM;
                return ret;
        }
	xss_req = batch_req->xss_req;
	slot_id = batch_req->slots;
	batch_req->slots++;

	if (slot_id == 0) {
#ifdef XSS_TRACE_TIME
		do_gettimeofday(&xss_req->start_tv);
#endif
		batch_req->ctx_id =  ctx_id;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0)
		timer_setup(&batch_req->batch_timer, submit_batch_request, 0);
#else
		setup_timer(&batch_req->batch_timer, submit_batch_request, (unsigned long)batch_req);
#endif
		mod_timer(&batch_req->batch_timer, jiffies + usecs_to_jiffies(10));
	}
	if(slot_id == (MAX_NUM_BLOCKS - 1))
		list_del(&batch_req->list);

        sg_set_page(&batch_req->sg_in[slot_id], (struct page*)virt_to_page(compress_req->src), 4096, 0);
	memcpy(batch_req->compress_req[slot_id], compress_req, sizeof(struct xss_compress_request));
	spin_unlock_irqrestore(&batch_req_list_lock, flags);

	if(slot_id == (MAX_NUM_BLOCKS - 1)) {
		del_timer(&batch_req->batch_timer);
		if ((ret = prepare_batch_request(batch_req)) < 0) {
			printk("%s: prepare_batch_request Failed\n",__func__);
			return ret;
		}
	}
	return -EINPROGRESS;
}
EXPORT_SYMBOL_GPL(xss_compress);
