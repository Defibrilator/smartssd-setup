/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 *
 * Authors: Amit Kumar <akum@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define MAX_OUTSTANDING_CRYPT_REQS        2048
#define MAX_OUTSTANDING_DECRYPT_REQS      2048
#define MAX_NUM_P2P_PAGES   (MAX_OUTSTANDING_CRYPT_REQS + 32768)
#define MAX_OUTSTANDING_COMPRESS_REQS 3000
#define MAX_COMPRESS_NUM_P2P_PAGES   (MAX_OUTSTANDING_COMPRESS_REQS + 512)
#define CRYPT_BLK_SIZE    4096
#define MAX_NUM_BLOCKS 8
#define COMPRESS_BLK_SIZE    MAX_NUM_BLOCKS*4096
#define PACKER_BLK_SIZE    4096

int crypt_service_init(struct xss_context *xss_ctx);
void crypt_service_exit(struct xss_context *xss_ctx);

int compress_service_init(struct xss_context *xss_ctx);
int packer_service_init(struct xss_context *xss_ctx);
void compress_service_exit(struct xss_context *xss_ctx);
void packer_service_exit(struct xss_context *xss_ctx);

#define AES_XTS_ENCR_SERVICE \
	.svc_id = XSS_SERVICE_AES_XTS_ENCRYPTION, \
	.name = "aes_xts_encryption", \
	.num_kernels = 1, \
	.kernels = {AES_XTS_256_ENCR}, \
	.max_outstanding_reqs = MAX_OUTSTANDING_CRYPT_REQS, \
	.reqd_p2p_pages = MAX_NUM_P2P_PAGES, \
	.blk_size = CRYPT_BLK_SIZE, \
	.init = crypt_service_init, \
	.exit = crypt_service_exit

#define AES_XTS_DECR_SERVICE \
	.svc_id = XSS_SERVICE_AES_XTS_DECRYPTION, \
	.name = "aes_xts_decryption", \
	.num_kernels = 1, \
	.kernels = {AES_XTS_256_DECR}, \
	.max_outstanding_reqs = MAX_OUTSTANDING_DECRYPT_REQS, \
	.reqd_p2p_pages = MAX_NUM_P2P_PAGES, \
	.blk_size = CRYPT_BLK_SIZE, \
	.init = crypt_service_init, \
	.exit = crypt_service_exit

#define LZ4_COMPRESS_SERVICE \
	.svc_id = XSS_SERVICE_LZ4_COMPRESSION, \
	.name = "lz4_compression", \
	.num_kernels = 1, \
	.kernels = {LZ4_COMPRESS}, \
	.max_outstanding_reqs = MAX_OUTSTANDING_COMPRESS_REQS, \
	.reqd_p2p_pages = 0, \
	.blk_size = COMPRESS_BLK_SIZE, \
	.init = compress_service_init, \
	.exit = compress_service_exit

#define LZ4_DECOMPRESS_SERVICE \
	.svc_id = XSS_SERVICE_LZ4_DECOMPRESSION, \
	.name = "lz4_decompression", \
	.num_kernels = 1, \
	.kernels = {LZ4_DECOMPRESS}, \
	.max_outstanding_reqs = MAX_OUTSTANDING_COMPRESS_REQS, \
	.reqd_p2p_pages = 0, \
	.blk_size = COMPRESS_BLK_SIZE, \
	.init = compress_service_init, \
	.exit = compress_service_exit

#define PACKER_SERVICE \
	.svc_id = XSS_SERVICE_PACKER, \
	.name = "packer", \
	.num_kernels = 1, \
	.kernels = {PACKER}, \
	.max_outstanding_reqs = MAX_OUTSTANDING_COMPRESS_REQS, \
	.reqd_p2p_pages = MAX_COMPRESS_NUM_P2P_PAGES, \
	.blk_size = PACKER_BLK_SIZE, \
	.init = packer_service_init, \
	.exit = packer_service_exit
