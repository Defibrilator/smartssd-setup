
Requirement:
============
1. Xilinx Acceleration Card with a valid platform shell 
2. A valid "encryption+decryption" xclbin compatible with shell on the accelration card
3. dmsetup should be installed
4. cryptsetup >= 2.3.1 version

Install Pre-requisites:
=======================
1. Install U.2 platform shell/DSA package
   1. install following debian shell package
      1. apt install ./xilinx-u2-gen3x4-xdma-gc-1-202020-1-dev_1-XXXXXXX_all_XX.04.deb
      2. apt install ./xilinx-u2-gen3x4-xdma-gc-validate_1-XXXXXXX_all_XX.04.deb
      3. apt install ./xilinx-u2-gen3x4-xdma-gc-base_1-XXXXXXX_all_XX.04.deb
   2. Flash the card
      1. xbmgmt flash --shell --card <mgmt-bdf> --primary <xsabin_path> \
          --secondary <xsabin_path> --flash_type spi
      where, <xsabin_path> can be /opt/xilinx/firmware/u2/gen3x4-xdma/base/partition.xsabin.

2. Build and install XRT
   1. cd XRT/build
   2. ./build.sh
   3. cd Release
   4. sudo apt install ./xrt_202010.X.X.X_xx.xx-amd64-xrt.deb
   5. insert xocl in kds mode as root(sudo) user
      1. rmmod xocl; modprobe xocl kds_mode=1

3. All commands should be run with root user.

Build and Install XSS components:
=================================
1. source the XRT setup script
2. cd xss/build
2. ./build.sh -app dm-crypt
3. sudo apt install ./xss-x.x.x-version.deb


Configure xss on xilinx acceleration devices:
============================================
1. list the available usable SmartSSD device
   1. sudo xss_util list-devices
2. List the kernels available in xclbin
   1. sudo xss_util list-kernels **xclbin-file-path**
   (xclbin-file-path is the path where xclbin is kept)

3. Update the /etc/xss.conf file with device information
   1. bdf_address   **xclbin-file-path**   **list-of-CUs**
   (list-of-CUs are CUs which you want to configure, It can be left
    empty to configure all CUs available in xclbin as mentioned
    in next step)

   2. bdf_address   **xclbin-file-path**

4. Load the device configuration with xss_util
   1. sudo xss_util load-config
   2. xss service can also be used to load the configuration 
      ( Not required if already configured with xss_util load-config )
      1. sudo systemctl start xss (XSS service start)
      2. sudo systemctl status xss (to check if XSS service not failed)
      3. Make sure to stop xss before starting again to reload the configuration.

Create a Dm-crypt block device (VD) :
====================================
1. sudo dmsetup create xss-dev --table "0 **nvme-ns-size** crypt capi:xss_aes_xts_async-plain64 \
**512-bit-key**  0 **nvme-ns-path** 0 1 sector_size:4096"

Create a filesystem on the VD:
==========================
1. sudo mkfs.ext4 /dev/mapper/xss-dev

Mount the VD
============
1. sudo mount /dev/mapper/xss-dev /mnt

Unmount the VD
==============
1. sudo umount /mnt

Remove the Dm-crypt block device (VD):
======================================
1. sudo dmsetup remove xss-dev


Steps to configure cryptsetup block device (VD) through XSS:
===========================================================
Pre-requisites:
===============
1. Install cryptsetup version >= 2.3.1
   1. git clone -b v2.3.1 https://gitlab.com/cryptsetup/cryptsetup.git
   2. After installation, verify cryptsetup version with cryptsetup --version. 
2. Make sure xocl driver is loaded in kds_mode
   1. sudo rmmod xocl; sudo modprobe xocl kds_mode=1
3. Make sure xss-driver, xcrypt and dm-crypt are loaded.
4. Update /etc/xss.conf file as mentioned in above step
5. source the XRT setup script if not done
6. sudo xss_util load-config

Setup LUKS format for device
=============================
1. With key-file
   cryptsetup -y -v --cipher capi:xss_aes_xts_async-plain64 --key-size=512 --sector-size=4096 \
--key-file=**key-file-path** --perf-submit_from_crypt_cpus --type luks2 luksFormat **nvme-ns-path**

2. Without key-file
   cryptsetup -y -v --cipher capi:xss_aes_xts_async-plain64 --key-size=512 --sector-size=4096 \
--perf-submit_from_crypt_cpus --type luks2 luksFormat **nvme-ns-path**

Open a target to use encrypted volume
=====================================
1. cryptsetup --key-file=**key-file-path** luksOpen **nvme-ns-path** xss-dev
2. cryptsetup luksOpen **nvme-ns-path** xss-dev (If not key file is used)

Create a filesystem on the VD
=============================
1. sudo mkfs.ext4 /dev/mapper/xss-dev

Mount the VD
============
1. sudo mount /dev/mapper/xss-dev /mnt

Unmount the VD
==============
1. sudo umount /mnt

Close the target
================
1. sudo cryptsetup close xss-dev

Note : **xss-dev** is **xss virtual device name**, It can be renamed to any other name.


Known Issues
============
1. XRT hangs/ crashes randomly while loading/unloadig on system with 24 SmartSSDs.
2. IOMMU should be disabled in system (as intel/amd_iommu=off)
