/*
 * Copyright (C) 2020 Xilinx, Inc. All rights reserved.
 * 
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */ 

#include <arpa/inet.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <assert.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <CL/opencl.h>
#include <vector>
#include <iostream>
#include <chrono>
#include <CL/cl_ext.h>
#include <getopt.h>

////////////////////////////////////////////////////////////////////////////////

//#define ELEM_PER_ITER 16384//65536
#define	ENABLE_EVENT_DEBUG

//#define NIST 1
#define KEYLEN 128
#define IVLEN 32
//#define	ENABLE_EVENT_DEBUG

int NISTVEC;
int DEFAULT;
////////////////////////////////////////////////////////////////////////////////
char *strrev(char *str, int i, int size)
{
  int num_beats= size/32;
for ( int k=1; k<=num_beats; k++) 
{
  	i = k*32-1;
	int j = (k-1)*32;
	
	char ch;
	while (i > j)
	{
	    ch = str[i];
	    str[i] = str[j];
	    str[j] = ch;
	    i--;
	    j++;
	}
}
return str;
}

class Timer {
	std::chrono::high_resolution_clock::time_point mTimeStart;
	public:
	Timer() {
	    reset();
	}
	long long stop() {
	    std::chrono::high_resolution_clock::time_point timeEnd = std::chrono::high_resolution_clock::now();
	    return std::chrono::duration_cast<std::chrono::microseconds>(timeEnd - mTimeStart).count();
	}
	void reset() {
	    mTimeStart = std::chrono::high_resolution_clock::now();
	}
};

int load_file_to_memory(const char *filename, char **result)
{
	unsigned int size = 0;
	FILE *f = fopen(filename, "rb");
	if (f == NULL)
	{
	    *result = NULL;
	    return -1; // -1 means file opening fail
	}
	fseek(f, 0, SEEK_END);
	size = ftell(f);
	fseek(f, 0, SEEK_SET);
	*result = (char *)malloc(size+1);
	if (size != fread(*result, sizeof(char), size, f))
	{
	    free(*result);
	    return -2; // -2 means file reading fail
	}
	fclose(f);
	(*result)[size] = 0;
	return size;
}

int ascii_to_hex(char c)
{
        int num = (int) c;
        if(num < 58 && num > 47)
        {
                return num - 48;
        }
        if(num < 103 && num > 96)
        {
                return num - 87;
        }
        return num;
}


int roundUp(int numToRound, int multiple)
{
	if ((multiple == 0) || (numToRound == 0))
	{
	    return numToRound;
	}
	
	int remainder = numToRound % multiple;
	if (remainder == 0)
	{
	    return numToRound;
	}
	
	return numToRound + multiple - remainder;
}

void event_cb(cl_event event, cl_int ev_status, void* data)
{
	cl_command_type cmd;
	const char* str;
	clGetEventInfo(event, CL_EVENT_COMMAND_TYPE, sizeof(cl_command_type), &cmd, NULL);
	if (cmd == CL_COMMAND_MIGRATE_MEM_OBJECTS)
	{
		str = "Migrate";
	}
	printf("[%s:%#x] Event %s\n", str, cmd, (char*)data);
}

int get_kernel_inputs(char** argv, size_t** aes_key, size_t** aes_iv, char** out, char** in, FILE** fp_data)
{
	size_t iv[4], iv0, iv1, iv2, iv3;
	char buffer_key[10] = "\n";
	char buffer_iv[10] = "\n";
	unsigned char sum;
	char name[10];
	char key[300];
	int iv_num;
	char seq[150];
	char *ptx;
	char *ctx;
	unsigned int length, i;
//	char *in;
	int j,c1,c2,count;
	char filename[20];
	
	FILE *fp=NULL;
	*aes_key = (size_t*) malloc(KEYLEN);
	*aes_iv = (size_t*) malloc(IVLEN);
	memset(*aes_iv, 0, 4*sizeof(size_t));
	memset(iv, 0, 4*sizeof(size_t));
	memset(*aes_key, 0, 4*sizeof(size_t));

	fp =fopen(argv[2],"rb+");
	if(fp == NULL)
	{
		printf("Not able to open file %s\n", argv[2]);
		return EXIT_FAILURE;
	}

	while (!feof(fp))
	{
		fscanf(fp,"%s",name);
		if (!strcmp(name,"PTX") || !strcmp(name, "PT")) {
			ptx = (char *) malloc(length+5);
			fscanf(fp,"%s\n",ptx);
		} else if (!strcmp(name, "LENGTH") || !strcmp(name, "DataUnitLen")) {
			fscanf(fp, "%d\n", &length);
		} else if (!strcasecmp(name,"KEY")) {
			fscanf(fp,"%s\n",key);
		} else if (!strcmp(name,"SEQ") || !strcmp(name, "i")) {
			if (NISTVEC) {
				fscanf(fp,"%d\n", (int*)iv);
			} else { 
				fscanf(fp,"%s\n",seq);
			}
		} else if (!strcmp(name,"CTX") || !strcmp(name, "CT")) {
			ctx = (char *) malloc(length+5);
			fscanf(fp,"%s\n",ctx);
		}
	}
	fclose(fp);
	*in = (char *) malloc((length)/2);
	*out = (char *) malloc((length)/2);

	for(i=0,j=15; j>0, i<KEYLEN; j--,i=i+8)
	{
		strncpy(buffer_key, key+i, 8);
		*(*aes_key + j) = (size_t)strtol(buffer_key, NULL, 16);	
		//printf("key [%d]: %x\n",j,*(*aes_key + j));
	}

	if(NISTVEC == 1) {
		for(i=0, j=3; i<4, j>=0; i++, j--)
		{
			iv0 = (iv[i] & 0x000000ff) << 24;
			iv1 = (iv[i] & 0x0000ff00) << 8;
			iv2 = (iv[i] & 0x00ff0000) >> 8;
			iv3 = (iv[i] & 0xff000000) >> 24;
			*(*aes_iv + j) = iv0 | iv1 | iv2 | iv3;
		} 
	} else {
		for(j=3,i=0; j>=0; i=i+8,j--)
	        {
			strncpy(buffer_iv, seq+i, 8);
		       *(*aes_iv+j)=(size_t) strtol(buffer_iv, NULL, 16);
		//printf("iv [%d]: %x\n",j,*(*aes_iv + j));
		}
	}
       
	for(i=0; i<length; i= i+2)
   	{
        	c1 = ascii_to_hex(ptx[i]);
        	c2 = ascii_to_hex(ptx[i+1]);
        	sum = c1<<4 | c2;
     		*(*in + (i>>1)) = sum;
   	}

	for(i=0; i<length; i= i+2)
        {
                c1 = ascii_to_hex(ctx[i]);
                c2 = ascii_to_hex(ctx[i+1]);
                sum = c1<<4 | c2;
         	*(*out + (i>>1)) = sum;
        }
	if(!strcmp(argv[5], "2"))
	{
		*fp_data =fopen("DATA_IN","wb+");
		if(*fp_data == NULL)
		{
		    	printf("Not able to open file DATA_IN\n");
		    	return EXIT_FAILURE;
		}

		fwrite(*in, length/2, 1, *fp_data); 
	} else {
		strcpy(filename, argv[2]);
		strcat(filename, ".encr");	
		*fp_data = fopen(filename, "rb+");
		if(*fp_data == NULL)
		{
			printf("Not able to open file %s\n", filename);
		        	
			*fp_data =fopen("DATA_IN","wb+");
			if(*fp_data == NULL)
			{
			    	printf("Not able to open file DATA_IN\n");
			    	return EXIT_FAILURE;
			}

			fwrite(*out, length/2, 1, *fp_data); 
		}
		
	}
	free(ptx);
	free(ctx);
   	return 0;
}

int get_kernel_inputs_default(char** argv, size_t** aes_key, size_t** aes_iv, FILE** fp_data)
{
	size_t iv[4], iv0, iv1, iv2, iv3;
	char buffer_key[10] = "\n";
	char buffer_key1[10];
	unsigned char sum;
	char key[300];
	char seq[150];
	char *data;
	unsigned int length, i;
	char *in;
	int j,c1,c2;
	FILE *fp_txt=NULL, *fp_key=NULL, *fp_iv=NULL;

	*aes_key = (size_t*) malloc(KEYLEN);
	*aes_iv = (size_t*) malloc(IVLEN);
	memset(*aes_iv, 0, 4*sizeof(size_t));
	memset(*aes_key, 0, 4*sizeof(size_t));

	fp_txt = fopen(argv[2], "rb+");
	if (fp_txt == NULL)
	{
		printf("Not able to open file %s\n", argv[2]);
		return EXIT_FAILURE;
	}
	fseek(fp_txt, 0, SEEK_END);
	length = ftell(fp_txt); 
	fseek(fp_txt, 0, SEEK_SET);

	fp_key = fopen(argv[3], "rb+");
	if (fp_key == NULL)
	{
		printf("Not able to open file %s\n", argv[3]);
		return EXIT_FAILURE;
	}

	fp_iv = fopen(argv[4],"rb+");
	if (fp_iv == NULL)
	{
		printf("Not able to open file %s\n", argv[4]);
		return EXIT_FAILURE;
	}

	data = (char *) malloc(length);
	fscanf(fp_txt,"%s\n",data);
	fscanf(fp_key,"%s\n",key);
	fscanf(fp_iv,"%s\n",seq);

	fclose(fp_txt);
	fclose(fp_key);
	fclose(fp_iv);

	in = (char *) malloc((length)/2);

	for(i=0,j=15; j>0, i<KEYLEN; j--,i=i+8)
	{
		strncpy(buffer_key, key+i, 8);
		*(*aes_key + j) = (size_t)strtol(buffer_key, NULL, 16);	
	}

	for(j=3,i=0; j>=0; i=i+8,j--)
	{
		strncpy(buffer_key1, seq+i, 8);
		*(*aes_iv + j) = (size_t)strtol(buffer_key1, NULL, 16);	
	}
       
	for(i=0; i<length; i= i+2)
   	{
        	c1 = ascii_to_hex(data[i]);
        	c2 = ascii_to_hex(data[i+1]);
        	sum = c1<<4 | c2;
        	in[i>>1] = sum;
   	}

	*fp_data =fopen("DATA_IN","wb+");
	if(*fp_data == NULL)
	{
	    	printf("Not able to open file DATA_IN\n");
	    	return EXIT_FAILURE;
	}
	fwrite(in, length/2, 1, *fp_data);

	free(in);
	free(data);
   	return 0;
}

static constexpr uint32_t aes_keyx[16] = {
    0xeb5aa3b8,
    0x17750c26,
    0x9d0db966,
    0xbcb9e3b6,
    0x510e08c6,
    0x83956e46,
    0x3bd10f72,
    0x769bf32e,
    0xfa374467,
    0x3386553a,
    0x46f91c6a,
    0x6b25d1b4,
    0x6116fa6f,
    0xd29b1a56,
    0x9c193635,
    0x10ed77d4
  };

constexpr uint32_t aes_keyu[16] = {
	0xd477ed10,
	0x3536199c,
	0x561a9bd2,
	0x6ffa1661,
	0xb4d1256b,
	0x6a1cf946,
	0x3a558633,
	0x674437fa,
	0x2ef39b76,
	0x720fd13b,
	0x466e9583,
	0xc6080e51,
	0xb6e3b9bc,
	0x66b90d9d,
	0x260c7517,
	0xb8a35aeb
};

static constexpr uint32_t aes_ivx[4] = {
    0x149f40ae,
    0x38f1817d,
    0x32ccb7db,
    0xa6ef0e05
  };

int main(int argc, char** argv)
{
	int err;                            // error code returned from api calls
	unsigned int comp_len;
	unsigned int comp_status;
	int* curr_len;
	int* curr_addr;
	
	unsigned int h_data_in_op = 0;
	char* h_data_out;                    // host memory for data_out vector
	unsigned int h_data_out_len_avail ;
	int *h_data_out_status;                 // host memory for data_out_status vector
	
	char *h_data_in;

	struct timeval tv0,tv1,tv2,tv3;      //#########################copy this line ################################
	struct timeval tv4,tv5,tv6,tv7,tv8,tv9;          //##########################copy this line #######################
	
	unsigned long elapsed_time_delay;
	unsigned int flag;
	unsigned int out_length;

	cl_platform_id platform_id;         // platform id
	cl_device_id device_id;             // compute device id
	cl_context context;                 // compute context
	cl_command_queue commands;          // compute command queue
	cl_program program;      // compute programs
	cl_kernel kernel;                   // compute kernel
	
	static char cl_platform_vendor[1001];
	
	    #if defined(SDX_PLATFORM) && !defined(TARGET_DEVICE)
	    	#define STR_VALUE(arg)      #arg
	    	#define GET_STRING(name) STR_VALUE(name)
	    	#define TARGET_DEVICE GET_STRING(SDX_PLATFORM)
	    #endif
	
	//TARGET_DEVICE macro needs to be passed from gcc command line
//static char target_device_name[1001] = DTARGET_DEVICE;
	
	printf("\n");
	
	if (argc < 6 || argc > 7) {
		printf("Usage: %s xclbin textfile Key IV Ctrl <ITERATION_SIZE (KB)>\n", argv[0]);
		return EXIT_FAILURE;
    	}

	gettimeofday(&tv0,NULL);
	
	// Get all platforms and then select Xilinx platform
	cl_platform_id platforms[16];       // platform id
	cl_uint platform_count;
	int platform_found = 0;
	
	//!!
	err = clGetPlatformIDs(16, platforms, &platform_count);
	if (err != CL_SUCCESS)
	{
		printf("Error: Failed to find an OpenCL platform!\n");
		printf("Test failed\n");
		return EXIT_FAILURE;
    	}
	printf("INFO: Found %d platforms\n", platform_count);

	// Find Xilinx Plaftorm
	for (unsigned int iplat=0; iplat<platform_count; iplat++) {
		err = clGetPlatformInfo(platforms[iplat], CL_PLATFORM_VENDOR, 1000, (void *)cl_platform_vendor,NULL);

		if (err != CL_SUCCESS) {
		    printf("Error: clGetPlatformInfo(CL_PLATFORM_VENDOR) failed!\n");
		    printf("Test failed\n");
		    return EXIT_FAILURE;
		}

		if (strcmp(cl_platform_vendor, "Xilinx") == 0) {
		    printf("INFO: Selected platform %d from %s\n", iplat, cl_platform_vendor);
		    platform_id = platforms[iplat];
		    platform_found = 1;
		}
    	}

	if (!platform_found) {
		printf("ERROR: Platform Xilinx not found. Exit.\n");
		return EXIT_FAILURE;
	}

	// Get Accelerator compute device
	cl_uint num_devices;
	unsigned int device_found = 0;
	cl_device_id devices[16];  // compute device id
	static char cl_device_name[1001];
	
	//!!
	err = clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_ACCELERATOR, 16, devices, &num_devices);
	printf("INFO: Found %d devices\n", num_devices);
	if (err != CL_SUCCESS) {
		printf("ERROR: Failed to create a device group!\n");
		printf("ERROR: Test failed\n");
		return -1;
    	}

	//iterate all devices to select the target device.
	for (unsigned int i=0; i<num_devices; i++) {
		err = clGetDeviceInfo(devices[i], CL_DEVICE_NAME, 1024, cl_device_name, 0);
		if (err != CL_SUCCESS) {
			printf("Error: Failed to get device name for device %d!\n", i);
			printf("Test failed\n");
			return EXIT_FAILURE;
		}
		printf("CL_DEVICE_NAME %s\n", cl_device_name);
//		if(strcmp(cl_device_name, target_device_name) == 0) {
			device_id = devices[i];
			device_found = 1;
			printf("Selected %s as the target device\n", cl_device_name);
//		}
	}

//	if (!device_found) {
//		printf("Target device %s not found. Exit.\n", target_device_name);
//		return EXIT_FAILURE;
//	}

	// Create a compute context
	context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
	if (!context) {
		printf("Error: Failed to create a compute context!\n");
		printf("Test failed\n");
		return EXIT_FAILURE;
	}

	// Create a command commands (out of order added for sw pipeline)
	//commands = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE | CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE, &err);
	commands = clCreateCommandQueue(context,device_id,CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE,&err);
	if (!commands) {
		printf("Error: Failed to create a command commands!\n");
		printf("Error: code %i\n",err);
		printf("Test failed\n");
		return EXIT_FAILURE;
	}

	int status;
	
	// Create Program Objects
	// Load binary from disk
	unsigned char *kernelbinary;
	char *xclbin = argv[1];
	
	int aes_ctrl;

	if (!sscanf(argv[5], "%d", &aes_ctrl)) {
		printf("You must enter an integer for ITERATION_SIZE command line option, you entered %s\n", argv [ 5 ] );
		return EXIT_FAILURE;
	}

	printf("aes_ctrl is %d\n", aes_ctrl);

	size_t* aes_key;
	size_t* aes_iv;
	char* cipher_txt;
	char* plain_txt;

	FILE *fp=NULL;
	FILE *fp_data=NULL;
//	unsigned int length;
	int c;

	while (1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"randvec",	no_argument, 	   0,  'r' },
			{"nistvec",	no_argument,	   0,  'n' },
			{"defaultvec",	no_argument,	   0,  'd' },
			{NULL,0,NULL,0}
		};
		c = getopt_long(argc, argv, "rnd",
				long_options, &option_index);

		if (c == -1)
			break;

		switch(c) {
			case 'r':
				//get_kernel_inputs(argv, &aes_key, &aes_iv, &cipher_txt, &plain_txt, &fp_data);
				get_kernel_inputs(argv, &aes_key, &aes_iv, &cipher_txt, &plain_txt, &fp_data);
				break;
			case 'n':
				NISTVEC = 1;
				get_kernel_inputs(argv, &aes_key, &aes_iv, &cipher_txt, &plain_txt, &fp_data);
				break;
			case 'd':
				DEFAULT = 1;
				get_kernel_inputs_default(argv, &aes_key, &aes_iv, &fp_data);
				break;
		}
	}
	//------------------------------------------------------------------------------
	// xclbin
	//------------------------------------------------------------------------------
	printf("INFO: loading xclbin %s\n", xclbin);
	printf("\n");
	
	int n_i0 = load_file_to_memory(xclbin, (char **) &kernelbinary);
	if (n_i0 < 0) {
		printf("failed to load kernel from xclbin: %s\n", xclbin);
		printf("Test failed\n");
		return EXIT_FAILURE;
	}

	size_t n0 = n_i0;
	
	// Create the compute program from offline
	program = clCreateProgramWithBinary(context, 1, &device_id, &n0,
	        (const unsigned char **) &kernelbinary, &status, &err);
	
	if ((!program) || (err!=CL_SUCCESS)) {
		printf("Error: Failed to create compute program from binary %d!\n", err);
		printf("Test failed\n");
		return EXIT_FAILURE;
    	}

	gettimeofday(&tv1,NULL);
	
	// Fill our data sets with pattern
	// Read from the file
	fseek(fp_data,0,SEEK_END);
	unsigned int length_data=ftell(fp_data); 
	size_t size = length_data;
  
	fseek(fp_data,0,SEEK_SET);
	size_t align = 4096;
	
	if (posix_memalign((void **)&h_data_in, align, length_data)) {
	    printf("Failed to allocate 4k aligned memory for h_data_in\n");
	    return EXIT_FAILURE;
	}
	if (length_data != fread(h_data_in, sizeof(uint8_t), size, fp_data))
	{
	    free(h_data_in);
	    return EXIT_FAILURE;
	}
	fclose(fp_data);
	
	//strrev(h_data_in, 32, length_data);
	h_data_in_op = 0;
	h_data_out_len_avail = length_data;
	//h_data_out_len_avail =  length ;
	
	// Create and Open output file
	static char filename [1024];

	strcpy ( filename, argv[3] );

	if(aes_ctrl ==2)
	strcat ( filename, ".encr" );

	else if(aes_ctrl ==3)
	strcat ( filename, ".decr" );

	fp =fopen(filename,"wb");
	if(fp == NULL)
	{
		printf("Not able to open file %s\n", filename);
	} else {
		printf("Creating output file %s\n", filename);
	}

	gettimeofday(&tv2,NULL);

	// Build the program executable
	err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if (err != CL_SUCCESS) {
		size_t len;
		static char buffer[2048];

		printf("Error: Failed to build program executable!\n");
		clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
		printf("%s\n", buffer);
		printf("Test failed\n");
		return EXIT_FAILURE;
    	}

	gettimeofday(&tv3,NULL);
	// Create the compute kernel in the program we wish to run
	if(aes_ctrl ==2){
		kernel = clCreateKernel(program, "fa_aes_xts2_rtl_enc", &err);
		if (!kernel || err != CL_SUCCESS) {
		    	printf("Error: Failed to create compute kernel!\n");
		    	printf("Test failed\n");
		    	return EXIT_FAILURE;
		}
	}
	if(aes_ctrl ==3){
		kernel = clCreateKernel(program, "fa_aes_xts2_rtl_dec", &err);
		if (!kernel || err != CL_SUCCESS) {
		    	printf("Error: Failed to create dec compute kernel!\n");
		    	printf("Test failed\n");
		    	return EXIT_FAILURE;
		}
	}
	
	// Create the input and output arrays in device memory for our calculation
	gettimeofday(&tv4,NULL);
	
	// We will break down our problem into multiple iterations. Each iteration
	// will perform computation on a subset of the entire data-set.
	unsigned int elements_per_iteration; // = ELEM_PER_ITER;
	unsigned int elements_per_iteration_aligned;

	elements_per_iteration=length_data;
	printf("Using 4k aligned ITERATION_SIZE = %d bytes\n", elements_per_iteration);
	elements_per_iteration_aligned = roundUp(elements_per_iteration,4096);
	elements_per_iteration = elements_per_iteration_aligned;
	
	printf("Using 4k aligned ITERATION_SIZE = %d bytes\n", elements_per_iteration);
	
	size_t remaining_bytes = length_data;
	size_t data_in_transfer_size;
	size_t bytes_per_iteration;
	unsigned int plusOne;
	unsigned int num_iterations;
	size_t h_data_out_status_len;
	
	// Initial value of data_in_transfer_size, last iteration may change
	if (length_data > elements_per_iteration) {
		data_in_transfer_size = elements_per_iteration;
		bytes_per_iteration = elements_per_iteration * sizeof(char);
		plusOne = ((length_data % elements_per_iteration) > 0) ? 1 : 0;
		num_iterations = (length_data / elements_per_iteration) + plusOne;
	} else {
		data_in_transfer_size = length_data;

		bytes_per_iteration = length_data * sizeof(char);
		plusOne = 0;
		num_iterations = 1;
	}

	printf("num_iterations = %d\n",num_iterations);
	// Only use 2 integers worth of data, but want to avoid the unaligned host pointer messages
	h_data_out_status_len = 4096 * num_iterations;
	
	curr_len =(int*) malloc(num_iterations * sizeof (int) );
	curr_addr =(int*) malloc(num_iterations * sizeof (int) );
	
	if (posix_memalign((void **)&h_data_out_status, align, h_data_out_status_len * sizeof(int))) {
	    	printf("Failed to allocate 4k aligned memory for h_data_out_status\n");
	}
	
	printf("Transfer will take %d iteration(s) of %lu bytes to fully transfer file\n", num_iterations, data_in_transfer_size);
	printf("\n");
	
	if (posix_memalign((void **)&h_data_out, align, h_data_out_len_avail)) {
	    	printf("Failed to allocate 4k aligned memory for h_data_out\n");
	    	return EXIT_FAILURE;
	}
	
	// Start the pipelining
	cl_int err1;
	std::vector<cl_mem> data_in_vector(num_iterations,0);
	std::vector<cl_mem> data_out_vector(num_iterations,0);
	std::vector<cl_mem> data_out_status_vector(num_iterations,0);
	
	std::vector<cl_event> wrEvents1(num_iterations);
	std::vector<cl_event> wrEvents2(num_iterations);
	std::vector<cl_event> wrEvents3(num_iterations);
	std::vector<cl_event> rdEvents1(num_iterations);
	std::vector<cl_event> rdEvents2(num_iterations);
	std::vector<cl_event> cuEvents(num_iterations);
	cl_mem_ext_ptr_t in_ext[26000];
	cl_mem_ext_ptr_t out_ext[26000];
	cl_mem_ext_ptr_t out_status_ext[26000];
	cl_event currWrEvents[3] = {0, 0, 0};
	
	currWrEvents[0] = clCreateUserEvent(context, &err);
	if (err != CL_SUCCESS) {
	    	std::cout << "1" << "\n";
	    	return err;
	}
	
	currWrEvents[1] = clCreateUserEvent(context, &err);
	if (err != CL_SUCCESS) {
	    	std::cout << "2" << "\n";
	    	return err;
	}
	
	currWrEvents[2] = clCreateUserEvent(context, &err);
	if (err != CL_SUCCESS) {
	    	std::cout << "3" << "\n";
	    	return err;
	}
	
	err = clSetUserEventStatus(currWrEvents[0], CL_COMPLETE);
	if (err != CL_SUCCESS) {
	    	std::cout << "4" << "\n";
	    	return err;
	}
	
	err = clSetUserEventStatus(currWrEvents[1], CL_COMPLETE);
	if (err != CL_SUCCESS) {
	    	std::cout << "5" << "\n";
	    	return err;
	}
	
	err = clSetUserEventStatus(currWrEvents[2], CL_COMPLETE);
	if (err != CL_SUCCESS) {
	    	std::cout << "6" << "\n";
	    	return err;
	}
	
	remaining_bytes = length_data;
	Timer t;
	
	// Loop to build all the buffers for pipelining
	for (unsigned int i = 0; i < num_iterations; i++) {
	    	in_ext[i].flags = XCL_MEM_DDR_BANK0;
	    	in_ext[i].obj = &h_data_in[i*elements_per_iteration];
	    	in_ext[i].param = 0;
	
	    	out_ext[i].flags = XCL_MEM_DDR_BANK0;
	    	out_ext[i].obj = &h_data_out[i*elements_per_iteration];
	    	out_ext[i].param = 0;
	
	    	out_status_ext[i].flags = XCL_MEM_DDR_BANK0;
	    	out_status_ext[i].obj = &h_data_out_status[i*elements_per_iteration];
	    	out_status_ext[i].param = 0;

		data_in_vector[i] = clCreateBuffer(context,  CL_MEM_READ_ONLY | CL_MEM_EXT_PTR_XILINX |
                                        CL_MEM_USE_HOST_PTR,  bytes_per_iteration, &in_ext[i], NULL);
                data_out_vector[i] = clCreateBuffer(context, CL_MEM_WRITE_ONLY | CL_MEM_EXT_PTR_XILINX |
                                        CL_MEM_USE_HOST_PTR,  bytes_per_iteration , &out_ext[i], NULL);
                data_out_status_vector[i] = clCreateBuffer(context, CL_MEM_WRITE_ONLY | CL_MEM_EXT_PTR_XILINX |
                                        CL_MEM_USE_HOST_PTR, 2*sizeof(int), &out_status_ext[i], NULL);

	
	    	// Keep track of how many bytes remain in file
	    	if (remaining_bytes > elements_per_iteration) {
	    	    remaining_bytes = remaining_bytes - elements_per_iteration;
	    	} else {
	    	    remaining_bytes = 0;
	    	}
	
	    	// Only ask for the number of bytes that are left on the last iteration
	    	if (remaining_bytes > elements_per_iteration) {
	    	    data_in_transfer_size = elements_per_iteration;
	    	    bytes_per_iteration = data_in_transfer_size * sizeof(char);
	    	} else if (remaining_bytes > 0) {
	    	    data_in_transfer_size = remaining_bytes;
	    	    bytes_per_iteration = data_in_transfer_size * sizeof(char);
	    	} else {
	    	    data_in_transfer_size = remaining_bytes;
	    	    bytes_per_iteration = data_in_transfer_size * sizeof(char);
	    	}
	}
	printf("Buffers created for pipelining\n");
	// Timestamp
	
	remaining_bytes = length_data;
	
	// Only ask for the number of bytes that are left on the last iteration
	if (remaining_bytes > elements_per_iteration) {
	    	data_in_transfer_size = elements_per_iteration;
	} else if (remaining_bytes > 0) {
	    	data_in_transfer_size = remaining_bytes;
	} else {
	    	data_in_transfer_size = remaining_bytes;
	}
	
	gettimeofday(&tv5,NULL);
	// Loop for pipelining
	for (unsigned int i = 0; i < num_iterations; i++) {
		flag = i;
		err1 = clEnqueueMigrateMemObjects(commands, 1, &data_in_vector[i], 0, 0, NULL, &wrEvents1[flag]);
#ifdef ENABLE_EVENT_DEBUG
		clSetEventCallback(wrEvents1[flag], CL_COMPLETE, event_cb, (void*)"WRcomplete");
#endif

		curr_addr[i] = i*elements_per_iteration;

		if (err1 != CL_SUCCESS) {
		    std::cout << "A" << "\n";
		    break;
		}

		currWrEvents[0] = wrEvents1[flag];
		currWrEvents[1] = wrEvents2[flag];
		currWrEvents[2] = wrEvents3[flag];
		err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &data_in_vector[i]);
                err |= clSetKernelArg(kernel, 1, sizeof(int), &data_in_transfer_size);
                err |= clSetKernelArg(kernel, 2, sizeof(cl_mem), &data_out_vector[i]);
                err |= clSetKernelArg(kernel, 3, sizeof(int), &h_data_out_len_avail);
                err |= clSetKernelArg(kernel, 4, sizeof(cl_mem), &data_out_status_vector[i]);
                err |= clSetKernelArg(kernel, 5, sizeof(aes_keyx), &aes_keyx);
                err |= clSetKernelArg(kernel, 6, sizeof(aes_ivx), &aes_ivx);
	
		gettimeofday(&tv6,NULL);

		//Kernel enqueued
		err = clEnqueueTask(commands, kernel,
			1,   		// num events in wait list
			&wrEvents1[flag],		// event wait list
			&cuEvents[i]);		// event

		if (err != CL_SUCCESS) {
		    std::cout << "D" << "\n";
		    break;
		}
		
        	err = clEnqueueMigrateMemObjects(commands, 1, &data_out_vector[i],
			CL_MIGRATE_MEM_OBJECT_HOST, 1, &cuEvents[i], &rdEvents1[flag]);

		err = clEnqueueMigrateMemObjects(commands, 1, &data_out_status_vector[i],
			CL_MIGRATE_MEM_OBJECT_HOST, 1, &cuEvents[i], &rdEvents2[flag]);

		if (err != CL_SUCCESS) {
			std::cout << "E" << "\n";
			break;
		}

#ifdef ENABLE_EVENT_DEBUG
		clSetEventCallback(rdEvents1[flag], CL_COMPLETE, event_cb, (void*)"RDcomplete");
#endif
		if (err != CL_SUCCESS) {
		    std::cout << "F" << "\n";
		    break;
		}
		// Keep track of how many bytes remain in file
		if (remaining_bytes > elements_per_iteration) {
		    remaining_bytes = remaining_bytes - elements_per_iteration;
		} else {
		    remaining_bytes = 0;
		}

		// Only ask for the number of bytes that are left on the last iteration
		if (remaining_bytes > elements_per_iteration) {
		    data_in_transfer_size = elements_per_iteration;
		} else if (remaining_bytes > 0) {
		    data_in_transfer_size = remaining_bytes;
		} else {
		    data_in_transfer_size = remaining_bytes;
		}

		bytes_per_iteration = data_in_transfer_size * sizeof(char);


    	} //end new-iteration
	if (err != CL_SUCCESS) {

		std::cout << "G" << "\n";
		return -1;
    	}

	clFinish(commands);
	gettimeofday(&tv7,NULL);

	double crunch_time = t.stop();
	
	if (err != CL_SUCCESS) {
	
	    	std::cout << "G" << "\n";
	    	return -1;
	}
	// Now need to find out the total length based on each iteration's status
	comp_len = 0;
	comp_status = 1;
	
	// Add up all length segments to get final length of all returned data
	// Only interested in two integers from h_data_out_status (set to 4096 mem locations for alignment)
	for (unsigned int i=0 ; i < num_iterations ; i=i+1) {
	    	// Successful status should be 0x8 - No other bits should be high
	    	if (i < num_iterations - 1) {
	    	    //comp_status = comp_status && (*(h_data_out_status + i*4096 + 1) == 8);
	    	    comp_status = comp_status && (*(h_data_out_status + i*4096));
	    	    curr_len[i] = roundUp(*(h_data_out_status + i*4096),32);
	    	    comp_len = comp_len + curr_len[i];
	    	} else {
	    	    //comp_status = comp_status && (*(h_data_out_status + i*4096 + 1) == 8);
	    	    comp_status = comp_status && (*(h_data_out_status + i*4096));
	    	    curr_len[i] = *(h_data_out_status + i*4096);
	    	    comp_len = comp_len + curr_len[i];
	    	}
	}

	gettimeofday(&tv8,NULL);
	
	// Write to file with correct length of segments from h_data_out
	comp_len = 0;
	printf("Writing output to file %s\n", filename);
	printf("\n");

	for (unsigned int i=0 ; i < num_iterations ; i=i+1) {
		if (i == 0) {
			//strrev(h_data_out, 32, curr_len[0]);
			fwrite(&h_data_out[0],1,curr_len[0],fp);
			comp_len = comp_len + curr_len[i];
		} else {
			// On iteration 1, use iteration 0's length as starting place for next segment memcpy
			fwrite(&h_data_out[curr_addr[i]],1,curr_len[i],fp);
			comp_len = comp_len + curr_len[i];
		}
	}
	int crypt_status;
	if(aes_ctrl == 2 && (!DEFAULT))
	{
		crypt_status = memcmp(h_data_out, cipher_txt, length_data);
	} else if (aes_ctrl == 3 && (!DEFAULT)) {
		crypt_status = memcmp(h_data_out, plain_txt, length_data);
	}
	if(aes_ctrl ==2)
	{	  
	printf("Encrypted file length is %d bytes\n", comp_len);
	printf("Encrypted file status is %x\n", comp_status);
	}
	else if(aes_ctrl ==3)
	{

	printf("Decrypted file length is %d bytes\n", comp_len);
	printf("Decrypted file status is %x\n", comp_status);

	}

	gettimeofday(&tv9,NULL);
	
	//--------------------------------------------------------------------------
	// Shutdown and cleanup
	//--------------------------------------------------------------------------
	//
	for(unsigned int i=0; i < num_iterations; ++i) {
	    	clReleaseMemObject(data_in_vector.at(i));
	    	clReleaseMemObject(data_out_vector.at(i));
	    	clReleaseMemObject(data_out_status_vector.at(i));
	}
	clReleaseProgram(program);
	
	clReleaseKernel(kernel);
	
	clReleaseContext(context);
	
	free(aes_key);
	free(aes_iv);
	if (!DEFAULT) {
		free(cipher_txt);
		free(plain_txt);
	}
	free(h_data_in);
	free(h_data_out);
	free(curr_len);
	free(curr_addr);
	free(h_data_out_status);
	fclose(fp);
	
	// Report Timing Summary
	std::cout << "The time for crunching is " << crunch_time << " microseconds" << std::endl;
	
	elapsed_time_delay = ((tv1.tv_sec - tv0.tv_sec)*1000000L
	        +tv1.tv_usec) - tv0.tv_usec;
	
	printf("Delay Time in microseconds for Startup Routines: %ld microseconds\n", elapsed_time_delay );
	
	elapsed_time_delay = ((tv2.tv_sec - tv1.tv_sec)*1000000L
	        +tv2.tv_usec) - tv1.tv_usec;
	
	printf("Delay Time in microseconds from File Read to Memory & Create Output File: %ld microseconds\n", elapsed_time_delay );
	
	elapsed_time_delay = ((tv9.tv_sec - tv8.tv_sec)*1000000L
	        +tv9.tv_usec) - tv8.tv_usec;
	
	printf("Delay Time in microseconds from Memory to Output File: %ld microseconds\n", elapsed_time_delay );
	
	elapsed_time_delay = ((tv9.tv_sec - tv0.tv_sec)*1000000L
	        +tv9.tv_usec) - tv0.tv_usec;
	
	printf("Delay Time in microseconds start to finish (includes Start-up time): %ld microseconds\n", elapsed_time_delay );
	
	elapsed_time_delay = ((tv9.tv_sec - tv1.tv_sec)*1000000L
	        +tv9.tv_usec) - tv1.tv_usec;
	
	printf("Delay Time in microseconds start to finish (excluding Start-up time): %ld microseconds\n", elapsed_time_delay );

	elapsed_time_delay = ((tv7.tv_sec - tv5.tv_sec)*1000000L
	        +tv7.tv_usec) - tv5.tv_usec;
	
	printf("MEM2MEM_time: %ld\n", elapsed_time_delay);	
	
	if (comp_status == 0) {
	    	printf("INFO: Test failed\n");
	    	return EXIT_FAILURE;
	} else {
	    	printf("INFO: Test passed\n");
	}
	
	if(!crypt_status && aes_ctrl==2)
	    printf("STATUS: ENCRYPTION PASSED\n");
	else if(!crypt_status && aes_ctrl==3)
	    printf("STATUS: DECRYPTION PASSED\n");
        else if(crypt_status && aes_ctrl==2)
	    printf("STATUS: ENCRYPTION FAILED\n");
        else if(crypt_status && aes_ctrl==3)
	    printf("STATUS: DECRYPTION FAILED\n");
	
	printf("\n");
}
